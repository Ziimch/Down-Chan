# youtubedl-android memakai refleksi (Jackson) dan JNI
-keep class com.yausername.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-dontwarn com.fasterxml.jackson.**
-dontwarn org.apache.commons.compress.**

# Dipanggil sistem Android 15 lewat dispatch virtual (tanpa 'override' karena compileSdk 34):
# tanpa aturan ini R8 menganggapnya tak terpakai dan menghapusnya.
-keepclassmembers class com.example.unduhku.DownloadService {
    public void onTimeout(int, int);
}
