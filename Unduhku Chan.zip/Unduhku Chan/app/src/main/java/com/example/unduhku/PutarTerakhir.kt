package com.example.unduhku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Lagu online yang terakhir diputar: isi beranda "Terakhir diputar" (seperti Quick Picks di Metrolist). */
object PutarTerakhir {
    private const val MAKS = 30
    private var data: MutableList<HasilLagu>? = null

    private fun berkas(c: Context) = File(c.applicationContext.filesDir, "putar_terakhir.json")

    @Synchronized
    private fun muat(c: Context): MutableList<HasilLagu> {
        data?.let { return it }
        val hasil = mutableListOf<HasilLagu>()
        runCatching {
            val f = berkas(c)
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("i")
                    if (id.isBlank()) continue
                    hasil += HasilLagu(id, o.optString("j"), o.optString("a"), o.optLong("d"), o.optString("t").ifBlank { null })
                }
            }
        }
        data = hasil
        return hasil
    }

    @Synchronized
    fun semua(c: Context): List<HasilLagu> = muat(c).toList()

    @Synchronized
    fun tambah(c: Context, l: HasilLagu) {
        val d = muat(c)
        d.removeAll { it.id == l.id }
        d.add(0, l)
        while (d.size > MAKS) d.removeAt(d.lastIndex)
        simpan(c, d)
    }

    @Synchronized
    fun kosongkan(c: Context) {
        muat(c).clear()
        simpan(c, emptyList())
    }

    private fun simpan(c: Context, d: List<HasilLagu>) {
        val arr = JSONArray()
        d.forEach {
            arr.put(
                JSONObject().put("i", it.id).put("j", it.judul).put("a", it.artis)
                    .put("d", it.durasi).put("t", it.thumb.orEmpty())
            )
        }
        runCatching { berkas(c).writeText(arr.toString()) }
    }
}
