package com.example.unduhku

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Daftar antrean di layar Putar: lagu aktif ditandai, ketuk untuk melompat ke lagu itu. */
class AntreanAdapter(private val onKlik: (Int) -> Unit) : RecyclerView.Adapter<AntreanAdapter.VH>() {

    private var data: List<Lagu> = emptyList()
    private var aktif = -1

    class VH(val root: View) : RecyclerView.ViewHolder(root) {
        val no: TextView = root.findViewById(R.id.tvNoA)
        val judul: TextView = root.findViewById(R.id.tvJudulA)
        val artis: TextView = root.findViewById(R.id.tvArtisA)
    }

    /** Hanya baris yang berubah yang digambar ulang saat lagu aktif berpindah. */
    fun set(list: List<Lagu>, aktifBaru: Int) {
        if (list !== data) {
            data = list
            aktif = aktifBaru
            notifyDataSetChanged()
            return
        }
        if (aktifBaru != aktif) {
            val lama = aktif
            aktif = aktifBaru
            if (lama in data.indices) notifyItemChanged(lama)
            if (aktifBaru in data.indices) notifyItemChanged(aktifBaru)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_antrean, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val l = data[position]
        val nyala = position == aktif
        h.no.text = if (nyala) "▶" else (position + 1).toString()
        h.judul.text = l.nama
        h.judul.setTypeface(null, if (nyala) Typeface.BOLD else Typeface.NORMAL)
        val artis = l.artis.orEmpty()
        h.artis.text = artis
        h.artis.visibility = if (artis.isBlank()) View.GONE else View.VISIBLE
        h.root.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onKlik(p)
        }
    }

    override fun getItemCount() = data.size
}
