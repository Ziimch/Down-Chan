package com.example.unduhku

import android.net.Uri

enum class FormatUnduh { MP4, MP3 }

enum class Efek(val label: String, val filter: String?) {
    NORMAL("Normal", null),
    NORMALISASI("Samakan volume", "loudnorm=I=-16:TP=-1.5:LRA=11"),
    SLOWED("Slowed + reverb", "asetrate=44100*0.85,aresample=44100,aecho=0.8:0.88:60:0.4"),
    NIGHTCORE("Nightcore", "asetrate=44100*1.25,aresample=44100")
}

data class Opsi(
    val format: FormatUnduh,
    val audioKbps: Int,
    val tinggi: Int?,
    val efek: Efek = Efek.NORMAL,
    val mulai: String? = null,
    val akhir: String? = null
)

data class Tugas(val id: String, val url: String, val judul: String, val opsi: Opsi)

data class Berkas(val nama: String, val uri: Uri, val ukuran: Long)

data class EntriPlaylist(val judul: String, val url: String, val durasi: Long)

data class InfoMedia(
    val url: String,
    val judul: String,
    val kanal: String,
    val durasi: Long,
    val thumb: String?,
    val ukuranVideo: Map<Int, Long>,
    val ukuranAudio: Long,
    val entri: List<EntriPlaylist>
) {
    val playlist get() = entri.isNotEmpty()

    /** Perkiraan ukuran video+audio untuk batas tinggi tertentu (null = tertinggi). */
    fun perkiraan(tinggi: Int?): Long {
        if (ukuranVideo.isEmpty()) return 0
        val kunci = if (tinggi == null) ukuranVideo.keys.max()
        else ukuranVideo.keys.filter { it <= tinggi }.maxOrNull() ?: ukuranVideo.keys.min()
        return (ukuranVideo[kunci] ?: 0) + ukuranAudio
    }
}

sealed interface HasilUnduh {
    data class Sukses(val daftar: List<Berkas>) : HasilUnduh
    data class Gagal(val pesan: String) : HasilUnduh
    data object Dibatalkan : HasilUnduh
    data object Dijeda : HasilUnduh
    data object Dilewati : HasilUnduh
}

sealed interface HasilKonversi {
    data class Sukses(val nama: String, val uri: Uri?, val ukuran: Long) : HasilKonversi
    data class Gagal(val pesan: String) : HasilKonversi
    data object Dibatalkan : HasilKonversi
}
