package com.example.unduhku

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** Menjalankan antrean unduhan di latar belakang, lengkap dengan notifikasi progres. */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val berjalan = AtomicBoolean(false)
    private val downloader by lazy { Downloader(applicationContext) }
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var startIdTerakhir = 0
    private var sudahPerbarui = false
    private var notifTerakhir = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startIdTerakhir = startId
        buatKanal()
        if (intent?.action == AKSI_BATAL) {
            AntrianUnduh.kosongkanAntre()
            AntrianUnduh.hentikanAktif(jeda = false)
        }
        val tipe = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, ID_NOTIF, notif("Down-Chan", "Menyiapkan…", -1), tipe)
        if (berjalan.compareAndSet(false, true)) scope.launch { pekerja() }
        return START_NOT_STICKY
    }

    /**
     * Android 15+ membatasi layanan jenis dataSync (sekitar 6 jam). Sengaja tanpa `override`
     * karena compileSdk masih 34; sistem tetap memanggilnya lewat dispatch virtual.
     * Bila compileSdk dinaikkan ke 35, tambahkan `override`.
     */
    fun onTimeout(startId: Int, fgsType: Int) {
        Catatan.tulis("Layanan unduhan mencapai batas waktu sistem; sisa unduhan dijeda.")
        AntrianUnduh.jedakanSemua()
        AntrianUnduh.hentikanAktif(jeda = true)
        scope.launch {
            kotlinx.coroutines.delay(4000)
            stopSelf()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        wakeLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    private suspend fun pekerja() {
        val prefs = Prefs(this)
        Mesin.siapkan(application)
        bersihkanSisa()
        // Wake lock lokal: pekerja lama tidak boleh melepas wake lock milik pekerja baru.
        val wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "unduhku:unduh")
            .apply { acquire(2 * 60 * 60 * 1000L) }
        wakeLock = wl
        try {
            while (true) {
                val t = AntrianUnduh.ambilBerikut()
                if (t == null) {
                    berjalan.set(false)
                    // Ada tugas yang masuk tepat saat selesai? Lanjut lagi.
                    if (AntrianUnduh.adaAntrean() && berjalan.compareAndSet(false, true)) continue
                    break
                }
                try { proses(t, prefs) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                    Catatan.tulis("Error tak terduga: ${e.message}")
                    AntrianUnduh.selesai(false, "Gagal: ${ringkasError(e)}", t)
                }
            }
        } finally {
            wl.takeIf { it.isHeld }?.release()
        }
        notifSelesai()
        // Hanya berhenti bila tidak ada permintaan mulai baru sejak startId terakhir.
        if (stopSelfResult(startIdTerakhir)) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        }
    }

    private suspend fun proses(t: Tugas, prefs: Prefs) {
        val folder = prefs.folderUri?.toUri()
        if (folder == null) { AntrianUnduh.selesai(false, "Pilih folder simpan dulu", t); return }
        if (prefs.wifiOnly && !Jaringan.wifi(this)) {
            AntrianUnduh.selesai(false, "Mode 'Hanya Wi-Fi' aktif, tapi tidak tersambung Wi-Fi", t)
            return
        }

        perbaruiNotif(t.judul, "Mengunduh…", -1, paksa = true)
        val unduh = suspend {
            downloader.unduh(
                t, prefs, folder,
                onProgress = { p ->
                    AntrianUnduh.setProgress(p)
                    perbaruiNotif(t.judul, "Mengunduh $p%", p)
                },
                onMenyimpan = {
                    AntrianUnduh.setTahap("Menyimpan…")
                    perbaruiNotif(t.judul, "Menyimpan…", -1, paksa = true)
                }
            )
        }

        var hasil = unduh()
        // HTTP 403 / minta login biasanya karena yt-dlp kedaluwarsa: perbarui sekali lalu ulangi.
        if (hasil is HasilUnduh.Gagal && !sudahPerbarui && perluPerbarui(hasil.pesan)) {
            sudahPerbarui = true
            AntrianUnduh.setTahap("Memperbarui mesin…")
            perbaruiNotif(t.judul, "Memperbarui mesin…", -1, paksa = true)
            if (Mesin.perbarui(this)) {
                AntrianUnduh.setTahap("Mengunduh ulang")
                hasil = unduh()
            }
        }

        when (hasil) {
            is HasilUnduh.Sukses -> {
                val label = if (t.opsi.format == FormatUnduh.MP3) "MP3" else "MP4"
                val riwayat = Riwayat.get(this)
                hasil.daftar.forEach {
                    riwayat.tambah(
                        Entri(namaDasar(it.nama), it.nama, label, it.ukuran, System.currentTimeMillis(), it.uri.toString(), t.url)
                    )
                }
                val nama = hasil.daftar.firstOrNull()?.nama ?: t.judul
                val tambahan = if (hasil.daftar.size > 1) " (+${hasil.daftar.size - 1})" else ""
                AntrianUnduh.selesai(true, "Tersimpan: $nama$tambahan")
            }
            is HasilUnduh.Gagal -> {
                val saran = if (perluPerbarui(hasil.pesan)) "\nCoba: Atur → Perbarui mesin." else ""
                AntrianUnduh.selesai(false, "Gagal: ${hasil.pesan}$saran", t)
            }
            HasilUnduh.Dibatalkan -> AntrianUnduh.selesaiTanpaHitung("Unduhan dibatalkan.")
            HasilUnduh.Dijeda -> AntrianUnduh.terjeda(t)
            HasilUnduh.Dilewati -> AntrianUnduh.selesaiTanpaHitung("Dilewati: sudah pernah diunduh (${t.judul}).")
        }
    }

    /** Hapus folder kerja lama yang tidak terpakai (sisa crash atau jeda yang terlupa). */
    private fun bersihkanSisa() {
        val batas = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        File(cacheDir, "dl").listFiles()?.filter { it.lastModified() < batas }?.forEach { it.deleteRecursively() }
    }

    // ---------- Notifikasi ----------

    private fun buatKanal() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(KANAL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(KANAL, "Unduhan", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notif(judul: String, teks: String, persen: Int): Notification {
        val buka = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val batal = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction(AKSI_BATAL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, KANAL)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(judul)
            .setContentText(teks)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, persen.coerceAtLeast(0), persen < 0)
            .setContentIntent(buka)
            .addAction(0, "Batalkan semua", batal)
            .build()
    }

    /** Dibatasi 1x per detik supaya tidak boros CPU/baterai. */
    private fun perbaruiNotif(judul: String, teks: String, persen: Int, paksa: Boolean = false) {
        val sekarang = System.currentTimeMillis()
        if (!paksa && sekarang - notifTerakhir < 1000 && persen < 100) return
        notifTerakhir = sekarang
        runCatching {
            NotificationManagerCompat.from(this).notify(ID_NOTIF, notif(judul, teks, persen))
        }
    }

    private fun notifSelesai() {
        val s = AntrianUnduh.status.value
        if (s.sukses + s.gagal == 0) return
        val buka = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, KANAL)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("Unduhan selesai")
            .setContentText("${s.sukses} berhasil, ${s.gagal} gagal")
            .setContentIntent(buka)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(this).notify(ID_SELESAI, n) }
    }

    companion object {
        private const val KANAL = "unduhan"
        private const val ID_NOTIF = 1
        private const val ID_SELESAI = 2
        const val AKSI_BATAL = "com.example.unduhku.BATAL"

        /** Masukkan ke antrean lalu pastikan service berjalan. */
        fun mulai(context: Context, daftar: List<Tugas>) {
            AntrianUnduh.tambah(daftar)
            ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
        }
    }
}
