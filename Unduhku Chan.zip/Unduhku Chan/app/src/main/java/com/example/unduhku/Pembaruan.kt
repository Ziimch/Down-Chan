package com.example.unduhku

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Pengingat versi baru lewat GitHub Releases.
 * Hemat data & baterai: tanpa library, tanpa polling di latar belakang. Dicek hanya saat
 * aplikasi dibuka, paling sering 1x per 12 jam, dengan ETag (balasan 304 tidak memakan kuota
 * API GitHub dan hampir tanpa data).
 */
object Pembaruan {
    private const val REPO = "Ziimch/Down-Chan"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    private const val JEDA_CEK = 12L * 60 * 60 * 1000

    data class Info(val versi: String, val catatan: String, val halaman: String, val apk: String?)

    sealed interface Hasil {
        data class Baru(val info: Info) : Hasil
        data object Terkini : Hasil
        data object Dilewati : Hasil
        data class Gagal(val pesan: String) : Hasil
    }

    fun versiSaatIni(c: Context): String = runCatching {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName
    }.getOrNull() ?: "0"

    /** "v2.1.0" lebih baru dari "2.0"? Hanya angka yang dibandingkan. */
    fun lebihBaru(baru: String, lama: String): Boolean {
        val a = angka(baru)
        val b = angka(lama)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    private fun angka(v: String) = Regex("\\d+").findAll(v).map { it.value.toIntOrNull() ?: 0 }.toList()

    suspend fun cek(context: Context, prefs: Prefs, paksa: Boolean): Hasil = withContext(Dispatchers.IO) {
        if (!paksa) {
            if (!prefs.cekOtomatis) return@withContext Hasil.Dilewati
            if (prefs.wifiOnly && !Jaringan.wifi(context)) return@withContext Hasil.Dilewati
        }
        val sekarang = System.currentTimeMillis()
        var json = prefs.rilisCache
        val segar = !paksa && json != null && sekarang - prefs.cekTerakhir < JEDA_CEK
        if (!segar) {
            try {
                json = ambil(prefs)
                prefs.cekTerakhir = sekarang
            } catch (e: Exception) {
                Catatan.tulis("Cek pembaruan gagal: ${e.message}")
                return@withContext Hasil.Gagal(e.message ?: "tidak ada koneksi")
            }
        }
        val info = json?.let { dariJson(it) } ?: return@withContext Hasil.Terkini
        val baru = lebihBaru(info.versi, versiSaatIni(context))
        if (baru && (paksa || info.versi != prefs.lewatiVersi)) Hasil.Baru(info) else Hasil.Terkini
    }

    /** Mengembalikan JSON ringkas rilis terbaru (atau null bila repo belum punya rilis). */
    private fun ambil(prefs: Prefs): String? {
        val c = URL(API).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "Down-Chan")
            val lama = prefs.rilisCache
            val etag = prefs.etag
            if (etag != null && lama != null) c.setRequestProperty("If-None-Match", etag)

            return when (val kode = c.responseCode) {
                304 -> lama
                404 -> { prefs.rilisCache = null; prefs.etag = null; null }
                200 -> {
                    val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    val apk = j.optJSONArray("assets")?.let { a ->
                        (0 until a.length()).map { a.getJSONObject(it) }
                            .firstOrNull { it.teks("name").endsWith(".apk", ignoreCase = true) }
                            ?.teks("browser_download_url")
                    }
                    val ringkas = JSONObject()
                        .put("v", j.teks("tag_name"))
                        .put("c", j.teks("body").take(1500))
                        .put("h", j.teks("html_url"))
                        .put("a", apk ?: "")
                        .toString()
                    prefs.etag = c.getHeaderField("ETag")
                    prefs.rilisCache = ringkas
                    ringkas
                }
                else -> throw IOException("GitHub membalas HTTP $kode")
            }
        } finally {
            c.disconnect()
        }
    }

    private fun dariJson(s: String): Info? = runCatching {
        val j = JSONObject(s)
        val v = j.teks("v")
        if (v.isBlank()) null
        else Info(v, j.teks("c"), j.teks("h").ifBlank { "https://github.com/$REPO/releases/latest" }, j.teks("a").ifBlank { null })
    }.getOrNull()
}
