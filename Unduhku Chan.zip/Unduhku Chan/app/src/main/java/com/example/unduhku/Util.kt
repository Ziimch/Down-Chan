package com.example.unduhku

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.util.Locale

object Jaringan {
    fun wifi(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
        val cap = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            cap.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }
}

fun formatUkuran(b: Long): String = when {
    b <= 0 -> "?"
    b < 1_048_576 -> "${b / 1024} KB"
    b < 1_073_741_824 -> String.format(Locale.getDefault(), "%.1f MB", b / 1_048_576.0)
    else -> String.format(Locale.getDefault(), "%.2f GB", b / 1_073_741_824.0)
}

fun formatDurasi(detik: Long): String {
    val j = detik / 3600
    val m = (detik % 3600) / 60
    val s = detik % 60
    return if (j > 0) String.format(Locale.US, "%d:%02d:%02d", j, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

private val POLA_WAKTU = Regex("""^(\d{1,2}:){0,2}\d{1,2}(\.\d+)?$""")
fun waktuValid(s: String) = POLA_WAKTU.matches(s)

fun bersihkanNamaFile(n: String): String =
    n.replace(Regex("[\\\\/:*?\"<>|#%]"), "_").ifBlank { "file" }

fun namaDasar(n: String): String =
    bersihkanNamaFile(n.substringBeforeLast('.', n)).ifBlank { "hasil" }

/** Ambil baris error yt-dlp yang paling informatif, bukan stack trace panjang. */
fun ringkasError(e: Throwable): String {
    val baris = e.message.orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }
    val error = baris.lastOrNull { it.startsWith("ERROR", ignoreCase = true) }
    val teks = (error ?: baris.lastOrNull() ?: e.javaClass.simpleName).removePrefix("ERROR:").trim()
    return teks.take(160)
}

/** JSON null dari yt-dlp jangan jadi string "null". */
fun JSONObject.teks(k: String): String = if (isNull(k)) "" else optString(k)

fun perluPerbarui(pesan: String) =
    pesan.contains("HTTP Error 403", ignoreCase = true) ||
        pesan.contains("403: Forbidden", ignoreCase = true) ||
        pesan.contains("Sign in to", ignoreCase = true)

fun formatWebp(): android.graphics.Bitmap.CompressFormat =
    if (android.os.Build.VERSION.SDK_INT >= 30) android.graphics.Bitmap.CompressFormat.WEBP_LOSSY
    else @Suppress("DEPRECATION") android.graphics.Bitmap.CompressFormat.WEBP

/** Set teks hanya bila berubah: menghindari relayout sia-sia saat progres sering diperbarui. */
fun android.widget.TextView.setTeks(t: CharSequence) {
    if (text.toString() != t.toString()) text = t
}

fun ukuranCache(c: Context): Long =
    c.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

/** Unduhan yang sedang dijeda memakai cache/dl untuk resume, jadi hanya dihapus bila aman. */
fun bersihkanCache(c: Context, termasukUnduhan: Boolean, termasukKonversi: Boolean = true) {
    if (termasukKonversi) java.io.File(c.cacheDir, "konversi").deleteRecursively()
    if (termasukUnduhan) java.io.File(c.cacheDir, "dl").deleteRecursively()
}

/** "1:30" / "90" / "1:02:03.5" -> detik. */
fun waktuKeDetik(s: String): Double? {
    var total = 0.0
    for (b in s.split(':')) total = total * 60 + (b.toDoubleOrNull() ?: return null)
    return total
}

/** Akhir harus setelah mulai (kalau keduanya diisi). */
fun rentangValid(mulai: String?, akhir: String?): Boolean {
    if (mulai == null || akhir == null) return true
    val a = waktuKeDetik(mulai) ?: return false
    val b = waktuKeDetik(akhir) ?: return false
    return b > a
}

/**
 * cookies.txt harus berformat Netscape. File yang salah membuat SEMUA unduhan gagal dengan pesan
 * membingungkan, jadi diperiksa sebelum disimpan.
 */
fun cookiesValid(isi: String): Boolean {
    val baris = isi.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
    if (baris.isEmpty()) return false
    val kepala = baris.first()
    if (kepala.startsWith("# Netscape HTTP Cookie File", ignoreCase = true) ||
        kepala.startsWith("# HTTP Cookie File", ignoreCase = true)) return true
    return baris.any { (!it.startsWith("#") || it.startsWith("#HttpOnly_")) && it.split('\t').size >= 7 }
}
