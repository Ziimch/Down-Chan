package com.example.unduhku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.util.LruCache
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HasilLagu(
    val id: String,
    val judul: String,
    val artis: String,
    val durasi: Long,
    val thumb: String?
)

/** Tautan audio langsung dari YouTube. Kedaluwarsa dalam beberapa jam, jadi disimpan beserta batas waktunya. */
class StreamLagu(val url: String, val headers: Map<String, String>, val kedaluwarsa: Long)

/**
 * Mesin "Jelajah": cari lagu, siapkan tautan streaming, dan cache.
 *
 * Kecepatan (waktu tunggu sebelum lagu berbunyi) adalah prioritas:
 *  - pencarian lewat satu permintaan HTTP langsung (cadangan: yt-dlp),
 *  - tautan stream disimpan di cache dan lagu berikutnya disiapkan lebih dulu (prefetch),
 *  - memanggil yt-dlp (yang menyalakan Python) dibuat sesedikit mungkin.
 * Semua waktu dicatat di log (Atur -> Salin log) supaya bisa diukur di HP.
 */
object Jelajah {

    // Klien ANDROID_VR: memberi tautan audio langsung tanpa PO Token dan tanpa runtime JavaScript.
    private const val VERSI_VR = "1.65.10"
    private const val UA_VR = "com.google.android.apps.youtube.vr.oculus/$VERSI_VR (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    private const val TES_ID = "jNQXAC9IVRw"
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    private val DURASI = Regex("^\\d{1,2}(:\\d{2}){1,2}$")
    private val JENIS = setOf("Lagu", "Song", "Video", "Single", "EP", "Album")

    private val cacheStream = object : LinkedHashMap<String, StreamLagu>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, StreamLagu>?): Boolean = size > 60
    }

    private val cacheGambar = object : LruCache<String, Bitmap>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val scopeLatar = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var prefetchBerjalan = false

    /** Alasan kegagalan terakhir (untuk ditampilkan ke pengguna dan ke log). */
    @Volatile var alasanGagal: String? = null

    /** ID pengunjung YouTube (visitorData). yt-dlp selalu mengirimnya; tanpa itu permintaan langsung dicurigai bot. */
    @Volatile private var dataPengunjung: String? = null

    /** Bila jalur langsung gagal berturut-turut, dilewati sementara supaya tiap lagu tidak membuang waktu. */
    @Volatile private var gagalLangsungBerturut = 0
    @Volatile private var lewatiLangsungHingga = 0L

    /** Jejak percobaan jalur langsung terakhir (ditampilkan di Tes pemutaran online). */
    @Volatile private var jejakLangsung = ""

    /** Tautan yang sedang diambil: permintaan kedua untuk lagu yang sama menunggu, bukan menyalakan Python lagi. */
    private val sedangDiambil = HashMap<String, CompletableDeferred<StreamLagu?>>()

    // ================================================================ PENCARIAN

    suspend fun cari(context: Context, kueri: String, video: Boolean = false): List<HasilLagu> = withContext(Dispatchers.IO) {
        val t0 = SystemClock.elapsedRealtime()
        val cepat = runCatching { cariLangsung(kueri, video) }
            .onFailure { Catatan.tulis("Cari langsung gagal: ${it.message}") }
            .getOrNull().orEmpty()
        if (cepat.isNotEmpty()) {
            Catatan.tulis("Cari \"$kueri\": ${cepat.size} hasil, langsung, ${SystemClock.elapsedRealtime() - t0} ms")
            return@withContext cepat
        }
        // Cadangan: yt-dlp (lebih lambat, tetapi tidak bergantung pada format respons YouTube Music)
        val cadangan = cariYtDlp(kueri)
        Catatan.tulis("Cari \"$kueri\": ${cadangan.size} hasil, yt-dlp, ${SystemClock.elapsedRealtime() - t0} ms")
        cadangan
    }

    private fun cariLangsung(kueri: String, video: Boolean): List<HasilLagu> {
        val tanggal = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(System.currentTimeMillis() - 86_400_000L))
        val badan = JSONObject()
            .put(
                "context", JSONObject().put(
                    "client", JSONObject()
                        .put("clientName", "WEB_REMIX")
                        .put("clientVersion", "1.$tanggal.01.00")
                        .put("hl", "id").put("gl", "ID")
                )
            )
            .put("query", kueri)
            .put("params", if (video) "EgWKAQIQAWoMEA4QChADEAQQCRAF" else "EgWKAQIIAWoMEA4QChADEAQQCRAF") // filter: Video / Lagu
            .toString()
        val c = URL("https://music.youtube.com/youtubei/v1/search?prettyPrint=false").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Origin", "https://music.youtube.com")
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
            c.outputStream.use { it.write(badan.toByteArray()) }
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val root = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            if (dataPengunjung == null) {
                dataPengunjung = root.optJSONObject("responseContext")?.optString("visitorData")?.takeIf { it.isNotBlank() }
            }
            return parseCari(root)
        } finally {
            c.disconnect()
        }
    }

    private fun cariYtDlp(kueri: String): List<HasilLagu> {
        val req = YoutubeDLRequest("ytsearch20:$kueri").apply {
            addOption("-J")
            addOption("--flat-playlist")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(req, "cari-${System.nanoTime()}") { _, _, _ -> }.out
        val arr = JSONObject(out.substring(out.indexOf('{'))).optJSONArray("entries") ?: return emptyList()
        val hasil = mutableListOf<HasilLagu>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val id = e.teks("id")
            if (id.length != 11) continue
            hasil += HasilLagu(
                id = id,
                judul = e.teks("title").ifBlank { id },
                artis = e.teks("uploader").ifBlank { e.teks("channel") }.removeSuffix(" - Topic"),
                durasi = e.optLong("duration", 0),
                thumb = "https://i.ytimg.com/vi/$id/mqdefault.jpg"
            )
        }
        return hasil
    }

    /** Struktur respons YouTube Music bersarang dalam dan sering berubah: cari simpul lagu secara rekursif. */
    private fun parseCari(root: JSONObject): List<HasilLagu> {
        val item = mutableListOf<JSONObject>()
        kumpulkan(root, "musicResponsiveListItemRenderer", item)
        val hasil = LinkedHashMap<String, HasilLagu>()
        for (r in item) {
            val id = r.optJSONObject("playlistItemData")?.optString("videoId").orEmpty()
                .ifBlank { cariNilai(r, "videoId") as? String ?: "" }
            if (id.length != 11 || id in hasil) continue
            val kolom = r.optJSONArray("flexColumns") ?: continue
            val judul = teksKolom(kolom, 0)
            if (judul.isBlank()) continue
            val bagian = teksKolom(kolom, 1).split(" • ").map { it.trim() }
                .filter { it.isNotEmpty() && it !in JENIS }
            val artis = bagian.firstOrNull { !DURASI.matches(it) }.orEmpty()
            val durasi = bagian.lastOrNull { DURASI.matches(it) }?.let { waktuKeDetik(it)?.toLong() } ?: 0L
            val thumb = (cariNilai(r, "thumbnails") as? JSONArray)
                ?.let { a -> a.optJSONObject(a.length() - 1)?.optString("url") }
                ?.takeIf { it.isNotBlank() }
                ?.replace(Regex("=w\\d+-h\\d+"), "=w256-h256")
            hasil[id] = HasilLagu(id, judul, artis, durasi, thumb)
            if (hasil.size >= 25) break
        }
        return hasil.values.toList()
    }

    private fun teksKolom(kolom: JSONArray, i: Int): String {
        val runs = kolom.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")?.optJSONArray("runs") ?: return ""
        return buildString { for (j in 0 until runs.length()) append(runs.optJSONObject(j)?.optString("text").orEmpty()) }
    }

    private fun kumpulkan(n: Any?, kunci: String, keluar: MutableList<JSONObject>) {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = n.opt(k)
                    if (k == kunci && v is JSONObject) keluar += v else kumpulkan(v, kunci, keluar)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) kumpulkan(n.opt(i), kunci, keluar)
        }
    }

    private fun cariNilai(n: Any?, kunci: String): Any? {
        when (n) {
            is JSONObject -> {
                if (n.has(kunci)) return n.opt(kunci)
                val ks = n.keys()
                while (ks.hasNext()) {
                    val r = cariNilai(n.opt(ks.next()), kunci)
                    if (r != null) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = cariNilai(n.opt(i), kunci)
                if (r != null) return r
            }
        }
        return null
    }

    /** Saran ketikan (autocomplete) ala Metrolist. Gagal = daftar kosong, tanpa mengganggu. */
    suspend fun saran(kueri: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val u = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=id&q=" +
                URLEncoder.encode(kueri, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.setRequestProperty("User-Agent", UA)
                val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray(1)
                val hasil = mutableListOf<String>()
                if (arr != null) for (i in 0 until minOf(arr.length(), 8)) hasil += arr.optString(i)
                hasil.filter { it.isNotBlank() }
            } finally {
                c.disconnect()
            }
        }.getOrDefault(emptyList())
    }

    // ================================================================ STREAM

    private fun dariCache(id: String): StreamLagu? = synchronized(cacheStream) {
        cacheStream[id]?.takeIf { it.kedaluwarsa > System.currentTimeMillis() }
    }

    /** Tautan audio siap putar. Dari cache bila ada (instan), kalau tidak lewat yt-dlp. */
    suspend fun resolve(context: Context, id: String): StreamLagu? {
        dariCache(id)?.let { Catatan.tulis("Stream $id: dari cache"); return it }
        val t0 = SystemClock.elapsedRealtime()
        alasanGagal = null
        val s = ambilStream(listOf(id))[id]
        if (s == null && alasanGagal == null) alasanGagal = "tidak ada tautan audio"
        Catatan.tulis("Stream $id: ${if (s != null) "siap" else "GAGAL (${alasanGagal})"}, total ${SystemClock.elapsedRealtime() - t0} ms")
        return s
    }

    /** Siapkan tautan lagu-lagu berikutnya di latar belakang (satu panggilan yt-dlp untuk semuanya). */
    fun prefetch(context: Context, ids: List<String>) {
        val perlu = ids.filter { dariCache(it) == null }
        if (perlu.isEmpty() || prefetchBerjalan) return
        val app = context.applicationContext
        if (Prefs(app).wifiOnly && !Jaringan.wifi(app)) return
        prefetchBerjalan = true
        scopeLatar.launch {
            try {
                val t0 = SystemClock.elapsedRealtime()
                val h = ambilStream(perlu)
                Catatan.tulis("Prefetch ${perlu.size} lagu: ${h.size} siap, ${SystemClock.elapsedRealtime() - t0} ms")
            } finally {
                prefetchBerjalan = false
            }
        }
    }

    private fun panggilPemutar(id: String, visitor: String?): JSONObject {
        val klien = JSONObject()
            .put("clientName", "ANDROID_VR").put("clientVersion", VERSI_VR)
            .put("deviceMake", "Oculus").put("deviceModel", "Quest 3")
            .put("osName", "Android").put("osVersion", "12L").put("androidSdkVersion", 32)
            .put("hl", "en").put("gl", "US")
            .put("timeZone", "UTC").put("utcOffsetMinutes", 0)
        if (!visitor.isNullOrBlank()) klien.put("visitorData", visitor)
        val badan = JSONObject()
            .put("context", JSONObject().put("client", klien))
            .put("videoId", id).put("contentCheckOk", true).put("racyCheckOk", true)
            .toString()
        val c = URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 4000
            c.readTimeout = 6000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("User-Agent", UA_VR)
            c.setRequestProperty("X-YouTube-Client-Name", "28")
            c.setRequestProperty("X-YouTube-Client-Version", VERSI_VR)
            c.setRequestProperty("Origin", "https://www.youtube.com")
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (!visitor.isNullOrBlank()) c.setRequestProperty("X-Goog-Visitor-Id", visitor)
            c.outputStream.use { it.write(badan.toByteArray()) }
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /**
     * Jalur cepat tanpa Python: satu permintaan HTTP ke API pemutar YouTube. Biasanya di bawah 1 detik,
     * dibanding 4-9 detik lewat yt-dlp (yang harus menyalakan Python lebih dulu).
     *
     * v2.9: permintaan kini membawa ID pengunjung seperti yt-dlp. Bila YouTube menolak, ID baru dari
     * respons penolakan dipakai untuk satu percobaan ulang, lalu disimpan untuk lagu-lagu berikutnya.
     */
    private fun ambilLangsung(id: String): StreamLagu {
        jejakLangsung = ""
        val jejak = StringBuilder()
        var visitor = dataPengunjung
        var j = panggilPemutar(id, visitor)
        var status = j.optJSONObject("playabilityStatus")
        var st = status?.optString("status").orEmpty()
        jejak.append(if (visitor == null) "tanpa ID pengunjung: $st" else "dengan ID pengunjung: $st")
        if (st != "OK") {
            val baru = j.optJSONObject("responseContext")?.optString("visitorData").orEmpty()
            if (baru.isNotBlank() && baru != visitor) {
                dataPengunjung = baru
                visitor = baru
                j = panggilPemutar(id, baru)
                status = j.optJSONObject("playabilityStatus")
                st = status?.optString("status").orEmpty()
                jejak.append(", ulang dengan ID dari respons: $st")
            } else {
                jejak.append(" (respons tanpa ID pengunjung baru)")
            }
        }
        jejakLangsung = jejak.toString()
        if (st != "OK") throw IOException("YouTube menolak ($st ${status?.optString("reason").orEmpty()})".trim())
        val fmt = j.optJSONObject("streamingData")?.optJSONArray("adaptiveFormats")
            ?: throw IOException("tanpa data streaming")
        var terbaik: JSONObject? = null
        var skor = -1L
        for (k in 0 until fmt.length()) {
            val f = fmt.optJSONObject(k) ?: continue
            val mime = f.optString("mimeType")
            if (!mime.startsWith("audio/") || f.optString("url").isBlank()) continue
            // m4a (AAC) paling aman diputar di semua HP: diberi bonus besar
            val nilai = f.optLong("bitrate", 0) + if (mime.startsWith("audio/mp4")) 10_000_000L else 0L
            if (nilai > skor) { skor = nilai; terbaik = f }
        }
        val url = terbaik?.optString("url").orEmpty()
        if (url.isBlank()) throw IOException("tidak ada format audio dengan tautan langsung")
        return StreamLagu(url, mapOf("User-Agent" to UA_VR), batasWaktu(url))
    }

    /**
     * Ambil tautan untuk beberapa lagu. Lagu yang sedang diambil oleh permintaan lain (mis. prefetch
     * yang baru saja jalan) ditunggu, bukan diambil dua kali: dua proses Python sekaligus saling
     * memperlambat di HP.
     */
    private suspend fun ambilStream(ids: List<String>): Map<String, StreamLagu> = withContext(Dispatchers.IO) {
        val menunggu = HashMap<String, CompletableDeferred<StreamLagu?>>()
        val milikku = HashMap<String, CompletableDeferred<StreamLagu?>>()
        synchronized(sedangDiambil) {
            for (id in ids) {
                val ada = sedangDiambil[id]
                if (ada != null) {
                    menunggu[id] = ada
                } else {
                    val d = CompletableDeferred<StreamLagu?>()
                    sedangDiambil[id] = d
                    milikku[id] = d
                }
            }
        }
        val hasil = HashMap<String, StreamLagu>()
        try {
            if (milikku.isNotEmpty()) hasil.putAll(ambilStreamBaru(milikku.keys.toList()))
        } finally {
            synchronized(sedangDiambil) {
                for ((id, d) in milikku) {
                    sedangDiambil.remove(id)
                    d.complete(hasil[id])
                }
            }
        }
        if (menunggu.isNotEmpty()) Catatan.tulis("Menunggu ${menunggu.size} tautan yang sedang diambil permintaan lain")
        for ((id, d) in menunggu) d.await()?.let { hasil[id] = it }
        hasil
    }

    private suspend fun ambilStreamBaru(ids: List<String>): Map<String, StreamLagu> = withContext(Dispatchers.IO) {
        val hasil = HashMap<String, StreamLagu>()
        // 1) Jalur cepat (HTTP langsung), kecuali sedang dilewati karena gagal berturut-turut
        for (id in ids) {
            if (SystemClock.elapsedRealtime() < lewatiLangsungHingga) {
                Catatan.tulis("Jalur langsung dilewati sementara (gagal berturut-turut)")
                break
            }
            val t0 = SystemClock.elapsedRealtime()
            try {
                hasil[id] = ambilLangsung(id)
                gagalLangsungBerturut = 0
                Catatan.tulis("Stream $id langsung: ${SystemClock.elapsedRealtime() - t0} ms ($jejakLangsung)")
            } catch (e: Exception) {
                alasanGagal = e.message
                Catatan.tulis("Stream langsung gagal ($id, ${SystemClock.elapsedRealtime() - t0} ms): ${e.message} [$jejakLangsung]")
                gagalLangsungBerturut += 1
                if (gagalLangsungBerturut >= 2) {
                    lewatiLangsungHingga = SystemClock.elapsedRealtime() + 10 * 60_000L
                    Catatan.tulis("Jalur langsung dilewati 10 menit; langsung memakai yt-dlp")
                }
            }
        }
        // 2) Cadangan yt-dlp untuk yang belum didapat
        val sisa = ids.filter { it !in hasil }
        if (sisa.isNotEmpty()) hasil.putAll(ambilStreamYtDlp(sisa))
        synchronized(cacheStream) { hasil.forEach { (k, v) -> cacheStream[k] = v } }
        hasil
    }

    private suspend fun ambilStreamYtDlp(ids: List<String>): Map<String, StreamLagu> = withContext(Dispatchers.IO) {
        val hasil = HashMap<String, StreamLagu>()
        // android_vr dulu; bila gagal, klien bawaan yt-dlp.
        for (klien in listOf<String?>("android_vr", null)) {
            val perlu = ids.filter { it !in hasil }
            if (perlu.isEmpty()) break
            val req = YoutubeDLRequest(perlu.map { "https://music.youtube.com/watch?v=$it" }).apply {
                addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                addOption("--no-playlist")
                addOption("--no-warnings")
                if (klien != null) addOption("--extractor-args", "youtube:player_client=$klien")
                addOption("--print", "%(id)s %(urls)s %(http_headers)j")
            }
            val out = try {
                YoutubeDL.getInstance().execute(req, "stream-${System.nanoTime()}") { _, _, _ -> }.out
            } catch (e: Exception) {
                alasanGagal = ringkasError(e)
                Catatan.tulis("Ambil stream yt-dlp gagal (${klien ?: "bawaan"}): ${e.message?.take(300)}")
                continue
            }
            for (baris in out.lineSequence()) {
                val a = baris.indexOf(' ')
                if (a <= 0) continue
                val sisa = baris.substring(a + 1)
                val b = sisa.indexOf(' ')
                val url = (if (b < 0) sisa else sisa.substring(0, b)).trim()
                if (!url.startsWith("http")) continue
                val header = if (b < 0) emptyMap() else bacaHeader(sisa.substring(b + 1))
                hasil[baris.substring(0, a)] = StreamLagu(url, header, batasWaktu(url))
            }
        }
        hasil
    }

    /** Hanya User-Agent yang diteruskan: sebagian tautan menolak User-Agent yang tidak cocok (HTTP 403). */
    private fun bacaHeader(json: String): Map<String, String> = runCatching {
        val ua = JSONObject(json).optString("User-Agent")
        if (ua.isBlank()) emptyMap() else mapOf("User-Agent" to ua)
    }.getOrDefault(emptyMap())

    private fun batasWaktu(url: String): Long {
        val detik = Regex("[?&/]expire[=/](\\d{9,})").find(url)?.groupValues?.get(1)?.toLongOrNull()
        // Sisakan 10 menit supaya tidak memakai tautan yang hampir mati
        return if (detik != null) detik * 1000L - 10 * 60_000L else System.currentTimeMillis() + 30 * 60_000L
    }

    /**
     * Cadangan bila streaming langsung gagal: unduh audionya ke cache lalu putar dari file.
     * Lebih lambat, tetapi memakai jalur yang sama dengan fitur Unduh, sehingga ikut berhasil
     * selama unduhan berhasil. Disimpan maksimal 25 lagu terakhir.
     */
    suspend fun ambilKeCache(context: Context, id: String): File? = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "lagu").apply { mkdirs() }
        fun ada() = dir.listFiles()?.firstOrNull {
            it.name.startsWith("$id.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && it.length() > 0
        }
        ada()?.let { return@withContext it }
        alasanGagal = null
        val t0 = SystemClock.elapsedRealtime()
        val req = YoutubeDLRequest("https://music.youtube.com/watch?v=$id").apply {
            addOption("-f", "bestaudio[ext=m4a]/bestaudio[acodec=aac]/bestaudio/best")
            addOption("--no-playlist")
            addOption("--no-warnings")
            addOption("--concurrent-fragments", "4")
            addOption("-o", "${dir.absolutePath}/$id.%(ext)s")
            Prefs.cookies(context).takeIf { it.exists() }?.let { addOption("--cookies", it.absolutePath) }
        }
        try {
            YoutubeDL.getInstance().execute(req, "cache-$id-${System.nanoTime()}") { _, _, line -> Catatan.tulis(line) }
        } catch (e: Exception) {
            alasanGagal = ringkasError(e)
            Catatan.tulis("Unduh ke cache gagal: ${e.message?.take(300)}")
            return@withContext null
        }
        val f = ada()
        if (f == null) alasanGagal = "file audio tidak dihasilkan"
        Catatan.tulis("Cache $id: ${if (f != null) "siap" else "GAGAL"}, ${SystemClock.elapsedRealtime() - t0} ms")
        dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.drop(25)?.forEach { it.delete() }
        f
    }

    /** Uji cepat untuk halaman Atur: pencarian dan pengambilan tautan, lengkap dengan waktu & alasan gagal. */
    suspend fun diagnosa(context: Context): String = withContext(Dispatchers.IO) {
        val b = StringBuilder()
        var t = SystemClock.elapsedRealtime()
        runCatching { cariLangsung("lofi", false) }
            .onSuccess { b.append("Pencarian: ").append(if (it.isEmpty()) "0 hasil (format respons berubah)" else "OK, ${it.size} hasil") }
            .onFailure { b.append("Pencarian: GAGAL (${it.message?.take(80)})") }
        b.append(" • ${SystemClock.elapsedRealtime() - t} ms\n")

        t = SystemClock.elapsedRealtime()
        val langsung = runCatching { ambilLangsung(TES_ID) }
        b.append("Tautan langsung (tanpa Python): ")
        langsung.onSuccess {
            b.append("OK")
            gagalLangsungBerturut = 0
            lewatiLangsungHingga = 0L
        }.onFailure { b.append("GAGAL (${it.message?.take(100)})") }
        b.append(" • ${SystemClock.elapsedRealtime() - t} ms\n")
        if (jejakLangsung.isNotBlank()) b.append("Rincian: ").append(jejakLangsung).append('\n')

        // yt-dlp hanya diuji bila jalur langsung gagal (butuh beberapa detik)
        if (langsung.isFailure) {
            t = SystemClock.elapsedRealtime()
            alasanGagal = null
            val s = runCatching { ambilStreamYtDlp(listOf(TES_ID))[TES_ID] }.getOrNull()
            b.append("Tautan lewat yt-dlp (cadangan): ")
            if (s != null) b.append("OK") else b.append("GAGAL (${alasanGagal ?: "tanpa tautan"})")
            b.append(" • ${SystemClock.elapsedRealtime() - t} ms\n")
            if (s == null) b.append("Putar online tetap dicoba lewat cache (lebih lambat).\n")
        } else {
            b.append("yt-dlp tidak diperlukan untuk memutar.\n")
        }
        b.toString().trim()
    }

    // ================================================================ GAMBAR

    fun gambarDariCache(url: String): Bitmap? = cacheGambar.get(url)

    /** Blokir: panggil dari thread IO. Hasil disimpan di cache memori agar daftar tidak memuat ulang. */
    fun muatGambar(url: String): Bitmap? {
        cacheGambar.get(url)?.let { return it }
        return runCatching {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 6000
                c.readTimeout = 6000
                val bytes = c.inputStream.use { it.readBytes() }
                val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, batas)
                var s = 1
                while (batas.outWidth / s > 512) s *= 2
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            } finally {
                c.disconnect()
            }
        }.getOrNull()?.also { cacheGambar.put(url, it) }
    }
}
