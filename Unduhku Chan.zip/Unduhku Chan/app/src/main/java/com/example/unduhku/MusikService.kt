package com.example.unduhku

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Notifikasi pemutar musik: sampul album, judul, artis, dan tombol Sebelumnya / Putar-Jeda /
 * Berikutnya / Tutup. Memakai MediaSession platform (tanpa library tambahan), sehingga tombol
 * yang sama juga muncul di layar kunci, kontrol media sistem, dan headset Bluetooth.
 * Musiknya sendiri dijalankan oleh [Pemutar]; service ini hanya menjaga proses tetap hidup
 * selama musik diputar dan menampilkan kontrolnya.
 */
class MusikService : Service() {

    private val pemutar by lazy { Pemutar.get(applicationContext) }
    private lateinit var sesi: MediaSession
    private var sedangForeground = false
    private var menutup = false
    private var kunciMeta: String? = null
    private val dengar: () -> Unit = { segarkan() }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Headset dicabut / Bluetooth putus: jeda supaya suara tidak tiba-tiba keluar dari speaker.
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pemutar.jeda()
        }
    }

    private val bukaApp: PendingIntent by lazy {
        PendingIntent.getActivity(
            this, 20,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EKSTRA_TAB, MainActivity.TAB_PUTAR),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
    private val piSebelumnya: PendingIntent by lazy { pendingAksi(AKSI_SEBELUMNYA, 21) }
    private val piToggle: PendingIntent by lazy { pendingAksi(AKSI_TOGGLE, 22) }
    private val piBerikut: PendingIntent by lazy { pendingAksi(AKSI_BERIKUT, 23) }
    private val piTutup: PendingIntent by lazy { pendingAksi(AKSI_TUTUP, 24) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        berjalan = true
        buatKanal()
        sesi = MediaSession(this, "Unduhku").apply {
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!pemutar.sedangMain) pemutar.toggle() }
                override fun onPause() { pemutar.jeda() }
                override fun onSkipToNext() { pemutar.berikut() }
                override fun onSkipToPrevious() { pemutar.sebelumnya() }
                override fun onSeekTo(pos: Long) { pemutar.seek(pos.toInt()) }
                override fun onStop() { pemutar.hentikan() }
            })
            isActive = true
        }
        ContextCompat.registerReceiver(
            this, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        pemutar.dengar(dengar)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Setelah startForegroundService(), startForeground() wajib segera dipanggil.
        jadikanForeground(bangunNotif())
        when (intent?.action) {
            AKSI_TOGGLE -> pemutar.toggle()
            AKSI_BERIKUT -> pemutar.berikut()
            AKSI_SEBELUMNYA -> pemutar.sebelumnya()
            AKSI_TUTUP -> { pemutar.hentikan(); tutup() }
            else -> segarkan()
        }
        // Proses sempat mati lalu tombol notifikasi lama ditekan: pemutar kosong, jadi tidak ada
        // yang akan menutup notifikasi ini. Tutup di sini.
        if (!menutup && !pemutar.aktif) tutup()
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Aplikasi digeser dari daftar recent: musik yang sedang jalan tetap lanjut, selain itu bersihkan.
        if (!pemutar.sedangMain) pemutar.hentikan()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        berjalan = false
        pemutar.lepasDengar(dengar)
        runCatching { unregisterReceiver(noisy) }
        runCatching { sesi.release() }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pembaruan

    private fun segarkan() {
        if (menutup) return
        if (!pemutar.aktif) { tutup(); return }
        perbaruiSesi()
        val n = bangunNotif()
        if (pemutar.sedangMain || pemutar.menyiapkan) {
            jadikanForeground(n)
        } else {
            // Dijeda: lepaskan status foreground (notifikasi tetap tampil dan bisa digeser untuk menutup).
            if (sedangForeground) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
                sedangForeground = false
            }
            runCatching { getSystemService(NotificationManager::class.java).notify(ID_NOTIF, n) }
        }
    }

    private fun jadikanForeground(n: Notification) {
        try {
            val tipe = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            ServiceCompat.startForeground(this, ID_NOTIF, n, tipe)
            sedangForeground = true
        } catch (e: Exception) {
            Catatan.tulis("Notifikasi musik tidak bisa jadi foreground: ${e.message}")
            runCatching { getSystemService(NotificationManager::class.java).notify(ID_NOTIF, n) }
        }
    }

    private fun tutup() {
        if (menutup) return
        menutup = true
        berjalan = false
        pemutar.lepasDengar(dengar)
        runCatching { sesi.isActive = false }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        runCatching { getSystemService(NotificationManager::class.java).cancel(ID_NOTIF) }
        sedangForeground = false
        stopSelf()
    }

    private fun perbaruiSesi() {
        val p = pemutar
        val kunci = "${p.judul}|${p.artis}|${p.durasi}|${p.sampul?.hashCode()}"
        if (kunci != kunciMeta) {
            kunciMeta = kunci
            sesi.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, p.judul)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, p.artis ?: getString(R.string.app_name))
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, p.durasi.toLong())
                    .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, p.sampul ?: Sampul.bawaan(this))
                    .build()
            )
        }
        val status = when {
            p.menyiapkan -> PlaybackState.STATE_BUFFERING
            p.sedangMain -> PlaybackState.STATE_PLAYING
            else -> PlaybackState.STATE_PAUSED
        }
        sesi.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                        PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
                )
                .setState(
                    status, p.posisi.toLong(),
                    if (status == PlaybackState.STATE_PLAYING) 1f else 0f,
                    SystemClock.elapsedRealtime()
                )
                .build()
        )
    }

    // ------------------------------------------------------------------ notifikasi

    private fun buatKanal() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(KANAL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(KANAL, "Pemutar musik", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Kontrol musik yang sedang diputar"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun bangunNotif(): Notification {
        val p = pemutar
        val main = p.sedangMain || p.menyiapkan
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, KANAL)
        else Notification.Builder(this)

        b.setSmallIcon(R.drawable.ic_music)
            .setContentTitle(p.judul)
            .setContentText(p.artis ?: getString(R.string.app_tagline))
            .setLargeIcon(p.sampul ?: Sampul.bawaan(this))
            .setContentIntent(bukaApp)
            .setDeleteIntent(piTutup)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(main)
            .setColor(ContextCompat.getColor(this, R.color.primary_container))
        if (p.indeks >= 0 && p.daftar.isNotEmpty()) b.setSubText("${p.indeks + 1} / ${p.daftar.size}")

        b.addAction(aksi(R.drawable.ic_prev, "Sebelumnya", piSebelumnya))
        b.addAction(aksi(if (main) R.drawable.ic_pause else R.drawable.ic_play, if (main) "Jeda" else "Putar", piToggle))
        b.addAction(aksi(R.drawable.ic_next, "Berikutnya", piBerikut))
        b.addAction(aksi(R.drawable.ic_close, "Tutup", piTutup))
        b.setStyle(
            Notification.MediaStyle()
                .setMediaSession(sesi.sessionToken)
                .setShowActionsInCompactView(0, 1, 2)
        )
        return b.build()
    }

    private fun aksi(ikon: Int, judul: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, ikon), judul, pi).build()

    private fun pendingAksi(kode: String, kodeReq: Int): PendingIntent {
        val i = Intent(this, MusikService::class.java).setAction(kode)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, kodeReq, i, flags)
        else PendingIntent.getService(this, kodeReq, i, flags)
    }

    companion object {
        private const val KANAL = "musik"
        private const val ID_NOTIF = 3
        private const val AKSI_TOGGLE = "com.example.unduhku.musik.TOGGLE"
        private const val AKSI_BERIKUT = "com.example.unduhku.musik.BERIKUT"
        private const val AKSI_SEBELUMNYA = "com.example.unduhku.musik.SEBELUMNYA"
        private const val AKSI_TUTUP = "com.example.unduhku.musik.TUTUP"

        @Volatile private var berjalan = false

        /** Pastikan service (dan notifikasinya) aktif; tidak berbuat apa-apa bila sudah berjalan. */
        fun mulai(context: Context) {
            if (berjalan) return
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, MusikService::class.java))
            }.onFailure { Catatan.tulis("Gagal memulai notifikasi musik: ${it.message}") }
        }
    }
}
