package com.example.unduhku

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log ringan untuk diagnosa. Baris progres "[download] xx%" tidak dicatat agar file tetap kecil. */
object Catatan {
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun init(context: Context) {
        val f = File(context.filesDir, "log.txt")
        file = f
        if (f.length() > 120_000) runCatching { f.writeText(f.readText().takeLast(40_000)) }
    }

    @Synchronized
    fun tulis(pesan: String) {
        val f = file ?: return
        if (pesan.contains("[download]") && pesan.contains('%')) return
        runCatching { f.appendText("${fmt.format(Date())} $pesan\n") }
    }

    @Synchronized
    fun baca(): String =
        file?.takeIf { it.exists() }?.readText().orEmpty().ifBlank { "(log kosong)" }

    @Synchronized
    fun hapus() { file?.delete() }
}
