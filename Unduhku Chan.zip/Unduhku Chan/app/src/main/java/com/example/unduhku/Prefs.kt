package com.example.unduhku

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(context: Context) {
    private val app = context.applicationContext
    private val sp: SharedPreferences = app.getSharedPreferences("unduhku", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) =
            sp.edit().putBoolean(key, value).apply()
    }

    private fun int(key: String, def: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) =
            sp.edit().putInt(key, value).apply()
    }

    var folderUri: String?
        get() = sp.getString("folder_uri", null)
        set(v) = sp.edit().putString("folder_uri", v).apply()

    var wifiOnly by bool("wifi_only", false)
    var lewatiDuplikat by bool("lewati_duplikat", true)
    var cover by bool("cover", true)
    var sponsor by bool("sponsor", false)
    var subtitle by bool("subtitle", false)
    var folderPerKanal by bool("folder_kanal", false)
    var penamaan by int("penamaan", 0)
    var batas by int("batas", 0)
    var pernahMintaNotif by bool("minta_notif", false)
    var cekOtomatis by bool("cek_update", true)

    var cekTerakhir: Long
        get() = sp.getLong("cek_terakhir", 0L)
        set(v) = sp.edit().putLong("cek_terakhir", v).apply()
    var etag: String?
        get() = sp.getString("etag", null)
        set(v) = sp.edit().putString("etag", v).apply()
    var rilisCache: String?
        get() = sp.getString("rilis_cache", null)
        set(v) = sp.edit().putString("rilis_cache", v).apply()
    var lewatiVersi: String?
        get() = sp.getString("lewati_versi", null)
        set(v) = sp.edit().putString("lewati_versi", v).apply()

    fun batasArg(): String? = listOf(null, "500K", "1M", "2M").getOrNull(batas)

    companion object {
        val PILIHAN_PENAMAAN = listOf("Judul", "Channel - Judul")
        val PILIHAN_BATAS = listOf("Tanpa batas", "500 KB/s", "1 MB/s", "2 MB/s")
        fun cookies(c: Context) = File(c.filesDir, "cookies.txt")
        fun arsip(c: Context, f: FormatUnduh) = File(c.filesDir, "arsip_${f.name.lowercase()}.txt")
        fun latar(c: Context) = File(c.filesDir, "latar.webp")
    }
}

data class Entri(
    val judul: String,
    val nama: String,
    val label: String,
    val ukuran: Long,
    val waktu: Long,
    val uri: String,
    val sumber: String = ""
)

/** Riwayat unduhan: satu file JSON kecil, dibatasi 300 entri terbaru. */
class Riwayat private constructor(context: Context) {
    private val file = File(context.filesDir, "riwayat.json")
    private val data: MutableList<Entri> = muat()

    private fun muat(): MutableList<Entri> {
        val hasil = mutableListOf<Entri>()
        runCatching {
            if (!file.exists()) return@runCatching
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                hasil += Entri(
                    o.optString("j"), o.optString("n"), o.optString("l"),
                    o.optLong("u"), o.optLong("w"), o.optString("r"), o.optString("s")
                )
            }
        }
        return hasil
    }

    private fun simpan() {
        val arr = JSONArray()
        data.forEach {
            arr.put(
                JSONObject().put("j", it.judul).put("n", it.nama).put("l", it.label)
                    .put("u", it.ukuran).put("w", it.waktu).put("r", it.uri).put("s", it.sumber)
            )
        }
        // Tulis ke file sementara lalu ganti nama: riwayat tidak rusak bila proses mati saat menulis.
        runCatching {
            val sementara = File(file.parentFile, "riwayat.json.tmp")
            sementara.writeText(arr.toString())
            if (!sementara.renameTo(file)) { file.delete(); sementara.renameTo(file) }
        }
    }

    @Synchronized fun semua(): List<Entri> = data.toList()

    @Synchronized fun tambah(e: Entri) {
        data.add(0, e)
        while (data.size > 300) data.removeAt(data.lastIndex)
        simpan()
    }

    @Synchronized fun tambahBanyak(daftar: List<Entri>) {
        if (daftar.isEmpty()) return
        data.addAll(0, daftar.asReversed())
        while (data.size > 300) data.removeAt(data.lastIndex)
        simpan()
    }

    @Synchronized fun hapus(e: Entri) { data.remove(e); simpan() }
    @Synchronized fun kosongkan() { data.clear(); simpan() }

    companion object {
        @Volatile private var instance: Riwayat? = null
        fun get(c: Context): Riwayat = instance ?: synchronized(this) {
            instance ?: Riwayat(c.applicationContext).also { instance = it }
        }
    }
}
