package com.example.unduhku

import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class StatusAntrian(
    val aktif: Tugas? = null,
    val persen: Int = -1,
    val tahap: String = "",
    val antre: List<Tugas> = emptyList(),
    val terjeda: List<Tugas> = emptyList(),
    val sukses: Int = 0,
    val gagal: Int = 0,
    val pesan: String? = null,
    val pesanSukses: Boolean? = null,
    val gagalTerakhir: Tugas? = null
)

/** Antrean unduhan di dalam proses: dibaca UI (StateFlow), dijalankan DownloadService. */
object AntrianUnduh {
    const val TIDAK = 0
    const val BATAL = 1
    const val JEDA = 2

    @Volatile var permintaan = TIDAK
        private set

    private val _status = MutableStateFlow(StatusAntrian())
    val status: StateFlow<StatusAntrian> = _status

    fun tambah(daftar: List<Tugas>) = _status.update { s ->
        val baru = s.aktif == null && s.antre.isEmpty()
        s.copy(
            antre = s.antre + daftar,
            sukses = if (baru) 0 else s.sukses,
            gagal = if (baru) 0 else s.gagal,
            pesan = null, pesanSukses = null, gagalTerakhir = null
        )
    }

    fun ambilBerikut(): Tugas? {
        var diambil: Tugas? = null
        _status.update { s ->
            diambil = s.antre.firstOrNull()
            if (diambil == null) s
            else s.copy(antre = s.antre.drop(1), aktif = diambil, persen = -1, tahap = "Mengunduh")
        }
        if (diambil != null) permintaan = TIDAK
        return diambil
    }

    fun adaAntrean() = _status.value.antre.isNotEmpty()
    fun setProgress(p: Int) = _status.update { it.copy(persen = p) }
    fun setTahap(t: String, persen: Int = -1) = _status.update { it.copy(tahap = t, persen = persen) }

    fun selesai(berhasil: Boolean, pesan: String, tugas: Tugas? = null) = _status.update { s ->
        s.copy(
            aktif = null, persen = -1, pesan = pesan, pesanSukses = berhasil,
            gagalTerakhir = if (berhasil) s.gagalTerakhir else tugas,
            sukses = s.sukses + if (berhasil) 1 else 0,
            gagal = s.gagal + if (berhasil) 0 else 1
        )
    }

    fun selesaiTanpaHitung(pesan: String) = _status.update {
        it.copy(aktif = null, persen = -1, pesan = pesan, pesanSukses = null)
    }

    fun terjeda(t: Tugas) = _status.update {
        it.copy(aktif = null, persen = -1, terjeda = it.terjeda + t, pesan = "Dijeda: ${t.judul}", pesanSukses = null)
    }

    fun hapusGagal() = _status.update { it.copy(gagalTerakhir = null) }
    fun lanjutkan() = _status.update { it.copy(antre = it.terjeda + it.antre, terjeda = emptyList(), pesan = null) }
    fun kosongkanAntre() = _status.update { it.copy(antre = emptyList(), terjeda = emptyList()) }

    /** Hentikan unduhan aktif: matikan proses yt-dlp-nya. */
    fun hentikanAktif(jeda: Boolean) {
        val id = _status.value.aktif?.id ?: return
        permintaan = if (jeda) JEDA else BATAL
        runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
    }
}
