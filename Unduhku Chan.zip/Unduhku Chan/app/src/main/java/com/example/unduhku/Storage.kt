package com.example.unduhku

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

class Storage(private val context: Context) {
    
    fun simpanKeLokasiPilihan(fileSementara: File, uriFolderTujuan: Uri): Boolean {
        return try {
            val pickedDir = DocumentFile.fromTreeUri(context, uriFolderTujuan)
            val tipeMime = if (fileSementara.name.endsWith(".mp3", true)) "audio/mpeg" else "video/mp4"
            
            val fileBaru = pickedDir?.createFile(tipeMime, fileSementara.name)
            
            fileBaru?.let { docFile ->
                context.contentResolver.openOutputStream(docFile.uri)?.use { outputStream ->
                    fileSementara.inputStream().use { inputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                fileSementara.delete()
                true
            } ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}