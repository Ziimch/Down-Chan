package com.example.unduhku

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File

class Storage(private val context: Context) {

    /** Salin file ke folder pilihan (SAF), opsional ke subfolder. Mengembalikan Uri hasil. */
    fun simpan(file: File, tree: Uri, subfolder: List<String> = emptyList()): Uri? {
        return try {
            var dir = DocumentFile.fromTreeUri(context, tree) ?: return null
            for (nama in subfolder) {
                dir = dir.findFile(nama)?.takeIf { it.isDirectory }
                    ?: dir.createDirectory(nama) ?: return null
            }
            val baru = dir.createFile(tipeMime(file), file.name) ?: return null
            context.contentResolver.openOutputStream(baru.uri)?.use { out ->
                file.inputStream().buffered(BUFFER).use { it.copyTo(out, BUFFER) }
            } ?: return null
            file.delete()
            baru.uri
        } catch (e: Exception) {
            Catatan.tulis("Gagal menyimpan ${file.name}: ${e.message}")
            null
        }
    }

    fun tipeMime(file: File): String = when (file.extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "gif" -> "image/gif"
        "pdf" -> "application/pdf"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
            ?: "application/octet-stream"
    }

    companion object {
        const val BUFFER = 64 * 1024
    }
}
