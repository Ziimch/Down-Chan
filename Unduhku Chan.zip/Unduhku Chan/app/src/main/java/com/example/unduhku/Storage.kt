package com.example.unduhku

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File

class Storage(private val context: Context) {

    /** Salin file ke folder pilihan (SAF), opsional ke subfolder. Mengembalikan Uri hasil. */
    fun simpan(file: File, tree: Uri, subfolder: List<String> = emptyList()): Uri? {
        var baru: DocumentFile? = null
        return try {
            var dir = DocumentFile.fromTreeUri(context, tree) ?: return null
            for (nama in subfolder) {
                dir = dir.findFile(nama)?.takeIf { it.isDirectory }
                    ?: dir.createDirectory(nama) ?: return null
            }
            val tujuan = dir.createFile(tipeMime(file), file.name) ?: return null
            baru = tujuan
            val out = context.contentResolver.openOutputStream(tujuan.uri)
                ?: throw java.io.IOException("Tidak bisa menulis ke folder tujuan")
            out.use { file.inputStream().buffered(BUFFER).use { input -> input.copyTo(it, BUFFER) } }
            file.delete()
            tujuan.uri
        } catch (e: Exception) {
            Catatan.tulis("Gagal menyimpan ${file.name}: ${e.message}")
            // Jangan tinggalkan file setengah jadi / kosong di folder pengguna.
            runCatching { baru?.delete() }
            null
        }
    }

    fun tipeMime(file: File): String = when (file.extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "gif" -> "image/gif"
        "pdf" -> "application/pdf"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
            ?: "application/octet-stream"
    }

    companion object {
        const val BUFFER = 64 * 1024
    }
}
