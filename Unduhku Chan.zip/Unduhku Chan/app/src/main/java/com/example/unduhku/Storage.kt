package com.example.unduhku

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File

class Storage(private val context: Context) {

    /** Salin file sementara ke folder pilihan (SAF) lalu hapus file sementaranya. */
    fun simpanKeLokasiPilihan(fileSementara: File, uriFolderTujuan: Uri): Boolean {
        return try {
            val folder = DocumentFile.fromTreeUri(context, uriFolderTujuan) ?: return false
            val fileBaru = folder.createFile(tipeMime(fileSementara), fileSementara.name) ?: return false

            context.contentResolver.openOutputStream(fileBaru.uri)?.use { output ->
                fileSementara.inputStream().buffered(BUFFER).use { input ->
                    input.copyTo(output, BUFFER)
                }
            } ?: return false

            fileSementara.delete()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun tipeMime(file: File): String = when (file.extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        else -> MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase())
            ?: "application/octet-stream"
    }

    private companion object {
        const val BUFFER = 64 * 1024
    }
}
