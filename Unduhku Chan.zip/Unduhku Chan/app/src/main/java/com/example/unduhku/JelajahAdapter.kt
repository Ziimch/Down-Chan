package com.example.unduhku

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private object PembandingLagu : DiffUtil.ItemCallback<HasilLagu>() {
    override fun areItemsTheSame(a: HasilLagu, b: HasilLagu) = a.id == b.id
    override fun areContentsTheSame(a: HasilLagu, b: HasilLagu) = a == b
}

/** Daftar hasil pencarian: ketuk = putar, ikon unduh = masuk antrean unduhan. */
class JelajahAdapter(
    private val scope: CoroutineScope,
    private val onPutar: (Int) -> Unit,
    private val onUnduh: (HasilLagu) -> Unit
) : ListAdapter<HasilLagu, JelajahAdapter.VH>(PembandingLagu) {

    class VH(val root: View) : RecyclerView.ViewHolder(root) {
        val sampul: ImageView = root.findViewById(R.id.imgLaguO)
        val judul: TextView = root.findViewById(R.id.tvJudulO)
        val meta: TextView = root.findViewById(R.id.tvMetaO)
        val unduh: ImageButton = root.findViewById(R.id.btnUnduhO)
        var url: String? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_lagu_online, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val l = getItem(position)
        h.judul.text = l.judul
        h.meta.text = listOf(l.artis, if (l.durasi > 0) formatDurasi(l.durasi) else "")
            .filter { it.isNotBlank() }.joinToString(" • ")

        val url = l.thumb
        h.url = url
        h.sampul.setImageDrawable(null)
        if (url != null) {
            val cache = Jelajah.gambarDariCache(url)
            if (cache != null) h.sampul.setImageBitmap(cache)
            else scope.launch {
                val bmp = withContext(Dispatchers.IO) { Jelajah.muatGambar(url) }
                // Baris ini mungkin sudah dipakai ulang untuk lagu lain saat gambar selesai dimuat
                if (bmp != null && h.url == url) h.sampul.setImageBitmap(bmp)
            }
        }

        h.root.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onPutar(p)
        }
        h.unduh.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onUnduh(getItem(p))
        }
    }
}
