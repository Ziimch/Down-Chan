package com.example.unduhku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class FormatGambar(val ekstensi: String) { JPG("jpg"), PNG("png"), WEBP("webp") }
enum class FormatAudio(val ekstensi: String) { MP3("mp3"), M4A("m4a") }

class Converter(private val context: Context) {

    private val storage = Storage(context)

    @Volatile
    private var dibatalkan = false

    // ================= Gambar (Bitmap bawaan Android) =================

    suspend fun gambar(
        sumber: Uri, namaAsli: String, folder: Uri,
        target: FormatGambar, skala: Float = 1f, kualitas: Int = 92
    ): HasilKonversi = withContext(Dispatchers.IO) {
        val kerja = siapkanKerja()
        try {
            val mentah = decode(sumber)
                ?: return@withContext HasilKonversi.Gagal(context.getString(R.string.error_gambar_gagal_dibaca))
            var bmp = putarSesuaiExif(sumber, mentah)
            if (skala < 1f) {
                val kecil = Bitmap.createScaledBitmap(
                    bmp, (bmp.width * skala).toInt().coerceAtLeast(1), (bmp.height * skala).toInt().coerceAtLeast(1), true
                )
                if (kecil !== bmp) bmp.recycle()
                bmp = kecil
            }
            // JPG tidak punya transparansi: latar transparan diganti putih, bukan hitam.
            val siap = if (target == FormatGambar.JPG) keLatarPutih(bmp) else bmp

            val keluar = File(kerja, "${namaDasar(namaAsli)}.${target.ekstensi}")
            keluar.outputStream().buffered(Storage.BUFFER).use { out ->
                siap.compress(formatCompress(target), if (target == FormatGambar.PNG) 100 else kualitas, out)
            }
            selesaiSimpan(keluar, folder)
        } catch (e: OutOfMemoryError) {
            HasilKonversi.Gagal(context.getString(R.string.error_gambar_terlalu_besar))
        } catch (e: Exception) {
            HasilKonversi.Gagal(e.message ?: e.javaClass.simpleName)
        } finally {
            kerja.parentFile?.deleteRecursively()
        }
    }

    suspend fun gambarKePdf(daftar: List<Pair<Uri, String>>, folder: Uri): HasilKonversi =
        withContext(Dispatchers.IO) {
            val kerja = siapkanKerja()
            val pdf = PdfDocument()
            try {
                var halaman = 0
                for ((uri, _) in daftar) {
                    // Batasi sisi terpanjang: PDF tetap ringan dan memori aman untuk foto besar.
                    val mentah = decodeKecil(uri, 1600) ?: continue
                    val bmp = putarSesuaiExif(uri, mentah)
                    // Lebar halaman dibakukan ke A4 (595 pt) dan tinggi mengikuti proporsi gambar;
                    // sebelumnya ukuran halaman = jumlah piksel sehingga PDF terbuka sebesar poster.
                    val lebarHal = 595
                    val tinggiHal = (bmp.height * lebarHal.toFloat() / bmp.width).toInt().coerceAtLeast(1)
                    val info = PdfDocument.PageInfo.Builder(lebarHal, tinggiHal, ++halaman).create()
                    val page = pdf.startPage(info)
                    page.canvas.drawColor(Color.WHITE)
                    page.canvas.drawBitmap(bmp, null, Rect(0, 0, lebarHal, tinggiHal), Paint(Paint.FILTER_BITMAP_FLAG))
                    pdf.finishPage(page)
                    bmp.recycle()
                }
                if (halaman == 0) {
                    return@withContext HasilKonversi.Gagal(context.getString(R.string.error_gambar_gagal_dibaca))
                }
                val keluar = File(kerja, "${namaDasar(daftar.first().second)}.pdf")
                keluar.outputStream().buffered(Storage.BUFFER).use { pdf.writeTo(it) }
                selesaiSimpan(keluar, folder)
            } catch (e: OutOfMemoryError) {
                HasilKonversi.Gagal(context.getString(R.string.error_gambar_terlalu_besar))
            } catch (e: Exception) {
                HasilKonversi.Gagal(e.message ?: e.javaClass.simpleName)
            } finally {
                pdf.close()
                kerja.parentFile?.deleteRecursively()
            }
        }

    private fun decode(uri: Uri): Bitmap? = try {
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    } catch (e: OutOfMemoryError) {
        decodeKecil(uri, 3000)
    }

    fun decodeKecil(uri: Uri, maksSisi: Int): Bitmap? {
        val r = context.contentResolver
        val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        r.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, batas) }
        var s = 1
        while (maxOf(batas.outWidth, batas.outHeight) / s > maksSisi * 2) s *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = r.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val sisi = maxOf(bmp.width, bmp.height)
        if (sisi <= maksSisi) return bmp
        val f = maksSisi.toFloat() / sisi
        val kecil = Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true)
        if (kecil !== bmp) bmp.recycle()
        return kecil
    }

    private fun formatCompress(t: FormatGambar): Bitmap.CompressFormat = when (t) {
        FormatGambar.JPG -> Bitmap.CompressFormat.JPEG
        FormatGambar.PNG -> Bitmap.CompressFormat.PNG
        FormatGambar.WEBP ->
            if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
            else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
    }

    private fun keLatarPutih(src: Bitmap): Bitmap {
        val hasil = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(hasil).apply { drawColor(Color.WHITE); drawBitmap(src, 0f, 0f, null) }
        return hasil
    }

    /** Foto kamera sering menyimpan rotasi di EXIF; tanpa ini hasil bisa miring. */
    private fun putarSesuaiExif(sumber: Uri, bitmap: Bitmap): Bitmap {
        val orientasi = runCatching {
            context.contentResolver.openInputStream(sumber)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val derajat = when (orientasi) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> return bitmap
        }
        val m = Matrix().apply { postRotate(derajat) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
    }

    // ================= Video/audio lewat yt-dlp + ffmpeg bawaan =================

    suspend fun keAudio(
        sumber: Uri, nama: String, folder: Uri, target: FormatAudio,
        efek: Efek, mulai: String?, akhir: String?, id: String
    ): HasilKonversi {
        val args = buildList {
            if (mulai != null) add("-ss $mulai")
            if (akhir != null) add("-to $akhir")
            efek.filter?.let { add("-af $it") }
        }.joinToString(" ")
        return lewatYtDlp(sumber, bersihkanNamaFile(nama), folder, id, setOf(target.ekstensi)) { url, keluar ->
            listOf(dasar(url, keluar).apply {
                addOption("-x")
                addOption("--audio-format", target.ekstensi)
                addOption("--audio-quality", "192K")
                if (args.isNotBlank()) addOption("--postprocessor-args", "ExtractAudio:$args")
            })
        }
    }

    suspend fun kompresVideo(sumber: Uri, nama: String, folder: Uri, tinggi: Int, id: String): HasilKonversi {
        val crf = when (tinggi) { 720 -> 28; 480 -> 29; else -> 30 }
        // Sumber diberi ekstensi .mkv supaya yt-dlp tidak melewati "recode" karena sudah mp4.
        return lewatYtDlp(sumber, namaDasar(nama) + ".mkv", folder, id, setOf("mp4")) { url, keluar ->
            fun req(v: String, vf: String) = dasar(url, keluar).apply {
                addOption("--recode-video", "mp4")
                // -sn: buang subtitle (sering tidak kompatibel dengan mp4)
                addOption("--postprocessor-args", "VideoConvertor:$v -vf $vf -sn -c:a aac -b:a 96k")
            }
            // Tidak memperbesar video yang sudah lebih kecil, dan tinggi dijaga genap (syarat x264).
            // Dua backslash = koma ter-escape untuk ffmpeg setelah melewati pemecah argumen yt-dlp.
            val hemat = "scale=-2:trunc(min(ih\\\\,$tinggi)/2)*2"
            val polos = "scale=-2:$tinggi"
            // Cadangan berlapis: ekspresi gagal -> skala polos; libx264 tak ada -> encoder mpeg4.
            listOf(
                req("-c:v libx264 -preset veryfast -crf $crf", hemat),
                req("-c:v libx264 -preset veryfast -crf $crf", polos),
                req("-c:v mpeg4 -q:v 7", polos)
            )
        }
    }

    suspend fun keGif(
        sumber: Uri, nama: String, folder: Uri, lebar: Int,
        mulai: String?, akhir: String?, id: String
    ): HasilKonversi {
        val potong = buildList {
            if (mulai != null) add("-ss $mulai")
            if (akhir != null) add("-to $akhir") else add("-t 15")
        }.joinToString(" ")
        return lewatYtDlp(sumber, bersihkanNamaFile(nama), folder, id, setOf("gif")) { url, keluar ->
            fun req(vf: String) = dasar(url, keluar).apply {
                addOption("--recode-video", "gif")
                // -an/-sn: GIF tak punya audio/subtitle; stream itu bisa membuat ffmpeg gagal menulis GIF.
                addOption("--postprocessor-args", "VideoConvertor:$potong -an -sn -vf $vf")
            }
            val dasarVf = "fps=12,scale=$lebar:-1:flags=lanczos"
            // Palet khusus membuat warna GIF jauh lebih halus; polos jadi cadangan.
            listOf(
                req("$dasarVf,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3"),
                req(dasarVf)
            )
        }
    }

    private fun dasar(url: String, keluar: File) = YoutubeDLRequest(url).apply {
        addOption("--enable-file-urls")
        addOption("-o", "${keluar.absolutePath}/%(title).150s.%(ext)s")
        addOption("--no-playlist")
        addOption("--no-mtime")
    }

    private suspend fun lewatYtDlp(
        sumber: Uri, namaMasuk: String, folder: Uri, id: String,
        ekstensiKeluar: Set<String>,
        buat: (url: String, keluar: File) -> List<YoutubeDLRequest>
    ): HasilKonversi = withContext(Dispatchers.IO) {
        val kerja = siapkanKerja()
        val masuk = File(kerja, "masuk").apply { mkdirs() }
        val keluar = File(kerja, "keluar").apply { mkdirs() }
        try {
            // yt-dlp butuh path file sungguhan, jadi salin dulu dari SAF ke cache.
            val salinan = File(masuk, bersihkanNamaFile(namaMasuk))
            context.contentResolver.openInputStream(sumber)?.use { input ->
                salinan.outputStream().buffered(Storage.BUFFER).use { out -> input.copyTo(out, Storage.BUFFER) }
            } ?: return@withContext HasilKonversi.Gagal(context.getString(R.string.error_gambar_gagal_dibaca))

            var galat: Exception? = null
            for (req in buat(Uri.fromFile(salinan).toString(), keluar)) {
                try {
                    YoutubeDL.getInstance().execute(req, id) { _, _, line -> Catatan.tulis(line) }
                    galat = null
                    break
                } catch (e: Exception) {
                    galat = e
                    Catatan.tulis("Konversi gagal: ${e.message?.take(600)}")
                    if (dibatalkan) break
                    keluar.listFiles()?.forEach { it.deleteRecursively() }
                }
            }
            if (dibatalkan) return@withContext HasilKonversi.Dibatalkan
            galat?.let { return@withContext HasilKonversi.Gagal(ringkasError(it)) }

            val hasil = keluar.listFiles()
                ?.filter { it.isFile && it.extension.lowercase() in ekstensiKeluar }
                ?.firstOrNull()
                ?: return@withContext HasilKonversi.Gagal(context.getString(R.string.error_tidak_ada_file))
            selesaiSimpan(hasil, folder)
        } catch (e: Exception) {
            if (dibatalkan) HasilKonversi.Dibatalkan else HasilKonversi.Gagal(ringkasError(e))
        } finally {
            kerja.parentFile?.deleteRecursively()
        }
    }

    /** Panggil sebelum memulai rangkaian konversi baru. */
    fun reset() { dibatalkan = false }

    fun batalkan(id: String) {
        dibatalkan = true
        runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
    }

    // ================= util =================

    private fun selesaiSimpan(file: File, folder: Uri): HasilKonversi {
        val ukuran = file.length()
        val nama = file.name
        val uri = storage.simpan(file, folder)
        return if (uri != null) HasilKonversi.Sukses(nama, uri, ukuran)
        else HasilKonversi.Gagal(context.getString(R.string.error_gagal_simpan))
    }

    /** Folder kerja unik: cache/konversi/<angka>/ ; induknya dihapus saat selesai. */
    private fun siapkanKerja(): File {
        val akar = File(context.cacheDir, "konversi")
        return File(akar, System.nanoTime().toString()).also { it.mkdirs() }
    }
}
