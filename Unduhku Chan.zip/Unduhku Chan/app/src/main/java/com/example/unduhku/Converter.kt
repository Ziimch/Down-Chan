package com.example.unduhku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class FormatGambar(val ekstensi: String) { JPG("jpg"), PNG("png"), WEBP("webp") }
enum class FormatAudio(val ekstensi: String) { MP3("mp3"), M4A("m4a") }

sealed interface HasilKonversi {
    data class Sukses(val namaFile: String) : HasilKonversi
    data class Gagal(val pesan: String) : HasilKonversi
    data object Dibatalkan : HasilKonversi
}

class Converter(private val context: Context) {

    private val storage = Storage(context)

    @Volatile
    private var dibatalkan = false

    // ---------- Gambar: pakai Bitmap bawaan Android, tanpa library tambahan ----------

    suspend fun konversiGambar(
        sumber: Uri,
        namaAsli: String,
        folder: Uri,
        target: FormatGambar
    ): HasilKonversi = withContext(Dispatchers.IO) {
        val kerja = siapkanKerja()
        try {
            val resolver = context.contentResolver
            val mentah = resolver.openInputStream(sumber)?.use { BitmapFactory.decodeStream(it) }
                ?: return@withContext HasilKonversi.Gagal(
                    context.getString(R.string.error_gambar_gagal_dibaca)
                )

            val diputar = putarSesuaiExif(sumber, mentah)
            // JPG tidak punya transparansi: latar transparan PNG diganti putih, bukan hitam.
            val siap = if (target == FormatGambar.JPG) keLatarPutih(diputar) else diputar

            val keluar = File(kerja, "${namaDasar(namaAsli)}.${target.ekstensi}")
            keluar.outputStream().buffered(BUFFER).use { out ->
                siap.compress(formatCompress(target), if (target == FormatGambar.PNG) 100 else 92, out)
            }

            if (storage.simpanKeLokasiPilihan(keluar, folder)) {
                HasilKonversi.Sukses(keluar.name)
            } else {
                HasilKonversi.Gagal(context.getString(R.string.error_gagal_simpan))
            }
        } catch (e: OutOfMemoryError) {
            HasilKonversi.Gagal(context.getString(R.string.error_gambar_terlalu_besar))
        } catch (e: Exception) {
            HasilKonversi.Gagal(e.message ?: e.javaClass.simpleName)
        } finally {
            kerja.parentFile?.deleteRecursively()
        }
    }

    private fun formatCompress(target: FormatGambar): Bitmap.CompressFormat = when (target) {
        FormatGambar.JPG -> Bitmap.CompressFormat.JPEG
        FormatGambar.PNG -> Bitmap.CompressFormat.PNG
        FormatGambar.WEBP ->
            if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
            else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
    }

    private fun keLatarPutih(src: Bitmap): Bitmap {
        val hasil = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(hasil).apply {
            drawColor(Color.WHITE)
            drawBitmap(src, 0f, 0f, null)
        }
        return hasil
    }

    /** Foto dari kamera sering menyimpan rotasi di EXIF; tanpa ini hasil konversi bisa miring. */
    private fun putarSesuaiExif(sumber: Uri, bitmap: Bitmap): Bitmap {
        val orientasi = runCatching {
            context.contentResolver.openInputStream(sumber)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL

        val derajat = when (orientasi) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> return bitmap
        }
        val matrix = Matrix().apply { postRotate(derajat) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    // ---------- Video/audio -> MP3/M4A: lewat yt-dlp + ffmpeg yang sudah ada di aplikasi ----------

    suspend fun konversiMedia(
        sumber: Uri,
        namaAsli: String,
        folder: Uri,
        target: FormatAudio,
        processId: String
    ): HasilKonversi = withContext(Dispatchers.IO) {
        dibatalkan = false
        val kerja = siapkanKerja()
        val masuk = File(kerja, "masuk").apply { mkdirs() }
        val keluar = File(kerja, "keluar").apply { mkdirs() }

        try {
            // yt-dlp butuh path file sungguhan, jadi salin dulu dari SAF ke cache.
            val salinan = File(masuk, bersihkanNama(namaAsli))
            context.contentResolver.openInputStream(sumber)?.use { input ->
                salinan.outputStream().buffered(BUFFER).use { out -> input.copyTo(out, BUFFER) }
            } ?: return@withContext HasilKonversi.Gagal(
                context.getString(R.string.error_gambar_gagal_dibaca)
            )

            val request = YoutubeDLRequest(Uri.fromFile(salinan).toString()).apply {
                addOption("--enable-file-urls")
                addOption("-o", "${keluar.absolutePath}/%(title).150s.%(ext)s")
                addOption("-x")
                addOption("--audio-format", target.ekstensi)
                addOption("--audio-quality", "192K")
                addOption("--no-playlist")
                addOption("--no-mtime")
            }
            YoutubeDL.getInstance().execute(request, processId) { _, _, _ -> }

            if (dibatalkan) return@withContext HasilKonversi.Dibatalkan

            val hasil = keluar.listFiles()
                ?.filter { it.isFile && it.extension.equals(target.ekstensi, ignoreCase = true) }
                .orEmpty()
            if (hasil.isEmpty()) {
                return@withContext HasilKonversi.Gagal(context.getString(R.string.error_tidak_ada_file))
            }

            var gagalSimpan = false
            for (f in hasil) if (!storage.simpanKeLokasiPilihan(f, folder)) gagalSimpan = true

            if (gagalSimpan) HasilKonversi.Gagal(context.getString(R.string.error_gagal_simpan))
            else HasilKonversi.Sukses(hasil.first().name)
        } catch (e: Exception) {
            if (dibatalkan) HasilKonversi.Dibatalkan else HasilKonversi.Gagal(ringkasError(e))
        } finally {
            kerja.parentFile?.deleteRecursively()
        }
    }

    fun batalkan(processId: String) {
        dibatalkan = true
        YoutubeDL.getInstance().destroyProcessById(processId)
    }

    // ---------- util ----------

    /** Folder kerja unik: cache/konversi/<angka>/ ; induknya dihapus saat selesai. */
    private fun siapkanKerja(): File {
        val akar = File(context.cacheDir, "konversi").also { it.deleteRecursively() }
        return File(akar, System.nanoTime().toString()).also { it.mkdirs() }
    }

    private fun bersihkanNama(nama: String): String =
        nama.replace(Regex("[\\\\/:*?\"<>|#%]"), "_").ifBlank { "file" }

    private fun namaDasar(nama: String): String =
        bersihkanNama(nama.substringBeforeLast('.', nama)).ifBlank { "hasil" }

    private companion object {
        const val BUFFER = 64 * 1024
    }
}
