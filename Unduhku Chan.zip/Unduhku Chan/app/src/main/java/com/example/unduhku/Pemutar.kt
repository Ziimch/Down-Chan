package com.example.unduhku

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

class Lagu(val uri: Uri, val nama: String)

/** Pemutar mini: MediaPlayer bawaan Android, tanpa library tambahan. */
class Pemutar(private val context: Context, private val onUbah: () -> Unit) {

    var daftar: List<Lagu> = emptyList(); private set
    var indeks = -1; private set
    var acak = false
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tidur: Runnable? = null

    val sedangMain get() = runCatching { mp?.isPlaying == true }.getOrDefault(false)
    val durasi get() = runCatching { mp?.duration ?: 0 }.getOrDefault(0)
    val posisi get() = runCatching { mp?.currentPosition ?: 0 }.getOrDefault(0)
    val judul get() = daftar.getOrNull(indeks)?.nama ?: "Belum ada lagu diputar"

    suspend fun muat(tree: Uri) {
        daftar = withContext(Dispatchers.IO) { telusuri(tree) }
        onUbah()
    }

    fun putar(i: Int) {
        val lagu = daftar.getOrNull(i) ?: return
        lepasPemutar()
        val p = MediaPlayer()
        try {
            p.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(context, lagu.uri)
            p.prepare()
        } catch (e: Exception) {
            Catatan.tulis("Gagal memutar ${lagu.nama}: ${e.message}")
            p.release()
            onUbah()
            return
        }
        p.setOnCompletionListener { berikut() }
        p.start()
        mp = p
        indeks = i
        onUbah()
    }

    fun toggle() {
        val p = mp
        when {
            p == null -> if (daftar.isNotEmpty()) putar(if (acak) Random.nextInt(daftar.size) else 0)
            p.isPlaying -> { p.pause(); onUbah() }
            else -> { p.start(); onUbah() }
        }
    }

    fun berikut() {
        if (daftar.isEmpty()) return
        val n = daftar.size
        var i = if (acak) Random.nextInt(n) else (indeks + 1) % n
        if (acak && n > 1 && i == indeks) i = (i + 1) % n
        putar(i)
    }

    fun sebelumnya() {
        if (daftar.isEmpty()) return
        if (posisi > 3000) { mp?.seekTo(0); onUbah(); return }
        putar((indeks - 1 + daftar.size) % daftar.size)
    }

    fun lagiAcak() {
        if (daftar.isNotEmpty()) { acak = true; putar(Random.nextInt(daftar.size)) }
    }

    fun seek(ms: Int) { runCatching { mp?.seekTo(ms) } }

    fun setTidur(menit: Int) {
        tidur?.let(handler::removeCallbacks)
        tidur = null
        if (menit > 0) {
            tidur = Runnable { runCatching { mp?.pause() }; onUbah() }.also {
                handler.postDelayed(it, menit * 60_000L)
            }
        }
    }

    fun lepas() {
        setTidur(0)
        lepasPemutar()
    }

    private fun lepasPemutar() {
        runCatching { mp?.release() }
        mp = null
    }

    /** Satu query per folder (bukan per file) jauh lebih cepat daripada DocumentFile.listFiles(). */
    private fun telusuri(tree: Uri): List<Lagu> {
        val hasil = ArrayList<Lagu>()
        fun jelajah(docId: String, kedalaman: Int) {
            val anak = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            context.contentResolver.query(
                anak,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val nama = c.getString(1) ?: continue
                    val mime = c.getString(2).orEmpty()
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (kedalaman < 2) jelajah(id, kedalaman + 1)
                    } else if (mime.startsWith("audio/") ||
                        nama.substringAfterLast('.', "").lowercase() in EKSTENSI
                    ) {
                        hasil += Lagu(DocumentsContract.buildDocumentUriUsingTree(tree, id), nama.substringBeforeLast('.'))
                    }
                }
            }
        }
        runCatching { jelajah(DocumentsContract.getTreeDocumentId(tree), 0) }
            .onFailure { Catatan.tulis("Gagal membaca folder musik: ${it.message}") }
        return hasil.sortedBy { it.nama.lowercase() }
    }

    private companion object {
        val EKSTENSI = setOf("mp3", "m4a", "ogg", "opus", "wav", "flac", "aac")
    }
}
