package com.example.unduhku

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

class Lagu(val uri: Uri, val nama: String)

/** Pemutar mini: MediaPlayer bawaan Android, tanpa library tambahan. */
class Pemutar(private val context: Context, private val onUbah: () -> Unit) {

    var daftar: List<Lagu> = emptyList(); private set
    var indeks = -1; private set
    var acak = false
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tidur: Runnable? = null
    private var laguAktif: Lagu? = null
    private var lanjutSetelahFokus = false
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var permintaanFokus: AudioFocusRequest? = null

    private val dengarFokus = AudioManager.OnAudioFocusChangeListener { perubahan ->
        val p = mp ?: return@OnAudioFocusChangeListener
        runCatching {
            when (perubahan) {
                AudioManager.AUDIOFOCUS_LOSS -> { lanjutSetelahFokus = false; p.pause(); onUbah() }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                    lanjutSetelahFokus = p.isPlaying; p.pause(); onUbah()
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> p.setVolume(0.2f, 0.2f)
                AudioManager.AUDIOFOCUS_GAIN -> {
                    p.setVolume(1f, 1f)
                    if (lanjutSetelahFokus) { lanjutSetelahFokus = false; p.start(); onUbah() }
                }
                else -> {}
            }
            Unit
        }
    }

    val sedangMain get() = runCatching { mp?.isPlaying == true }.getOrDefault(false)
    val durasi get() = runCatching { mp?.duration ?: 0 }.getOrDefault(0)
    val posisi get() = runCatching { mp?.currentPosition ?: 0 }.getOrDefault(0)
    val judul get() = daftar.getOrNull(indeks)?.nama ?: laguAktif?.nama ?: "Belum ada lagu diputar"

    suspend fun muat(tree: Uri) {
        val baru = withContext(Dispatchers.IO) { telusuri(tree) }
        // Urutan/isi daftar bisa berubah: cari lagi posisi lagu yang sedang diputar.
        val aktif = laguAktif
        indeks = if (aktif == null) -1 else baru.indexOfFirst { it.uri == aktif.uri }
        daftar = baru
        onUbah()
    }

    private fun mintaFokus(): Boolean {
        val hasil = if (Build.VERSION.SDK_INT >= 26) {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setOnAudioFocusChangeListener(dengarFokus, handler).build()
            permintaanFokus = r
            audio.requestAudioFocus(r)
        } else {
            @Suppress("DEPRECATION")
            audio.requestAudioFocus(dengarFokus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return hasil == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun lepasFokus() {
        lanjutSetelahFokus = false
        if (Build.VERSION.SDK_INT >= 26) {
            permintaanFokus?.let { audio.abandonAudioFocusRequest(it) }
            permintaanFokus = null
        } else {
            @Suppress("DEPRECATION") audio.abandonAudioFocus(dengarFokus)
        }
    }

    fun putar(i: Int) {
        val lagu = daftar.getOrNull(i) ?: return
        lepasPemutar()
        val p = MediaPlayer()
        try {
            p.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(context, lagu.uri)
            p.prepare()
        } catch (e: Exception) {
            Catatan.tulis("Gagal memutar ${lagu.nama}: ${e.message}")
            p.release()
            onUbah()
            return
        }
        p.setOnCompletionListener { berikut() }
        p.setOnErrorListener { _, what, extra ->
            Catatan.tulis("Pemutar error ($what/$extra) pada ${lagu.nama}")
            if (mp === p) { lepasFokus(); lepasPemutar() }
            onUbah()
            true
        }
        mintaFokus()
        p.start()
        mp = p
        indeks = i
        laguAktif = lagu
        onUbah()
    }

    fun toggle() {
        val p = mp
        runCatching {
            when {
                p == null -> if (daftar.isNotEmpty()) putar(if (acak) Random.nextInt(daftar.size) else 0)
                p.isPlaying -> { p.pause(); onUbah() }
                else -> { mintaFokus(); p.start(); onUbah() }
            }
            Unit
        }.onFailure {
            Catatan.tulis("Toggle pemutar gagal: ${it.message}")
            lepasPemutar(); onUbah()
        }
    }

    fun berikut() {
        if (daftar.isEmpty()) return
        val n = daftar.size
        var i = if (acak) Random.nextInt(n) else (indeks + 1).coerceAtLeast(0) % n
        if (acak && n > 1 && i == indeks) i = (i + 1) % n
        putar(i)
    }

    fun sebelumnya() {
        if (daftar.isEmpty()) return
        if (posisi > 3000) { mp?.seekTo(0); onUbah(); return }
        putar(if (indeks <= 0) daftar.size - 1 else indeks - 1)
    }

    /** Tombol Acak: pertama kali menyalakan mode acak dan memutar lagu acak; ditekan lagi mematikannya. */
    fun lagiAcak() {
        if (daftar.isEmpty()) return
        if (acak) { acak = false; onUbah(); return }
        acak = true
        putar(Random.nextInt(daftar.size))
    }

    fun seek(ms: Int) { runCatching { mp?.seekTo(ms) } }

    fun setTidur(menit: Int) {
        tidur?.let(handler::removeCallbacks)
        tidur = null
        if (menit > 0) {
            tidur = Runnable { runCatching { mp?.pause() }; onUbah() }.also {
                handler.postDelayed(it, menit * 60_000L)
            }
        }
    }

    fun lepas() {
        setTidur(0)
        lepasFokus()
        lepasPemutar()
    }

    /** Dipanggil saat folder simpan diganti: hentikan lagu dan kosongkan daftar lama. */
    fun reset() {
        lepasFokus()
        lepasPemutar()
        daftar = emptyList()
        indeks = -1
        laguAktif = null
        onUbah()
    }

    private fun lepasPemutar() {
        runCatching { mp?.setOnCompletionListener(null) }
        runCatching { mp?.release() }
        mp = null
    }

    /** Satu query per folder (bukan per file) jauh lebih cepat daripada DocumentFile.listFiles(). */
    private fun telusuri(tree: Uri): List<Lagu> {
        val hasil = ArrayList<Lagu>()
        fun jelajah(docId: String, kedalaman: Int) {
            val anak = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            context.contentResolver.query(
                anak,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val nama = c.getString(1) ?: continue
                    val mime = c.getString(2).orEmpty()
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (kedalaman < 2) jelajah(id, kedalaman + 1)
                    } else if (mime.startsWith("audio/") ||
                        nama.substringAfterLast('.', "").lowercase() in EKSTENSI
                    ) {
                        hasil += Lagu(DocumentsContract.buildDocumentUriUsingTree(tree, id), nama.substringBeforeLast('.'))
                    }
                }
            }
        }
        runCatching { jelajah(DocumentsContract.getTreeDocumentId(tree), 0) }
            .onFailure { Catatan.tulis("Gagal membaca folder musik: ${it.message}") }
        return hasil.sortedBy { it.nama.lowercase() }
    }

    private companion object {
        val EKSTENSI = setOf("mp3", "m4a", "ogg", "opus", "wav", "flac", "aac")
    }
}
