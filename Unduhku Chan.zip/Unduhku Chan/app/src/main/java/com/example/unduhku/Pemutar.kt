package com.example.unduhku

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.DocumentsContract
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.random.Random

/**
 * Lagu lokal (uri dari folder simpan) atau online ([id] diisi: tautan streaming baru dicari saat diputar).
 */
class Lagu(
    val uri: Uri,
    val nama: String,
    val id: String? = null,
    val artis: String? = null,
    val sampulUrl: String? = null
)

/** Sampul bawaan (kotak biru dengan not musik) saat lagu tidak punya cover tersemat. */
object Sampul {
    @Volatile private var cache: Bitmap? = null

    fun bawaan(c: Context): Bitmap = cache ?: synchronized(this) {
        cache ?: buat(c.applicationContext).also { cache = it }
    }

    private fun buat(c: Context): Bitmap {
        val ukuran = 384
        val bmp = Bitmap.createBitmap(ukuran, ukuran, Bitmap.Config.ARGB_8888)
        val kanvas = Canvas(bmp)
        kanvas.drawColor(ContextCompat.getColor(c, R.color.primary_container))
        ContextCompat.getDrawable(c, R.drawable.ic_music)?.mutate()?.let { d ->
            d.setTint(ContextCompat.getColor(c, R.color.primary))
            val pad = ukuran / 4
            d.setBounds(pad, pad, ukuran - pad, ukuran - pad)
            d.draw(kanvas)
        }
        return bmp
    }
}

/**
 * Mesin pemutar musik. Satu instance untuk seluruh proses (bukan milik Activity), sehingga
 * musik tetap jalan saat aplikasi ditutup; MusikService menampilkan notifikasinya.
 * Semua pemanggilan harus dari thread utama.
 */
class Pemutar private constructor(private val context: Context) {

    enum class Ulang { SEMUA, SATU, MATI }

    private class Meta(val judul: String?, val artis: String?, val sampul: Bitmap?)

    var daftar: List<Lagu> = emptyList(); private set
    var indeks = -1; private set
    var acak = false; private set
    var ulang = Ulang.SEMUA; private set
    var menyiapkan = false; private set
    var sampul: Bitmap? = null; private set
    var artis: String? = null; private set

    private var judulMeta: String? = null
    private var laguAktif: Lagu? = null
    private var mp: MediaPlayer? = null
    private var gagalBeruntun = 0
    private var tidur: Runnable? = null
    private var lanjutSetelahFokus = false
    private var jobResolve: Job? = null

    /** Pesan kegagalan terakhir; dibaca (dan dikosongkan) oleh UI agar pengguna tahu penyebabnya. */
    @Volatile private var galat: String? = null
    fun ambilGalat(): String? { val g = galat; galat = null; return g }
    private var berikutAcak = -1

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val pendengar = CopyOnWriteArrayList<() -> Unit>()
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var permintaanFokus: AudioFocusRequest? = null

    // ---------------------------------------------------------------- status

    /** True juga saat tautan online sedang dicari, supaya MusikService tidak menutup diri di tengah antrean. */
    val aktif get() = mp != null || menyiapkan
    val laguSaatIni: Lagu? get() = laguAktif
    val antreanOnline get() = daftar.firstOrNull()?.id != null
    val sedangMain get() = runCatching { mp?.isPlaying == true }.getOrDefault(false)
    val durasi get() = if (menyiapkan) 0 else runCatching { mp?.duration ?: 0 }.getOrDefault(0).coerceAtLeast(0)
    val posisi get() = if (menyiapkan) 0 else runCatching { mp?.currentPosition ?: 0 }.getOrDefault(0).coerceAtLeast(0)
    val judul: String
        get() = judulMeta ?: daftar.getOrNull(indeks)?.nama ?: laguAktif?.nama ?: "Belum ada lagu diputar"

    fun dengar(l: () -> Unit) { if (!pendengar.contains(l)) pendengar.add(l) }
    fun lepasDengar(l: () -> Unit) { pendengar.remove(l) }
    private fun ubah() { for (l in pendengar) l() }

    // ---------------------------------------------------------------- audio focus

    private val dengarFokus = AudioManager.OnAudioFocusChangeListener { perubahan ->
        val p = mp ?: return@OnAudioFocusChangeListener
        runCatching {
            when (perubahan) {
                AudioManager.AUDIOFOCUS_LOSS -> { lanjutSetelahFokus = false; p.pause(); ubah() }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                    lanjutSetelahFokus = p.isPlaying; p.pause(); ubah()
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> p.setVolume(0.2f, 0.2f)
                AudioManager.AUDIOFOCUS_GAIN -> {
                    p.setVolume(1f, 1f)
                    if (lanjutSetelahFokus) { lanjutSetelahFokus = false; p.start(); ubah() }
                }
                else -> {}
            }
            Unit
        }
    }

    private fun mintaFokus(): Boolean {
        val hasil = if (Build.VERSION.SDK_INT >= 26) {
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setOnAudioFocusChangeListener(dengarFokus, handler).build()
            permintaanFokus = r
            audio.requestAudioFocus(r)
        } else {
            @Suppress("DEPRECATION")
            audio.requestAudioFocus(dengarFokus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return hasil == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun lepasFokus() {
        lanjutSetelahFokus = false
        if (Build.VERSION.SDK_INT >= 26) {
            permintaanFokus?.let { audio.abandonAudioFocusRequest(it) }
            permintaanFokus = null
        } else {
            @Suppress("DEPRECATION") audio.abandonAudioFocus(dengarFokus)
        }
    }

    // ---------------------------------------------------------------- daftar

    suspend fun muat(tree: Uri) {
        val baru = withContext(Dispatchers.IO) { telusuri(tree) }
        // Urutan/isi daftar bisa berubah: cari lagi posisi lagu yang sedang diputar.
        val sekarang = laguAktif
        indeks = if (sekarang == null) -1 else baru.indexOfFirst { it.uri == sekarang.uri }
        daftar = baru
        ubah()
    }

    // ---------------------------------------------------------------- kontrol

    /** Ganti antrean (mis. hasil pencarian online) lalu putar dari posisi [mulai]. */
    fun setAntrean(baru: List<Lagu>, mulai: Int) {
        if (baru.isEmpty()) return
        daftar = baru
        berikutAcak = -1
        indeks = -1
        laguAktif = null
        putar(mulai.coerceIn(0, baru.lastIndex))
    }

    /** Sisipkan tepat setelah lagu yang sedang berbunyi. Bila belum ada antrean, langsung diputar. */
    fun putarBerikutnya(l: Lagu) {
        if (daftar.isEmpty()) { setAntrean(listOf(l), 0); return }
        val baru = daftar.toMutableList()
        baru.add((indeks + 1).coerceIn(0, baru.size), l)
        daftar = baru
        berikutAcak = -1
        ubah()
    }

    fun tambahKeAntrean(l: Lagu) {
        if (daftar.isEmpty()) { setAntrean(listOf(l), 0); return }
        daftar = daftar + l
        ubah()
    }

    private fun catatPutar(lagu: Lagu) {
        val id = lagu.id ?: return
        scope.launch(Dispatchers.IO) {
            PutarTerakhir.tambah(context, HasilLagu(id, lagu.nama, lagu.artis.orEmpty(), 0, lagu.sampulUrl))
        }
    }

    fun setAcak(nyala: Boolean) {
        acak = nyala
        berikutAcak = -1
        ubah()
    }

    fun putar(i: Int) {
        val lagu = daftar.getOrNull(i) ?: return
        lepasPemutar()
        indeks = i
        laguAktif = lagu
        judulMeta = null; artis = lagu.artis; sampul = null
        menyiapkan = true
        if (lagu.id != null) mulaiOnline(lagu) else mulaiPlayer(lagu, lagu.uri, null)
        ubah()
    }

    /** Cari tautan streaming dulu (cache = instan, kalau tidak yt-dlp), baru mulai memutar. */
    private fun mulaiOnline(lagu: Lagu) {
        val id = lagu.id ?: return
        jobResolve = scope.launch {
            // Batas waktu: tanpa ini koneksi yang macet membuat "Menyiapkan…" menggantung selamanya
            val s = withTimeoutOrNull(30_000L) { Jelajah.resolve(context, id) }
            // Saat menunggu, pengguna mungkin sudah pindah lagu atau menghentikan pemutar
            if (laguAktif !== lagu || !menyiapkan) return@launch
            if (s != null) {
                mulaiPlayer(lagu, Uri.parse(s.url), s.headers, bolehCadangan = true)
                ubah()
                ambilMetaOnline(lagu)
            } else cadanganCache(lagu)
        }
    }

    /** Streaming gagal: unduh audionya ke cache lalu putar dari file (lebih lambat, tapi andal). */
    private suspend fun cadanganCache(lagu: Lagu) {
        val id = lagu.id ?: return
        Catatan.tulis("Streaming ${lagu.nama} gagal, mencoba lewat cache")
        val f = withTimeoutOrNull(120_000L) { Jelajah.ambilKeCache(context, id) }
        if (laguAktif !== lagu || !menyiapkan) return
        if (f == null) { gagalPutar(Jelajah.alasanGagal ?: "waktu habis, periksa koneksi internet"); return }
        mulaiPlayer(lagu, Uri.fromFile(f), null, bolehCadangan = false)
        ubah()
        ambilMetaOnline(lagu)
    }

    private fun mulaiPlayer(lagu: Lagu, uri: Uri, headers: Map<String, String>?, bolehCadangan: Boolean = false) {
        val p = MediaPlayer()
        mp = p
        // Gagal saat streaming: lepas pemutar lalu coba lewat cache (hanya untuk lagu online)
        fun gagal(alasan: String?) {
            if (bolehCadangan && lagu.id != null) {
                lepasPemutar()
                menyiapkan = true
                jobResolve = scope.launch { cadanganCache(lagu) }
            } else gagalPutar(alasan)
        }
        try {
            p.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            if (headers.isNullOrEmpty()) p.setDataSource(context, uri) else p.setDataSource(context, uri, headers)
            p.setOnPreparedListener { siap ->
                if (mp !== siap) return@setOnPreparedListener
                menyiapkan = false
                gagalBeruntun = 0
                mintaFokus()
                runCatching { siap.start() }
                MusikService.mulai(context)
                if (lagu.id == null) ambilMeta(lagu) else { prefetchBerikut(); catatPutar(lagu) }
                ubah()
            }
            p.setOnCompletionListener { selesai -> if (mp === selesai) selesaiLagu() }
            p.setOnErrorListener { galatPemutar, what, extra ->
                Catatan.tulis("Pemutar error ($what/$extra) pada ${lagu.nama}")
                if (mp === galatPemutar) gagal("kode kesalahan $what/$extra")
                true
            }
            // prepareAsync: membuka file dari SAF / jaringan tidak memblokir thread utama.
            p.prepareAsync()
        } catch (e: Exception) {
            Catatan.tulis("Gagal memutar ${lagu.nama}: ${e.message}")
            gagal(e.message)
        }
    }

    private fun gagalPutar(alasan: String? = null) {
        val nama = laguAktif?.nama.orEmpty()
        lepasPemutar()
        menyiapkan = false
        gagalBeruntun++
        // Dulu gagal diam-diam: sekarang pengguna diberi tahu lagu apa dan kenapa.
        galat = "Tidak bisa memutar “$nama”" + (alasan?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "")
        if (gagalBeruntun < 3 && daftar.size > 1) berikut()
        else { gagalBeruntun = 0; lepasFokus(); ubah() }
    }

    private fun selesaiLagu() {
        when {
            ulang == Ulang.SATU -> { runCatching { mp?.seekTo(0); mp?.start() }; ubah() }
            ulang == Ulang.MATI && !acak && indeks >= daftar.lastIndex -> {
                runCatching { mp?.seekTo(0) }
                lepasFokus()
                ubah()
            }
            else -> berikut()
        }
    }

    fun toggle() {
        if (menyiapkan) return
        val p = mp
        if (p == null) {
            if (daftar.isNotEmpty()) {
                putar(if (acak) Random.nextInt(daftar.size) else if (indeks in daftar.indices) indeks else 0)
            }
            return
        }
        if (menyiapkan) return
        runCatching {
            if (p.isPlaying) p.pause()
            else { mintaFokus(); p.start(); MusikService.mulai(context) }
        }.onFailure {
            Catatan.tulis("Toggle pemutar gagal: ${it.message}")
            hentikan()
            return
        }
        ubah()
    }

    fun jeda() {
        val p = mp ?: return
        if (menyiapkan) return
        if (sedangMain) runCatching { p.pause() }
        ubah()
    }

    /** Indeks lagu berikutnya. Mode acak memilih lebih dulu supaya lagunya bisa disiapkan (prefetch). */
    private fun indeksBerikut(): Int {
        val n = daftar.size
        if (n == 0) return -1
        if (!acak) return (indeks + 1).coerceAtLeast(0) % n
        if (berikutAcak !in 0 until n || (n > 1 && berikutAcak == indeks)) {
            var i = Random.nextInt(n)
            if (n > 1 && i == indeks) i = (i + 1) % n
            berikutAcak = i
        }
        return berikutAcak
    }

    fun berikut() {
        if (daftar.isEmpty()) return
        val i = indeksBerikut()
        berikutAcak = -1
        putar(i)
    }

    /** Siapkan tautan 1-2 lagu berikutnya selagi lagu ini berbunyi: pindah lagu jadi hampir instan. */
    private fun prefetchBerikut() {
        if (daftar.isEmpty()) return
        val a = indeksBerikut()
        val ids = mutableListOf<String>()
        daftar.getOrNull(a)?.id?.let { ids += it }
        if (!acak) daftar.getOrNull((a + 1) % daftar.size)?.id?.let { ids += it }
        if (ids.isNotEmpty()) Jelajah.prefetch(context, ids)
    }

    fun sebelumnya() {
        if (daftar.isEmpty()) return
        if (posisi > 3000) { runCatching { mp?.seekTo(0) }; ubah(); return }
        putar(if (indeks <= 0) daftar.size - 1 else indeks - 1)
    }

    /** Tombol Acak: pertama kali menyalakan mode acak dan memutar lagu acak; ditekan lagi mematikannya. */
    fun lagiAcak() {
        if (daftar.isEmpty()) return
        if (acak) { acak = false; ubah(); return }
        acak = true
        putar(Random.nextInt(daftar.size))
    }

    fun ganti() {
        ulang = when (ulang) { Ulang.SEMUA -> Ulang.SATU; Ulang.SATU -> Ulang.MATI; Ulang.MATI -> Ulang.SEMUA }
        ubah()
    }

    fun seek(ms: Int) {
        if (menyiapkan) return
        runCatching { mp?.seekTo(ms) }
        ubah()
    }

    fun setTidur(menit: Int) {
        tidur?.let(handler::removeCallbacks)
        tidur = null
        if (menit > 0) {
            tidur = Runnable { jeda() }.also { handler.postDelayed(it, menit * 60_000L) }
        }
    }

    /** Hentikan lagu dan lepaskan pemutar (daftar tetap ada). Notifikasi ikut hilang. */
    fun hentikan() {
        lepasFokus()
        lepasPemutar()
        laguAktif = null
        judulMeta = null; artis = null; sampul = null
        menyiapkan = false
        ubah()
    }

    /** Dipanggil saat folder simpan diganti: hentikan lagu dan kosongkan daftar lama. */
    fun reset() {
        lepasFokus()
        lepasPemutar()
        daftar = emptyList()
        indeks = -1
        laguAktif = null
        judulMeta = null; artis = null; sampul = null
        menyiapkan = false
        ubah()
    }

    private fun lepasPemutar() {
        jobResolve?.cancel()
        jobResolve = null
        runCatching { mp?.setOnCompletionListener(null) }
        runCatching { mp?.setOnPreparedListener(null) }
        runCatching { mp?.setOnErrorListener(null) }
        runCatching { mp?.release() }
        mp = null
    }

    // ---------------------------------------------------------------- metadata & sampul

    private fun ambilMeta(lagu: Lagu) {
        scope.launch {
            val m = withContext(Dispatchers.IO) { bacaMeta(lagu.uri) }
            if (laguAktif?.uri != lagu.uri) return@launch
            judulMeta = m?.judul?.takeIf { it.isNotBlank() }
            artis = m?.artis?.takeIf { it.isNotBlank() }
            sampul = m?.sampul
            ubah()
        }
    }

    /** Judul & artis sudah ada dari hasil pencarian; hanya sampulnya yang diunduh. */
    private fun ambilMetaOnline(lagu: Lagu) {
        val url = lagu.sampulUrl ?: return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { Jelajah.muatGambar(url) }
            if (laguAktif !== lagu || bmp == null) return@launch
            sampul = bmp
            ubah()
        }
    }

    private fun bacaMeta(uri: Uri): Meta? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            val judul = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            val artis = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            val gambar = r.embeddedPicture?.let { dekodeSampul(it) }
            Meta(judul, artis, gambar)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    /** Dikecilkan (maks ~600 px) dan dipotong persegi: pas untuk notifikasi & layar kunci. */
    private fun dekodeSampul(b: ByteArray): Bitmap? {
        val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, batas)
        var s = 1
        while (maxOf(batas.outWidth, batas.outHeight) / s > 600) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: return null
        val sisi = minOf(bmp.width, bmp.height)
        if (bmp.width == bmp.height) return bmp
        val persegi = Bitmap.createBitmap(bmp, (bmp.width - sisi) / 2, (bmp.height - sisi) / 2, sisi, sisi)
        if (persegi !== bmp) bmp.recycle()
        return persegi
    }

    // ---------------------------------------------------------------- penelusuran folder

    /** Satu query per folder (bukan per file) jauh lebih cepat daripada DocumentFile.listFiles(). */
    private fun telusuri(tree: Uri): List<Lagu> {
        val hasil = ArrayList<Lagu>()
        fun jelajah(docId: String, kedalaman: Int) {
            val anak = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            context.contentResolver.query(
                anak,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val nama = c.getString(1) ?: continue
                    val mime = c.getString(2).orEmpty()
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (kedalaman < 3) jelajah(id, kedalaman + 1)
                    } else if (mime.startsWith("audio/") ||
                        nama.substringAfterLast('.', "").lowercase() in EKSTENSI
                    ) {
                        hasil += Lagu(DocumentsContract.buildDocumentUriUsingTree(tree, id), nama.substringBeforeLast('.'))
                    }
                }
            }
        }
        runCatching { jelajah(DocumentsContract.getTreeDocumentId(tree), 0) }
            .onFailure { Catatan.tulis("Gagal membaca folder musik: ${it.message}") }
        return hasil.sortedBy { it.nama.lowercase() }
    }

    companion object {
        private val EKSTENSI = setOf("mp3", "m4a", "ogg", "opus", "wav", "flac", "aac")

        @Volatile private var instance: Pemutar? = null

        fun get(c: Context): Pemutar = instance ?: synchronized(this) {
            instance ?: Pemutar(c.applicationContext).also { instance = it }
        }
    }
}
