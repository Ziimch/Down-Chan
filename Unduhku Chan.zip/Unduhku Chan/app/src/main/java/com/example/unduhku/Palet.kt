package com.example.unduhku

import android.graphics.Bitmap
import android.graphics.Color
import java.util.Locale

/**
 * Palet tema yang mengikuti gambar latar pilihan pengguna.
 * Gaya tiap palet dihasilkan otomatis di res/values/palet.xml (24 corak x 2 tingkat kejenuhan + netral),
 * dipasang sebagai overlay di atas tema dasar. Hasilnya seluruh komponen (tombol, kolom isian, saklar,
 * kartu, bilah bawah) berganti warna bersama-sama.
 */
object Palet {
    private val TABEL = mapOf(
        "b00_v" to R.style.Palet_b00_v,
        "b00_m" to R.style.Palet_b00_m,
        "b01_v" to R.style.Palet_b01_v,
        "b01_m" to R.style.Palet_b01_m,
        "b02_v" to R.style.Palet_b02_v,
        "b02_m" to R.style.Palet_b02_m,
        "b03_v" to R.style.Palet_b03_v,
        "b03_m" to R.style.Palet_b03_m,
        "b04_v" to R.style.Palet_b04_v,
        "b04_m" to R.style.Palet_b04_m,
        "b05_v" to R.style.Palet_b05_v,
        "b05_m" to R.style.Palet_b05_m,
        "b06_v" to R.style.Palet_b06_v,
        "b06_m" to R.style.Palet_b06_m,
        "b07_v" to R.style.Palet_b07_v,
        "b07_m" to R.style.Palet_b07_m,
        "b08_v" to R.style.Palet_b08_v,
        "b08_m" to R.style.Palet_b08_m,
        "b09_v" to R.style.Palet_b09_v,
        "b09_m" to R.style.Palet_b09_m,
        "b10_v" to R.style.Palet_b10_v,
        "b10_m" to R.style.Palet_b10_m,
        "b11_v" to R.style.Palet_b11_v,
        "b11_m" to R.style.Palet_b11_m,
        "b12_v" to R.style.Palet_b12_v,
        "b12_m" to R.style.Palet_b12_m,
        "b13_v" to R.style.Palet_b13_v,
        "b13_m" to R.style.Palet_b13_m,
        "b14_v" to R.style.Palet_b14_v,
        "b14_m" to R.style.Palet_b14_m,
        "b15_v" to R.style.Palet_b15_v,
        "b15_m" to R.style.Palet_b15_m,
        "b16_v" to R.style.Palet_b16_v,
        "b16_m" to R.style.Palet_b16_m,
        "b17_v" to R.style.Palet_b17_v,
        "b17_m" to R.style.Palet_b17_m,
        "b18_v" to R.style.Palet_b18_v,
        "b18_m" to R.style.Palet_b18_m,
        "b19_v" to R.style.Palet_b19_v,
        "b19_m" to R.style.Palet_b19_m,
        "b20_v" to R.style.Palet_b20_v,
        "b20_m" to R.style.Palet_b20_m,
        "b21_v" to R.style.Palet_b21_v,
        "b21_m" to R.style.Palet_b21_m,
        "b22_v" to R.style.Palet_b22_v,
        "b22_m" to R.style.Palet_b22_m,
        "b23_v" to R.style.Palet_b23_v,
        "b23_m" to R.style.Palet_b23_m,
        "netral" to R.style.Palet_netral
    )

    fun gaya(kunci: String?): Int? = if (kunci == null) null else TABEL[kunci]

    /** Pilih palet dari corak dominan gambar. Gambar nyaris tanpa warna memakai palet netral. */
    fun dariBitmap(b: Bitmap): String {
        val kecil = Bitmap.createScaledBitmap(b, 32, 32, true)
        val bobot = DoubleArray(24)
        val jenuh = DoubleArray(24)
        val hsv = FloatArray(3)
        var total = 0.0
        for (y in 0 until 32) for (x in 0 until 32) {
            Color.colorToHSV(kecil.getPixel(x, y), hsv)
            // Piksel abu-abu atau terlalu gelap tidak menentukan warna tema
            if (hsv[1] < 0.12f || hsv[2] < 0.2f) continue
            val w = (hsv[1] * hsv[2]).toDouble()
            val bin = (hsv[0] / 15f).toInt().coerceIn(0, 23)
            bobot[bin] += w
            jenuh[bin] += w * hsv[1]
            total += w
        }
        if (total < 8.0) return "netral"
        var terbaik = 0
        var skorTerbaik = -1.0
        for (i in 0 until 24) {
            // Tetangga ikut dihitung setengah supaya warna di perbatasan dua corak tidak terpecah
            val skor = bobot[i] + 0.5 * bobot[(i + 23) % 24] + 0.5 * bobot[(i + 1) % 24]
            if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = i }
        }
        val rata = if (bobot[terbaik] > 0) jenuh[terbaik] / bobot[terbaik] else 0.0
        return String.format(Locale.US, "b%02d_%s", terbaik, if (rata >= 0.45) "v" else "m")
    }
}
