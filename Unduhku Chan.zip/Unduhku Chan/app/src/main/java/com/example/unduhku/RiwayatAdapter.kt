package com.example.unduhku

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RiwayatAdapter(private val onKlik: (Entri, View) -> Unit) :
    RecyclerView.Adapter<RiwayatAdapter.VH>() {

    private var data: List<Entri> = emptyList()

    fun set(list: List<Entri>) { data = list; notifyDataSetChanged() }

    class VH(val root: View) : RecyclerView.ViewHolder(root) {
        val judul: TextView = root.findViewById(R.id.tvJudulR)
        val meta: TextView = root.findViewById(R.id.tvMetaR)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_riwayat, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = data[position]
        h.judul.text = e.judul
        h.meta.text = "${e.label} • ${formatUkuran(e.ukuran)} • ${DateFormat.format("d MMM, HH:mm", e.waktu)}"
        h.root.setOnClickListener { onKlik(e, h.root) }
    }

    override fun getItemCount() = data.size
}
