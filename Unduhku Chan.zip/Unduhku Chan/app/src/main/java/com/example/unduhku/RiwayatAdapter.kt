package com.example.unduhku

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

/** Daftar riwayat: DiffUtil supaya hanya baris yang berubah yang digambar ulang. */
class RiwayatAdapter(
    private val onBuka: (Entri) -> Unit,
    private val onMenu: (Entri, View) -> Unit
) : ListAdapter<Entri, RiwayatAdapter.VH>(Pembanding) {

    class VH(val root: View) : RecyclerView.ViewHolder(root) {
        val ikon: ImageView = root.findViewById(R.id.imgIkonR)
        val judul: TextView = root.findViewById(R.id.tvJudulR)
        val meta: TextView = root.findViewById(R.id.tvMetaR)
        val lainnya: View = root.findViewById(R.id.btnLainnyaR)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_riwayat, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = getItem(position)
        h.judul.text = e.judul
        h.meta.text = "${e.label} • ${formatUkuran(e.ukuran)} • ${DateFormat.format("d MMM, HH:mm", e.waktu)}"
        h.ikon.setImageResource(
            when (e.label.uppercase()) {
                "MP3", "M4A" -> R.drawable.ic_music
                "MP4", "GIF" -> R.drawable.ic_video
                else -> R.drawable.ic_file
            }
        )
        h.root.setOnClickListener { onBuka(e) }
        h.lainnya.setOnClickListener { onMenu(e, h.lainnya) }
    }

    private object Pembanding : DiffUtil.ItemCallback<Entri>() {
        override fun areItemsTheSame(a: Entri, b: Entri) = a.uri == b.uri && a.waktu == b.waktu
        override fun areContentsTheSame(a: Entri, b: Entri) = a == b
    }
}
