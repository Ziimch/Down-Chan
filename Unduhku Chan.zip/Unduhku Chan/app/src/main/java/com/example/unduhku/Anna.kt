package com.example.unduhku

/** Kalimat-kalimat kecil supaya aplikasinya terasa hidup. Dipilih stabil per seed agar tidak berkedip. */
object Anna {
    private val santai = listOf(
        "Tempel link, Anna siap! 🍬", "Mau unduh apa hari ini?", "Anna menunggu perintahmu~"
    )
    private val kerja = listOf(
        "Anna semangat! 🍬", "Sebentar ya, Anna ambilkan…", "Anna lagi kerja keras nih~"
    )
    private val sukses = listOf(
        "Yatta! Selesai ✨", "Beres! Anna hebat kan? 🍰", "Sudah tersimpan, selamat menikmati~"
    )
    private val gagal = listOf(
        "Aduh… ada yang salah 😣", "Hmm, gagal. Coba lagi ya?", "Anna sudah berusaha, tapi gagal 💦"
    )

    fun santai(seed: Int = 0) = santai[Math.floorMod(seed, santai.size)]
    fun kerja(seed: Int) = kerja[Math.floorMod(seed, kerja.size)]
    fun sukses(seed: Int = 0) = sukses[Math.floorMod(seed, sukses.size)]
    fun gagal(seed: Int = 0) = gagal[Math.floorMod(seed, gagal.size)]
}
