package com.example.unduhku

/**
 * Kalimat-kalimat kecil supaya aplikasinya terasa hidup. Nama maskot bisa diganti pengguna
 * (Atur -> Tampilan); "{nama}" di bawah diganti nama itu. Dipilih stabil per seed agar tidak berkedip.
 */
object Anna {
    @Volatile
    var nama: String = "Anna"

    private val santai = listOf(
        "Tempel link, {nama} siap! 🍬", "Mau unduh apa hari ini?", "{nama} menunggu perintahmu~"
    )
    private val kerja = listOf(
        "{nama} semangat! 🍬", "Sebentar ya, {nama} ambilkan…", "{nama} lagi kerja keras nih~"
    )
    private val sukses = listOf(
        "Yatta! Selesai ✨", "Beres! {nama} hebat kan? 🍰", "Sudah tersimpan, selamat menikmati~"
    )
    private val gagal = listOf(
        "Aduh… ada yang salah 😣", "Hmm, gagal. Coba lagi ya?", "{nama} sudah berusaha, tapi gagal 💦"
    )

    private fun isi(t: String) = t.replace("{nama}", nama.ifBlank { "Anna" })

    fun santai(seed: Int = 0) = isi(santai[Math.floorMod(seed, santai.size)])
    fun kerja(seed: Int) = isi(kerja[Math.floorMod(seed, kerja.size)])
    fun sukses(seed: Int = 0) = isi(sukses[Math.floorMod(seed, sukses.size)])
    fun gagal(seed: Int = 0) = isi(gagal[Math.floorMod(seed, gagal.size)])
}
