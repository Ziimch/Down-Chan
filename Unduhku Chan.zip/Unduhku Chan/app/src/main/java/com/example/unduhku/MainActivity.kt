package com.example.unduhku

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Patterns
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.FrameLayout
import android.widget.PopupMenu
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.unduhku.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    companion object {
        /** Dikirim notifikasi musik agar aplikasi langsung membuka tab Putar. */
        const val EKSTRA_TAB = "tab"

        const val TAB_UNDUH = 0
        const val TAB_JELAJAH = 1
        const val TAB_KONVERSI = 2
        const val TAB_PUTAR = 3
        const val TAB_RIWAYAT = 4
        const val TAB_ATUR = 5
        /** Halaman awal & tujuan tombol Kembali. */
        const val TAB_BERANDA = TAB_JELAJAH
    }

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { Prefs(this) }
    private val riwayat by lazy { Riwayat.get(this) }
    private val downloader by lazy { Downloader(applicationContext) }
    private val converter by lazy { Converter(applicationContext) }
    // Satu pemutar untuk seluruh proses: musik tetap jalan walau Activity ditutup.
    private val pemutar by lazy { Pemutar.get(applicationContext) }
    private val handler = Handler(Looper.getMainLooper())
    private val adapterRiwayat = RiwayatAdapter(onBuka = { bukaFile(it) }, onMenu = { e, v -> menuRiwayat(e, v) })

    private var folderUri: Uri? = null
    private var mesinSiap = false
    private var mesinGagal = false
    private var tabAktif = -1
    private var statusAntrian = StatusAntrian()
    private var klipTerakhir = ""
    private var rilisBaru: Pembaruan.Info? = null
    private var insetAtas = 0
    private var insetBawah = 0
    private var insetIme = 0
    private var stempelKlip = 0L
    private var pesanKonversi: String? = null
    private var konversiOk = false
    private val kembaliKeUnduh = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { pilihTab(TAB_BERANDA) }
    }
    private var batasRiwayat = 30
    private var menyeret = false
    private var sampulTerpasang: Bitmap? = null
    private var sampulMini: Bitmap? = null
    private var miniTampak = false

    // ---- jelajah ----
    private var hasilCari: List<HasilLagu> = emptyList()
    private var jobCari: Job? = null
    private var jobSaran: Job? = null
    private var kueriTerakhir = ""
    private val adapterJelajah by lazy {
        JelajahAdapter(lifecycleScope, onPutar = { putarHasil(it) }, onUnduh = { unduhHasil(it) })
    }
    private var jobNamaFolder: Job? = null
    private val dengarPemutar: () -> Unit = { perbaruiPemutarUi() }

    // ---- unduh ----
    private val pilihanAudio = listOf("128 kbps (hemat)" to 128, "192 kbps" to 192, "256 kbps" to 256, "320 kbps (terbaik)" to 320)
    private val pilihanVideo: List<Pair<String, Int?>> = listOf(
        "Terbaik tersedia" to null, "4K / 2160p" to 2160, "1440p" to 1440,
        "1080p Full HD" to 1080, "720p HD" to 720, "480p" to 480, "360p" to 360
    )
    private var indeksAudio = 0
    private var indeksVideo = 3
    private var indeksEfekU = 0
    private var info: InfoMedia? = null
    private var jobInfo: Job? = null
    private var urlPratinjau: String? = null

    // ---- konversi ----
    private enum class Jenis { GAMBAR, VIDEO, AUDIO }
    private class BerkasKonv(val uri: Uri, val nama: String, val jenis: Jenis)
    private enum class Alat(val label: String, val opsi: List<String>) {
        FORMAT_GAMBAR("Ubah format gambar", listOf("JPG", "PNG", "WEBP")),
        PERKECIL("Perkecil gambar", listOf("75%", "50%", "25%")),
        PDF("Gambar → satu PDF", emptyList()),
        KE_AUDIO("Ubah / ekstrak ke audio", listOf("MP3", "M4A")),
        KOMPRES("Kompres video", listOf("720p", "480p", "360p")),
        GIF("Video → GIF", listOf("Kecil (320 px)", "Sedang (480 px)", "Besar (640 px)"))
    }
    private var berkasKonv: List<BerkasKonv> = emptyList()
    private var alatTersedia: List<Alat> = emptyList()
    private var indeksAlat = 0
    private var indeksOpsiK = 0
    private var indeksEfekK = 0
    private var konversiBerjalan = false
    private var batalKonversi = false
    private var idKonversi: String? = null

    // ---- pemutar ----
    private val pilihanTidur = listOf("Timer tidur: mati" to 0, "15 menit" to 15, "30 menit" to 30, "60 menit" to 60)
    private val ticker = object : Runnable {
        override fun run() {
            perbaruiSeek()
            if (tabAktif == TAB_PUTAR && pemutar.sedangMain) handler.postDelayed(this, 500)
        }
    }

    // ---- kontrak hasil ----
    private val pemilihFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { if (it != null) simpanFolder(it) }
    private val pemilihFile = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) pilihFile(it) }
    private val pemilihCookies = registerForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) impor(it) }
    private val pemilihLatar = registerForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) simpanLatar(it) }
    private val pemintaNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // =========================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Catatan.init(applicationContext)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        pasangTepiKeTepi()
        muatLatar()
        pulihFolder()

        binding.rvRiwayat.layoutManager = LinearLayoutManager(this)
        binding.rvRiwayat.adapter = adapterRiwayat

        pasangTab()
        pasangUnduh()
        pasangJelajah()
        pasangKonversi()
        pasangPutar()
        pasangRiwayat()
        pasangAtur()

        pasangTombolKembali()
        siapkanMesin()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                AntrianUnduh.status.collect { statusAntrian = it; render() }
            }
        }
        tanganiIntent(intent)
        perbaruiOpsiKualitas()
        render()

        // Tugas ringan setelah layar tampil, supaya tidak menghambat startup:
        // bersihkan sisa konversi lama, lalu cek pembaruan (maks 1x/12 jam, hemat data).
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { File(cacheDir, "konversi").deleteRecursively() }
            delay(2000)
            cekPembaruan(false)
        }
    }

    private fun siapkanMesin() {
        mesinGagal = false
        lifecycleScope.launch {
            mesinSiap = Mesin.siapkan(application)
            mesinGagal = !mesinSiap
            render()
        }
    }

    override fun onStart() {
        super.onStart()
        pemutar.dengar(dengarPemutar)
        perbaruiPemutarUi()
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        pemutar.lepasDengar(dengarPemutar)
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tanganiIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) tawarkanKlip()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    /**
     * Latar sampai ke balik status bar & navigasi. Kartu status melayang di bawah layar, jadi ruang
     * bawah daftar konten disesuaikan dengan tinggi kartu (atau tinggi keyboard bila lebih besar).
     */
    private fun pasangTepiKeTepi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bar = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            insetAtas = bar.top
            insetBawah = bar.bottom
            insetIme = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            terapkanPadding()
            insets
        }
        binding.cardStatus.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> terapkanPadding() }
        binding.cardMini.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> terapkanPadding() }
        binding.bottomNav.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> terapkanPadding() }
    }

    private fun terapkanPadding() {
        val dasar = dp(20)
        val jarak = dp(12)
        val status = binding.cardStatus
        val mini = binding.cardMini
        // Kartu melayang berada di atas bilah navigasi bawah (tingginya sudah termasuk inset sistem).
        val navTinggi = if (binding.bottomNav.height > 0) binding.bottomNav.height else insetBawah + dp(80)
        val marginStatus = jarak + navTinggi
        val lpStatus = status.layoutParams as FrameLayout.LayoutParams
        if (lpStatus.bottomMargin != marginStatus) { lpStatus.bottomMargin = marginStatus; status.layoutParams = lpStatus }

        val statusTampak = status.visibility == View.VISIBLE
        // Mini player duduk tepat di atas kartu status bila keduanya tampil.
        val marginMini = if (statusTampak) marginStatus + status.height + jarak else marginStatus
        val lpMini = mini.layoutParams as FrameLayout.LayoutParams
        if (lpMini.bottomMargin != marginMini) { lpMini.bottomMargin = marginMini; mini.layoutParams = lpMini }

        val ruang = when {
            mini.visibility == View.VISIBLE -> marginMini + mini.height
            statusTampak -> marginStatus + status.height
            else -> navTinggi
        }
        val bawah = maxOf(insetIme, ruang) + dasar
        val atas = dasar + insetAtas
        val gulir = binding.scroll
        if (gulir.paddingBottom != bawah || gulir.paddingTop != atas) gulir.setPadding(dasar, atas, dasar, bawah)
    }

    private fun pasangTombolKembali() {
        // Callback hanya aktif saat bukan di tab Unduh; di tab Unduh Back berperilaku normal.
        // (Versi lama mematikan callback permanen saat keluar, jadi setelah aplikasi dibuka lagi
        // tombol Back langsung menutup aplikasi dari tab mana pun.)
        onBackPressedDispatcher.addCallback(this, kembaliKeUnduh)
    }

    /** Snackbar harus berada di atas kartu melayang (mini player lalu kartu status). */
    private fun jangkar(): View? = when {
        binding.cardMini.visibility == View.VISIBLE -> binding.cardMini
        binding.cardStatus.visibility == View.VISIBLE -> binding.cardStatus
        else -> binding.bottomNav
    }

    private fun snack(t: String) {
        val sb = Snackbar.make(binding.root, t, Snackbar.LENGTH_SHORT)
        // Jangan tertutup kartu status yang melayang di bawah.
        jangkar()?.let { sb.anchorView = it }
        sb.show()
    }

    private fun snackAksi(teks: String, aksi: String, klik: () -> Unit) {
        val sb = Snackbar.make(binding.root, teks, Snackbar.LENGTH_LONG).setAction(aksi) { klik() }
        jangkar()?.let { sb.anchorView = it }
        sb.show()
    }

    // =========================================================================
    // Tab
    // =========================================================================
    /**
     * Navigasi: bilah bawah (5 tujuan) + pilihan "Dari link / Dari file" di dalam Unduh.
     * Konversi digabung ke Unduh karena keduanya sama-sama alat file; enam tab di atas sulit
     * dijangkau jempol dan membingungkan.
     */
    private fun pasangTab() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            val tab = when (item.itemId) {
                R.id.nav_jelajah -> TAB_JELAJAH
                R.id.nav_putar -> TAB_PUTAR
                R.id.nav_unduh ->
                    if (binding.toggleAlat.checkedButtonId == R.id.btnDariFile) TAB_KONVERSI else TAB_UNDUH
                R.id.nav_pustaka -> TAB_RIWAYAT
                else -> TAB_ATUR
            }
            tampilkanTab(tab)
            true
        }
        // Ketuk lagi menu yang sedang aktif = kembali ke atas halaman
        binding.bottomNav.setOnItemReselectedListener { binding.scroll.smoothScrollTo(0, 0) }
        binding.toggleAlat.addOnButtonCheckedListener { _, id, dicek ->
            if (dicek) tampilkanTab(if (id == R.id.btnDariFile) TAB_KONVERSI else TAB_UNDUH)
        }
        binding.bottomNav.selectedItemId = R.id.nav_jelajah
        tampilkanTab(TAB_BERANDA)
    }

    /** Pindah ke halaman mana pun dari kode (notifikasi, mini player, berbagi link, dll). */
    private fun pilihTab(i: Int) {
        val idNav = when (i) {
            TAB_JELAJAH -> R.id.nav_jelajah
            TAB_PUTAR -> R.id.nav_putar
            TAB_UNDUH, TAB_KONVERSI -> R.id.nav_unduh
            TAB_RIWAYAT -> R.id.nav_pustaka
            else -> R.id.nav_atur
        }
        if (i == TAB_UNDUH || i == TAB_KONVERSI) {
            val target = if (i == TAB_KONVERSI) R.id.btnDariFile else R.id.btnDariLink
            if (binding.toggleAlat.checkedButtonId != target) binding.toggleAlat.check(target)
        }
        if (binding.bottomNav.selectedItemId != idNav) binding.bottomNav.selectedItemId = idNav
        else tampilkanTab(i)
    }

    private fun tampilkanTab(i: Int) {
        val berubah = i != tabAktif
        tabAktif = i
        kembaliKeUnduh.isEnabled = i != TAB_BERANDA
        fun v(b: Boolean) = if (b) View.VISIBLE else View.GONE
        binding.panelUnduh.visibility = v(i == TAB_UNDUH)
        binding.panelJelajah.visibility = v(i == TAB_JELAJAH)
        binding.panelKonversi.visibility = v(i == TAB_KONVERSI)
        binding.panelPutar.visibility = v(i == TAB_PUTAR)
        binding.panelRiwayat.visibility = v(i == TAB_RIWAYAT)
        binding.panelAtur.visibility = v(i == TAB_ATUR)
        binding.cardFolder.visibility = v(i == TAB_UNDUH || i == TAB_KONVERSI || i == TAB_PUTAR)
        binding.cardStatus.visibility = v(i == TAB_UNDUH || i == TAB_KONVERSI)
        if (berubah) {
            val panel = when (i) {
                TAB_UNDUH -> binding.panelUnduh
                TAB_JELAJAH -> binding.panelJelajah
                TAB_KONVERSI -> binding.panelKonversi
                TAB_PUTAR -> binding.panelPutar
                TAB_RIWAYAT -> binding.panelRiwayat
                else -> binding.panelAtur
            }
            panel.alpha = 0f
            panel.animate().alpha(1f).setDuration(160).start()
        }
        perbaruiMini()
        binding.cardStatus.post { terapkanPadding() }
        handler.removeCallbacks(ticker)
        if (i == TAB_PUTAR) {
            if (pemutar.daftar.isEmpty() && folderUri != null) muatDaftar()
            perbaruiPemutarUi()
        }
        if (i == TAB_RIWAYAT) muatRiwayat()
        if (i == TAB_ATUR) hitungCache()
    }

    // =========================================================================
    // Folder & umum
    // =========================================================================
    private fun pulihFolder() {
        // Pemasangan klik harus SELALU terjadi, termasuk saat belum ada folder tersimpan
        // (sebelumnya `?: return` melewatinya sehingga tombol mati di pemakaian pertama).
        binding.btnPilihFolder.setOnClickListener { pemilihFolder.launch(null) }
        val tersimpan = prefs.folderUri?.toUri()
        if (tersimpan != null) {
            val masih = contentResolver.persistedUriPermissions.any { it.uri == tersimpan && it.isWritePermission }
            if (masih) folderUri = tersimpan else prefs.folderUri = null
        }
        perbaruiFolderUi()
    }

    private fun simpanFolder(uri: Uri) {
        val izinOk = runCatching {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }.onFailure { Catatan.tulis("Gagal mengambil izin folder: ${it.message}") }.isSuccess
        if (!izinOk) { snack("Folder ini tidak bisa dipakai. Pilih folder lain."); return }
        val lama = folderUri
        val berubah = uri != lama
        // Izin permanen dibatasi jumlahnya oleh sistem: lepaskan folder lama yang tak dipakai lagi.
        if (lama != null && berubah) {
            runCatching {
                contentResolver.releasePersistableUriPermission(
                    lama, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        folderUri = uri
        prefs.folderUri = uri.toString()
        // Daftar lagu di tab Putar berasal dari folder lama; kosongkan agar dimuat ulang dari folder baru.
        if (berubah) pemutar.reset()
        perbaruiFolderUi()
        render()
    }

    private fun perbaruiFolderUi() {
        val f = folderUri
        binding.btnPilihFolder.text = if (f == null) "Pilih folder" else "Ganti folder"
        jobNamaFolder?.cancel()
        if (f == null) { binding.tvFolderName.text = "Belum dipilih"; return }
        binding.tvFolderName.text = f.lastPathSegment ?: "Folder dipilih"
        // Menanyakan nama ke penyedia file (SAF) bisa lambat: jangan di thread utama.
        jobNamaFolder = lifecycleScope.launch {
            val nama = withContext(Dispatchers.IO) {
                runCatching { DocumentFile.fromTreeUri(this@MainActivity, f)?.name }.getOrNull()
            }
            if (nama != null) binding.tvFolderName.text = nama
        }
    }

    private fun tanganiIntent(intent: Intent?) {
        val tab = intent?.getIntExtra(EKSTRA_TAB, -1) ?: -1
        if (tab in TAB_UNDUH..TAB_ATUR) {
            pilihTab(tab)
            intent?.removeExtra(EKSTRA_TAB)
        }
        if (intent?.action != Intent.ACTION_SEND) return
        val teks = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        ambilUrl(teks)?.let {
            pilihTab(TAB_UNDUH)
            binding.etUrl.setText(it)
        }
    }

    private fun ambilUrl(teks: CharSequence?): String? {
        if (teks.isNullOrBlank()) return null
        val m = Patterns.WEB_URL.matcher(teks)
        if (!m.find()) return null
        val url = m.group()
        return if (url.startsWith("http", ignoreCase = true)) url else "https://$url"
    }

    /** Link di clipboard ditawarkan sekali saja per link, dan hanya bila kolom link kosong. */
    private fun tawarkanKlip() {
        if (binding.etUrl.text?.isNotBlank() == true) return
        val klip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        // Membaca isi klip di Android 12+ memunculkan toast "menempel dari clipboard" setiap kali.
        // Deskripsi klip bisa dibaca tanpa itu, jadi isi hanya dibaca bila klipnya benar-benar baru.
        val desk = klip.primaryClipDescription ?: return
        if (!desk.hasMimeType("text/*")) return
        if (Build.VERSION.SDK_INT >= 26) {
            val stempel = desk.timestamp
            if (stempel == stempelKlip) return
            stempelKlip = stempel
        }
        val teks = runCatching { klip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() }.getOrNull()
        val url = ambilUrl(teks) ?: return
        if (url == klipTerakhir) return
        klipTerakhir = url
        snackAksi("Ada link di clipboard", "Tempel") { pilihTab(TAB_UNDUH); binding.etUrl.setText(url) }
    }

    // =========================================================================
    // Status bersama (kartu bawah)
    // =========================================================================
    private fun render() {
        val s = statusAntrian
        val aktif = s.aktif
        val bar = binding.progressBar
        fun v(b: Boolean) = if (b) View.VISIBLE else View.GONE

        if (aktif != null) {
            bar.visibility = View.VISIBLE
            binding.tvProgress.visibility = View.VISIBLE
            if (s.persen < 0) { if (!bar.isIndeterminate) bar.isIndeterminate = true }
            else { if (bar.isIndeterminate) bar.isIndeterminate = false; bar.setProgressCompat(s.persen, true) }
            binding.tvProgress.setTeks(if (s.persen >= 0) "${s.persen}%" else "")
            val sisa = if (s.antre.isNotEmpty()) " • ${s.antre.size} menunggu" else ""
            binding.tvStatus.setTeks("${s.tahap}$sisa\n${aktif.judul}")
            binding.tvAnna.setTeks(Anna.kerja(aktif.id.hashCode()))
            pesanKonversi = null // unduhan baru dimulai: hasil konversi lama tak relevan lagi
        } else if (!konversiBerjalan) {
            bar.visibility = View.GONE
            binding.tvProgress.visibility = View.GONE
            val pk = pesanKonversi
            // Hasil konversi harus tetap terlihat (sebelumnya langsung ditimpa pesan siaga).
            binding.tvStatus.setTeks(pk ?: s.pesan ?: statusDiam())
            binding.tvAnna.setTeks(
                if (pk != null) (if (konversiOk) Anna.sukses() else Anna.gagal())
                else when (s.pesanSukses) {
                    true -> Anna.sukses(s.sukses)
                    false -> Anna.gagal(s.gagal)
                    null -> Anna.santai()
                }
            )
        }

        binding.btnJeda.visibility = v(aktif != null)
        binding.btnBatal.visibility = v(aktif != null)
        binding.btnLanjut.visibility = v(s.terjeda.isNotEmpty())
        binding.btnKosongkan.visibility = v(s.antre.isNotEmpty() || s.terjeda.isNotEmpty())
        binding.btnCoba.visibility = v(aktif == null && s.gagalTerakhir != null)
        binding.rowKontrol.visibility = v(
            aktif != null || s.terjeda.isNotEmpty() || s.antre.isNotEmpty() || s.gagalTerakhir != null
        )
        // Tetap aktif: alasan yang belum terpenuhi dijelaskan lewat pesan saat ditekan.
        binding.btnUnduh.isEnabled = true
        perbaruiTombolKonversi()
    }

    private fun statusDiam() = when {
        mesinGagal -> "Gagal memuat mesin pengunduh. Coba buka ulang aplikasi."
        !mesinSiap -> "Menyiapkan mesin pengunduh…"
        folderUri == null -> "Pilih folder simpan dulu."
        else -> "Siap. Tempel link lalu tambahkan ke antrean."
    }

    // =========================================================================
    // Tab UNDUH
    // =========================================================================
    private fun pasangUnduh() {
        binding.tilUrl.setEndIconOnClickListener {
            val klip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val teks = klip.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (teks.isNullOrBlank()) snack("Clipboard kosong") else binding.etUrl.setText(ambilUrl(teks) ?: teks.trim())
        }
        binding.etUrl.doAfterTextChanged { t ->
            binding.tilUrl.error = null
            val urlBaru = ambilUrl(t)
            if (jobInfo?.isActive == true && urlPratinjau != urlBaru) {
                jobInfo?.cancel()
                downloader.batalkanInfo()
                binding.btnPratinjau.isEnabled = true
                binding.btnPratinjau.text = "Pratinjau link (ukuran, playlist)"
            }
            if (info != null && info?.url != urlBaru) {
                info = null
                binding.cardPratinjau.visibility = View.GONE
                perbaruiOpsiKualitas()
            }
        }
        binding.etUrl.setOnEditorActionListener { _, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_DONE) { tambahKeAntrean(); true } else false
        }
        binding.btnPratinjau.setOnClickListener { pratinjau(false) }
        binding.toggleFormat.addOnButtonCheckedListener { _, _, dicek -> if (dicek) perbaruiOpsiKualitas() }

        binding.actEfekU.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Efek.values().map { it.label }))
        binding.actEfekU.setText(Efek.values()[0].label, false)
        binding.actEfekU.setOnItemClickListener { _, _, p, _ -> indeksEfekU = p }

        binding.btnLanjutan.setOnClickListener {
            val buka = binding.layoutLanjutan.visibility != View.VISIBLE
            binding.layoutLanjutan.visibility = if (buka) View.VISIBLE else View.GONE
            binding.btnLanjutan.text = if (buka) "Opsi lanjutan  ▴" else "Opsi lanjutan  ▾"
        }

        binding.btnUnduh.setOnClickListener { tambahKeAntrean() }
        binding.btnJeda.setOnClickListener { AntrianUnduh.hentikanAktif(true) }
        binding.btnBatal.setOnClickListener { AntrianUnduh.hentikanAktif(false) }
        binding.btnKosongkan.setOnClickListener { AntrianUnduh.kosongkanAntre() }
        binding.btnCoba.setOnClickListener {
            val t = statusAntrian.gagalTerakhir ?: return@setOnClickListener
            AntrianUnduh.hapusGagal()
            DownloadService.mulai(this, listOf(t.copy(id = UUID.randomUUID().toString())))
        }
        binding.btnLanjut.setOnClickListener {
            AntrianUnduh.lanjutkan()
            DownloadService.mulai(this, emptyList())
        }
    }

    private fun musikDipilih() = binding.toggleFormat.checkedButtonId == R.id.btnMp3

    private fun perbaruiOpsiKualitas() {
        val musik = musikDipilih()
        val infoIni = info
        val label = if (musik) pilihanAudio.map { it.first }
        else pilihanVideo.map { (nama, tinggi) ->
            val u = infoIni?.perkiraan(tinggi) ?: 0L
            if (u > 0) "$nama (≈ ${formatUkuran(u)})" else nama
        }
        val indeks = if (musik) indeksAudio else indeksVideo
        binding.actKualitas.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, label))
        binding.actKualitas.setText(label[indeks], false)
        binding.actKualitas.setOnItemClickListener { _, _, p, _ -> if (musik) indeksAudio = p else indeksVideo = p }
        binding.tilEfekU.visibility = if (musik) View.VISIBLE else View.GONE
    }

    private fun opsiSaatIni(): Opsi? {
        val mulai = binding.etMulaiU.text?.toString()?.trim().orEmpty().ifEmpty { null }
        val akhir = binding.etAkhirU.text?.toString()?.trim().orEmpty().ifEmpty { null }
        binding.tilMulaiU.error = null
        binding.tilAkhirU.error = null
        if (mulai != null && !waktuValid(mulai)) { bukaLanjutan(); binding.tilMulaiU.error = "Contoh: 1:30"; return null }
        if (akhir != null && !waktuValid(akhir)) { bukaLanjutan(); binding.tilAkhirU.error = "Contoh: 2:45"; return null }
        if (!rentangValid(mulai, akhir)) { bukaLanjutan(); binding.tilAkhirU.error = "Akhir harus lebih besar dari mulai"; return null }
        return Opsi(
            format = if (musikDipilih()) FormatUnduh.MP3 else FormatUnduh.MP4,
            audioKbps = pilihanAudio[indeksAudio].second,
            tinggi = pilihanVideo[indeksVideo].second,
            efek = Efek.values()[indeksEfekU],
            mulai = mulai,
            akhir = akhir
        )
    }

    private fun bukaLanjutan() {
        binding.layoutLanjutan.visibility = View.VISIBLE
        binding.btnLanjutan.text = "Opsi lanjutan  ▴"
    }

    private fun pratinjau(lanjut: Boolean) {
        val url = ambilUrl(binding.etUrl.text)
        if (url == null) { binding.tilUrl.error = "Tempel link dulu ya"; return }
        jobInfo?.cancel()
        downloader.batalkanInfo()
        urlPratinjau = url
        binding.btnPratinjau.isEnabled = false
        binding.btnPratinjau.text = "Memuat info…"
        jobInfo = lifecycleScope.launch {
            val hasil = runCatching { downloader.info(url) }
            // Dibatalkan (pratinjau baru atau link diganti): jangan tampilkan hasil/galat basi.
            if (!isActive) return@launch
            binding.btnPratinjau.isEnabled = true
            binding.btnPratinjau.text = "Pratinjau link (ukuran, playlist)"
            hasil.onSuccess { tampilkanInfo(it); if (lanjut) tambahKeAntrean() }
            hasil.onFailure {
                Catatan.tulis("Pratinjau gagal: ${it.message?.take(400)}")
                val pesan = ringkasError(it)
                snack("Gagal memuat info: $pesan" + if (perluPerbarui(pesan)) " — coba Atur → Perbarui mesin" else "")
            }
        }
    }

    private fun tampilkanInfo(i: InfoMedia) {
        info = i
        binding.cardPratinjau.visibility = View.VISIBLE
        binding.tvJudulP.text = i.judul.ifBlank { i.url }
        binding.tvMetaP.text = if (i.playlist) "Playlist • ${i.entri.size} video" + if (i.kanal.isNotBlank()) " • ${i.kanal}" else ""
        else listOf(i.kanal, if (i.durasi > 0) formatDurasi(i.durasi) else "").filter { it.isNotBlank() }.joinToString(" • ")
        binding.imgThumb.setImageDrawable(null)
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { muatGambar(i.thumb) }
            if (bmp != null && info === i) binding.imgThumb.setImageBitmap(bmp)
        }
        perbaruiOpsiKualitas()
    }

    private fun muatGambar(url: String?): Bitmap? {
        if (url == null) return null
        return runCatching {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val bytes = c.inputStream.use { it.readBytes() }
            val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, batas)
            var s = 1
            while (batas.outWidth / s > 480) s *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
        }.getOrNull()
    }

    private fun tambahKeAntrean() {
        if (folderUri == null) { snack("Pilih folder simpan dulu"); return }
        if (!mesinSiap) {
            if (mesinGagal) { snack("Menyiapkan ulang mesin pengunduh…"); siapkanMesin() }
            else snack("Mesin masih disiapkan, sebentar ya…")
            return
        }
        val url = ambilUrl(binding.etUrl.text)
        if (url == null) { binding.tilUrl.error = "Tempel link yang valid"; return }
        if (prefs.wifiOnly && !Jaringan.wifi(this)) { snack("Mode 'Hanya Wi-Fi' aktif. Sambungkan Wi-Fi dulu."); return }
        val opsi = opsiSaatIni() ?: return

        val infoIni = info?.takeIf { it.url == url }
        if (infoIni?.playlist == true) { dialogPlaylist(infoIni, opsi); return }
        if (infoIni == null && url.contains("/playlist?")) { pratinjau(true); return }

        val judul = infoIni?.judul?.ifBlank { null } ?: url.removePrefix("https://").removePrefix("www.").take(60)
        masukkan(listOf(Tugas(UUID.randomUUID().toString(), url, judul, opsi)))
    }

    private fun dialogPlaylist(i: InfoMedia, opsi: Opsi) {
        val judul = i.entri.map { it.judul }.toTypedArray()
        val dipilih = BooleanArray(judul.size) { true }
        MaterialAlertDialogBuilder(this)
            .setTitle("${i.judul.ifBlank { "Playlist" }} (${judul.size})")
            .setMultiChoiceItems(judul, dipilih) { _, p, c -> dipilih[p] = c }
            .setPositiveButton("Unduh") { _, _ ->
                val tugas = i.entri.filterIndexed { p, _ -> dipilih[p] }
                    .map { Tugas(UUID.randomUUID().toString(), it.url, it.judul, opsi) }
                if (tugas.isNotEmpty()) masukkan(tugas)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun mintaIzinNotif() {
        if (Build.VERSION.SDK_INT >= 33 && !prefs.pernahMintaNotif &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.pernahMintaNotif = true
            pemintaNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun masukkan(tugas: List<Tugas>, bersihkanUrl: Boolean = true) {
        mintaIzinNotif()
        DownloadService.mulai(this, tugas)
        if (bersihkanUrl) binding.etUrl.text?.clear()
        snack(if (tugas.size == 1) "Ditambahkan ke antrean" else "${tugas.size} video ditambahkan ke antrean")
    }

    // =========================================================================
    // Tab JELAJAH (cari & putar langsung, ala Metrolist)
    // =========================================================================
    private fun pasangJelajah() {
        binding.rvJelajah.layoutManager = LinearLayoutManager(this)
        binding.rvJelajah.adapter = adapterJelajah
        binding.rvJelajah.itemAnimator = null

        binding.etCariLagu.setOnEditorActionListener { _, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_SEARCH) {
                cariLagu(binding.etCariLagu.text?.toString().orEmpty()); true
            } else false
        }
        binding.etCariLagu.setOnItemClickListener { induk, _, pos, _ ->
            cariLagu(induk.getItemAtPosition(pos).toString())
        }
        binding.etCariLagu.doAfterTextChanged { t -> mintaSaran(t?.toString()?.trim().orEmpty()) }
        binding.btnPutarSemua.setOnClickListener { putarHasil(0, acak = false) }
        binding.btnAcakHasil.setOnClickListener {
            if (hasilCari.isNotEmpty()) putarHasil(Random.nextInt(hasilCari.size), acak = true)
        }
    }

    /** Saran ketikan: ditunda 250 ms supaya tidak menembak server di setiap huruf. */
    private fun mintaSaran(q: String) {
        jobSaran?.cancel()
        if (q.length < 2) return
        jobSaran = lifecycleScope.launch {
            delay(250)
            val saran = Jelajah.saran(q)
            // Jangan buka daftar bila teks sudah berubah, bila ini hasil memilih saran, atau kolom tak difokus.
            if (saran.isEmpty() || q == kueriTerakhir || !binding.etCariLagu.hasFocus()) return@launch
            if (binding.etCariLagu.text?.toString()?.trim() != q) return@launch
            binding.etCariLagu.setAdapter(AdapterSaran(this@MainActivity, saran))
            binding.etCariLagu.showDropDown()
        }
    }

    private fun cariLagu(kueri: String) {
        val q = kueri.trim()
        if (q.isEmpty()) return
        kueriTerakhir = q
        jobSaran?.cancel()
        binding.etCariLagu.dismissDropDown()
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(binding.etCariLagu.windowToken, 0)
        binding.etCariLagu.clearFocus()
        jobCari?.cancel()
        hasilCari = emptyList()
        adapterJelajah.submitList(emptyList())
        binding.barAksiJelajah.visibility = View.GONE
        binding.tvJelajah.visibility = View.VISIBLE
        binding.tvJelajah.text = "Mencari “$q”…"
        jobCari = lifecycleScope.launch {
            runCatching { Jelajah.cari(applicationContext, q) }
                .onSuccess { hasil ->
                    hasilCari = hasil
                    adapterJelajah.submitList(hasil)
                    binding.barAksiJelajah.visibility = if (hasil.isEmpty()) View.GONE else View.VISIBLE
                    binding.tvJelajah.visibility = if (hasil.isEmpty()) View.VISIBLE else View.GONE
                    if (hasil.isEmpty()) binding.tvJelajah.text = "Tidak ada hasil untuk “$q”."
                }
                .onFailure {
                    if (!isActive) return@onFailure // dibatalkan oleh pencarian baru
                    Catatan.tulis("Pencarian gagal: ${it.message?.take(300)}")
                    binding.tvJelajah.text = "Pencarian gagal: ${ringkasError(it)}"
                }
        }
    }

    private fun putarHasil(mulai: Int, acak: Boolean? = null) {
        if (hasilCari.isEmpty()) return
        if (prefs.wifiOnly && !Jaringan.wifi(this)) {
            snack("Mode 'Hanya Wi-Fi' aktif. Sambungkan Wi-Fi untuk memutar online.")
            return
        }
        if (!mesinSiap) { snack("Mesin masih disiapkan, sebentar ya…"); return }
        mintaIzinNotif()
        if (acak != null) pemutar.setAcak(acak)
        pemutar.setAntrean(
            hasilCari.map { Lagu(Uri.EMPTY, it.judul, it.id, it.artis, it.thumb) },
            mulai.coerceIn(0, hasilCari.lastIndex)
        )
    }

    private fun unduhHasil(h: HasilLagu) {
        if (folderUri == null) { snack("Pilih folder simpan dulu (di tab Unduh)"); return }
        if (!mesinSiap) { snack("Mesin masih disiapkan, sebentar ya…"); return }
        if (prefs.wifiOnly && !Jaringan.wifi(this)) { snack("Mode 'Hanya Wi-Fi' aktif. Sambungkan Wi-Fi dulu."); return }
        val opsi = Opsi(FormatUnduh.MP3, pilihanAudio[indeksAudio].second, null)
        masukkan(
            listOf(Tugas(UUID.randomUUID().toString(), "https://music.youtube.com/watch?v=${h.id}", h.judul, opsi)),
            bersihkanUrl = false
        )
    }

    /** Mini player melayang di semua tab kecuali Putar, seperti Metrolist. */
    private fun perbaruiMini() {
        val tampil = pemutar.aktif && tabAktif != TAB_PUTAR
        if (tampil) {
            binding.tvMiniJudul.setTeks(pemutar.judul)
            binding.tvMiniArtis.setTeks(if (pemutar.menyiapkan) "Menyiapkan…" else pemutar.artis.orEmpty())
            val sampul = pemutar.sampul ?: Sampul.bawaan(this)
            if (sampulMini !== sampul) { binding.imgMini.setImageBitmap(sampul); sampulMini = sampul }
            binding.btnMiniPlay.setIconResource(
                if (pemutar.sedangMain || pemutar.menyiapkan) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
        if (tampil != miniTampak) {
            miniTampak = tampil
            binding.cardMini.visibility = if (tampil) View.VISIBLE else View.GONE
            binding.cardMini.post { terapkanPadding() }
        }
    }

    // =========================================================================
    // Tab KONVERSI
    // =========================================================================
    private fun pasangKonversi() {
        binding.btnPilihFile.setOnClickListener { pemilihFile.launch(arrayOf("image/*", "video/*", "audio/*")) }
        binding.btnKonversi.setOnClickListener { mulaiKonversi() }
        binding.btnBatalKonversi.setOnClickListener {
            batalKonversi = true
            idKonversi?.let(converter::batalkan)
        }
        binding.actEfekK.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Efek.values().map { it.label }))
        binding.actEfekK.setText(Efek.values()[0].label, false)
        binding.actEfekK.setOnItemClickListener { _, _, p, _ -> indeksEfekK = p }
    }

    private fun namaDari(uri: Uri): String =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment ?: "file"

    private fun pilihFile(uris: List<Uri>) {
        val semua = uris.mapNotNull { u ->
            val tipe = contentResolver.getType(u).orEmpty()
            val j = when {
                tipe.startsWith("image/") -> Jenis.GAMBAR
                tipe.startsWith("video/") -> Jenis.VIDEO
                tipe.startsWith("audio/") -> Jenis.AUDIO
                else -> null
            }
            j?.let { BerkasKonv(u, namaDari(u), it) }
        }
        if (semua.isEmpty()) { snack("Hanya file gambar, video, atau audio yang didukung"); return }

        val gambar = semua.first().jenis == Jenis.GAMBAR
        berkasKonv = semua.filter { (it.jenis == Jenis.GAMBAR) == gambar }
        val dilewati = semua.size - berkasKonv.size
        alatTersedia = when {
            gambar -> listOf(Alat.FORMAT_GAMBAR, Alat.PERKECIL, Alat.PDF)
            berkasKonv.all { it.jenis == Jenis.VIDEO } -> listOf(Alat.KE_AUDIO, Alat.KOMPRES, Alat.GIF)
            else -> listOf(Alat.KE_AUDIO)
        }
        indeksAlat = 0
        indeksOpsiK = 0
        indeksEfekK = 0
        binding.actEfekK.setText(Efek.values()[0].label, false)

        binding.tvFileKonversi.text = if (berkasKonv.size == 1) berkasKonv[0].nama
        else "${berkasKonv.size} file • ${berkasKonv[0].nama}, …"
        if (dilewati > 0) snack("$dilewati file berbeda jenis dilewati")

        binding.actAlat.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, alatTersedia.map { it.label }))
        binding.actAlat.setText(alatTersedia[0].label, false)
        binding.actAlat.setOnItemClickListener { _, _, p, _ -> indeksAlat = p; indeksOpsiK = 0; terapkanAlat() }
        terapkanAlat()
    }

    private fun terapkanAlat() {
        val alat = alatTersedia.getOrNull(indeksAlat) ?: return
        binding.tilFormatKonversi.visibility = if (alat.opsi.isEmpty()) View.GONE else View.VISIBLE
        if (alat.opsi.isNotEmpty()) {
            binding.actFormatKonversi.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, alat.opsi))
            binding.actFormatKonversi.setText(alat.opsi[0], false)
            binding.actFormatKonversi.setOnItemClickListener { _, _, p, _ -> indeksOpsiK = p }
        }
        binding.tilEfekK.visibility = if (alat == Alat.KE_AUDIO) View.VISIBLE else View.GONE
        binding.rowPotongK.visibility = if (alat == Alat.KE_AUDIO || alat == Alat.GIF) View.VISIBLE else View.GONE
        perbaruiTombolKonversi()
    }

    private fun perbaruiTombolKonversi() {
        val alat = alatTersedia.getOrNull(indeksAlat)
        val butuhMesin = alat == Alat.KE_AUDIO || alat == Alat.KOMPRES || alat == Alat.GIF
        binding.btnKonversi.isEnabled = !konversiBerjalan && berkasKonv.isNotEmpty() && folderUri != null &&
            (!butuhMesin || mesinSiap)
        binding.btnPilihFile.isEnabled = !konversiBerjalan
        binding.btnBatalKonversi.visibility =
            if (konversiBerjalan && butuhMesin) View.VISIBLE else View.GONE
    }

    private fun tampilKonversi(teks: String, ok: Boolean? = null, berjalan: Boolean = true) {
        if (statusAntrian.aktif != null) return
        binding.progressBar.visibility = if (berjalan) View.VISIBLE else View.GONE
        if (berjalan) binding.progressBar.isIndeterminate = true
        binding.tvProgress.visibility = View.GONE
        binding.tvStatus.text = teks
        binding.tvAnna.text = when (ok) { true -> Anna.sukses(); false -> Anna.gagal(); null -> Anna.kerja(1) }
    }

    private fun mulaiKonversi() {
        val folder = folderUri ?: run { snack("Pilih folder simpan dulu"); return }
        val alat = alatTersedia.getOrNull(indeksAlat) ?: run { snack("Pilih file dulu"); return }
        if (konversiBerjalan) return

        val mulai = binding.etMulaiK.text?.toString()?.trim().orEmpty().ifEmpty { null }
        val akhir = binding.etAkhirK.text?.toString()?.trim().orEmpty().ifEmpty { null }
        binding.tilMulaiK.error = null
        binding.tilAkhirK.error = null
        val pakaiPotong = alat == Alat.KE_AUDIO || alat == Alat.GIF
        if (pakaiPotong && mulai != null && !waktuValid(mulai)) { binding.tilMulaiK.error = "Contoh: 1:30"; return }
        if (pakaiPotong && akhir != null && !waktuValid(akhir)) { binding.tilAkhirK.error = "Contoh: 2:45"; return }
        if (pakaiPotong && !rentangValid(mulai, akhir)) { binding.tilAkhirK.error = "Akhir harus lebih besar dari mulai"; return }

        val daftar = berkasKonv
        konversiBerjalan = true
        batalKonversi = false
        pesanKonversi = null
        converter.reset()
        render() // tampilkan kartu status segera
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        perbaruiTombolKonversi()

        lifecycleScope.launch {
            var ok = 0
            var gagal = 0
            var pesanGagal = ""
            fun catat(h: HasilKonversi) {
                when (h) {
                    is HasilKonversi.Sukses -> {
                        ok++
                        h.uri?.let {
                            riwayat.tambah(
                                Entri(namaDasar(h.nama), h.nama, h.nama.substringAfterLast('.').uppercase(),
                                    h.ukuran, System.currentTimeMillis(), it.toString())
                            )
                        }
                    }
                    is HasilKonversi.Gagal -> { gagal++; pesanGagal = h.pesan }
                    HasilKonversi.Dibatalkan -> batalKonversi = true
                }
            }

            if (alat == Alat.PDF) {
                tampilKonversi("Membuat PDF dari ${daftar.size} gambar…")
                catat(converter.gambarKePdf(daftar.map { it.uri to it.nama }, folder))
            } else {
                for ((n, b) in daftar.withIndex()) {
                    if (batalKonversi) break
                    tampilKonversi("Mengonversi (${n + 1}/${daftar.size})\n${b.nama}")
                    val id = UUID.randomUUID().toString().also { idKonversi = it }
                    val hasil = when (alat) {
                        Alat.FORMAT_GAMBAR -> converter.gambar(b.uri, b.nama, folder, FormatGambar.values()[indeksOpsiK])
                        Alat.PERKECIL -> {
                            val png = b.nama.endsWith(".png", true)
                            converter.gambar(
                                b.uri, b.nama, folder, if (png) FormatGambar.PNG else FormatGambar.JPG,
                                skala = listOf(0.75f, 0.5f, 0.25f)[indeksOpsiK], kualitas = 85
                            )
                        }
                        Alat.KE_AUDIO -> converter.keAudio(
                            b.uri, b.nama, folder, FormatAudio.values()[indeksOpsiK],
                            Efek.values()[indeksEfekK], mulai, akhir, id
                        )
                        Alat.KOMPRES -> converter.kompresVideo(b.uri, b.nama, folder, listOf(720, 480, 360)[indeksOpsiK], id)
                        Alat.GIF -> converter.keGif(b.uri, b.nama, folder, listOf(320, 480, 640)[indeksOpsiK], mulai, akhir, id)
                        Alat.PDF -> HasilKonversi.Gagal("tidak mungkin")
                    }
                    catat(hasil)
                }
            }

            konversiBerjalan = false
            idKonversi = null
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val ringkas = buildString {
                append(if (batalKonversi && ok + gagal == 0) "Konversi dibatalkan." else "Selesai: $ok berhasil")
                if (gagal > 0) append(", $gagal gagal ($pesanGagal)")
            }
            pesanKonversi = ringkas
            konversiOk = ok > 0 && gagal == 0
            perbaruiTombolKonversi()
            render()
        }
    }

    // =========================================================================
    // Tab PUTAR
    // =========================================================================
    private fun pasangPutar() {
        binding.btnPlay.setOnClickListener { mintaIzinNotif(); pastikanDaftar { pemutar.toggle() } }
        binding.btnNext.setOnClickListener { pastikanDaftar { pemutar.berikut() } }
        binding.btnPrev.setOnClickListener { pastikanDaftar { pemutar.sebelumnya() } }
        binding.btnAcak.setOnClickListener { mintaIzinNotif(); pastikanDaftar { pemutar.lagiAcak() } }
        binding.btnUlang.setOnClickListener { pemutar.ganti() }
        binding.btnMuatDaftar.setOnClickListener { muatDaftar() }
        binding.btnUnduhLagu.setOnClickListener {
            val l = pemutar.laguSaatIni
            val id = l?.id
            if (l != null && id != null) unduhHasil(HasilLagu(id, l.nama, l.artis.orEmpty(), 0, l.sampulUrl))
        }
        binding.cardMini.setOnClickListener { pilihTab(TAB_PUTAR) }
        binding.btnMiniPlay.setOnClickListener { mintaIzinNotif(); pemutar.toggle() }
        binding.btnMiniNext.setOnClickListener { pemutar.berikut() }
        binding.seekPutar.addOnChangeListener { _, nilai, dariUser ->
            if (dariUser) binding.tvWaktu.text = "${formatDurasi(nilai.toLong() / 1000L)} / ${formatDurasi(pemutar.durasi / 1000L)}"
        }
        binding.seekPutar.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) { menyeret = true }
            override fun onStopTrackingTouch(slider: Slider) {
                menyeret = false
                pemutar.seek(slider.value.toInt())
            }
        })
        binding.actTidur.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, pilihanTidur.map { it.first }))
        binding.actTidur.setText(pilihanTidur[0].first, false)
        binding.actTidur.setOnItemClickListener { _, _, p, _ -> pemutar.setTidur(pilihanTidur[p].second) }
    }

    private fun muatDaftar() {
        val f = folderUri ?: run { snack("Pilih folder simpan dulu"); return }
        binding.tvInfoDaftar.text = "Memuat daftar…"
        lifecycleScope.launch { pemutar.muat(f) }
    }

    /** Daftar dimuat otomatis saat pertama kali tombol ditekan. */
    private fun pastikanDaftar(aksi: () -> Unit) {
        if (pemutar.daftar.isNotEmpty()) { aksi(); return }
        val f = folderUri ?: run { snack("Pilih folder simpan dulu"); return }
        lifecycleScope.launch {
            pemutar.muat(f)
            if (pemutar.daftar.isEmpty()) snack("Tidak ada lagu di folder ini") else aksi()
        }
    }

    private fun warnaToggle(b: MaterialButton, nyala: Boolean) {
        val warna = ContextCompat.getColor(this, if (nyala) R.color.accent else R.color.on_surface_variant)
        b.iconTint = ColorStateList.valueOf(warna)
    }

    private fun perbaruiPemutarUi() {
        val main = pemutar.sedangMain || pemutar.menyiapkan
        binding.tvLagu.text = pemutar.judul
        binding.tvArtis.text = pemutar.artis.orEmpty()
        binding.tvArtis.visibility = if (pemutar.artis.isNullOrBlank()) View.GONE else View.VISIBLE
        binding.tvInfoDaftar.text = if (pemutar.daftar.isEmpty()) "Folder simpan belum dimuat"
        else "${pemutar.daftar.size} lagu" + (if (pemutar.antreanOnline) " • antrean online" else "") +
            if (pemutar.acak) " • mode acak" else ""

        val sampul = pemutar.sampul ?: Sampul.bawaan(this)
        if (sampulTerpasang !== sampul) { binding.imgSampul.setImageBitmap(sampul); sampulTerpasang = sampul }

        binding.btnPlay.setIconResource(if (main) R.drawable.ic_pause else R.drawable.ic_play)
        binding.btnPlay.contentDescription = if (main) "Jeda" else "Putar"
        warnaToggle(binding.btnAcak, pemutar.acak)
        binding.btnUlang.setIconResource(
            if (pemutar.ulang == Pemutar.Ulang.SATU) R.drawable.ic_repeat_one else R.drawable.ic_repeat
        )
        binding.btnUlang.contentDescription = when (pemutar.ulang) {
            Pemutar.Ulang.SEMUA -> "Ulangi semua lagu"
            Pemutar.Ulang.SATU -> "Ulangi satu lagu"
            Pemutar.Ulang.MATI -> "Ulang mati"
        }
        warnaToggle(binding.btnUlang, pemutar.ulang != Pemutar.Ulang.MATI)

        binding.btnUnduhLagu.visibility = if (pemutar.laguSaatIni?.id != null) View.VISIBLE else View.GONE
        perbaruiMini()
        perbaruiSeek()
        handler.removeCallbacks(ticker)
        if (tabAktif == TAB_PUTAR && pemutar.sedangMain) handler.postDelayed(ticker, 500)
    }

    private fun perbaruiSeek() {
        if (menyeret) return // jangan menimpa posisi saat slider sedang digeser pengguna
        val d = pemutar.durasi
        val p = pemutar.posisi
        val maks = maxOf(d, 1).toFloat()
        val slider = binding.seekPutar
        if (slider.valueTo != maks) { slider.value = 0f; slider.valueTo = maks }
        val nilai = p.toFloat().coerceIn(0f, maks)
        if (slider.value != nilai) slider.value = nilai
        slider.isEnabled = pemutar.aktif && !pemutar.menyiapkan
        binding.tvWaktu.setTeks("${formatDurasi(p / 1000L)} / ${formatDurasi(d / 1000L)}")
    }

    // =========================================================================
    // Tab RIWAYAT
    // =========================================================================
    private fun pasangRiwayat() {
        binding.etCari.doAfterTextChanged { batasRiwayat = 30; muatRiwayat() }
        binding.btnLebihBanyak.setOnClickListener { batasRiwayat += 30; muatRiwayat() }
        binding.btnKosongkanRiwayat.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Hapus semua riwayat?")
                .setMessage("Hanya daftar riwayat yang dihapus, file tetap ada.")
                .setPositiveButton("Hapus") { _, _ -> riwayat.kosongkan(); muatRiwayat() }
                .setNegativeButton("Batal", null).show()
        }
    }

    private fun muatRiwayat() {
        val kata = binding.etCari.text?.toString()?.trim()?.lowercase().orEmpty()
        val cocok = riwayat.semua().filter { kata.isEmpty() || it.judul.lowercase().contains(kata) }
        // Tampil bertahap (30 per halaman): daftar tetap ringan, sisanya bisa dimuat atau dicari.
        val tampil = cocok.take(batasRiwayat)
        adapterRiwayat.submitList(tampil)
        val sisa = cocok.size - tampil.size
        binding.btnLebihBanyak.visibility = if (sisa > 0) View.VISIBLE else View.GONE
        binding.btnLebihBanyak.text = "Tampilkan lebih banyak ($sisa lagi)"
        binding.tvKosongR.visibility = if (cocok.isEmpty()) View.VISIBLE else View.GONE
        binding.tvKosongR.text = if (kata.isEmpty()) "Belum ada riwayat." else "Tidak ditemukan."
    }

    private fun menuRiwayat(e: Entri, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Buka")
        pm.menu.add(0, 2, 1, "Bagikan")
        pm.menu.add(0, 3, 2, "Hapus dari riwayat")
        pm.menu.add(0, 4, 3, "Hapus file juga")
        if (e.sumber.isNotBlank()) pm.menu.add(0, 5, 4, "Salin link sumber")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> bukaFile(e)
                2 -> bagikanFile(e)
                3 -> { riwayat.hapus(e); muatRiwayat() }
                4 -> {
                    runCatching { DocumentFile.fromSingleUri(this, e.uri.toUri())?.delete() }
                    riwayat.hapus(e); muatRiwayat()
                }
                5 -> {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("link", e.sumber))
                    snack("Link sumber disalin")
                }
            }
            true
        }
        pm.show()
    }

    private fun adaFile(e: Entri): Boolean =
        runCatching { DocumentFile.fromSingleUri(this, e.uri.toUri())?.exists() == true }.getOrDefault(false)

    private fun fileHilang(e: Entri) =
        snackAksi("File tidak ditemukan (mungkin sudah dihapus atau dipindah)", "Hapus dari riwayat") {
            riwayat.hapus(e); muatRiwayat()
        }

    private fun bukaFile(e: Entri) {
        if (!adaFile(e)) { fileHilang(e); return }
        val uri = e.uri.toUri()
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, contentResolver.getType(uri) ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) } catch (_: ActivityNotFoundException) { snack("Tidak ada aplikasi untuk membuka file ini") }
    }

    private fun bagikanFile(e: Entri) {
        if (!adaFile(e)) { fileHilang(e); return }
        val uri = e.uri.toUri()
        val i = Intent(Intent.ACTION_SEND).setType(contentResolver.getType(uri) ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(Intent.createChooser(i, "Bagikan")) }
        catch (_: ActivityNotFoundException) { snack("Tidak ada aplikasi untuk membagikan file ini") }
    }

    // =========================================================================
    // Tab ATUR
    // =========================================================================
    private fun pasangAtur() {
        binding.swWifi.isChecked = prefs.wifiOnly
        binding.swDuplikat.isChecked = prefs.lewatiDuplikat
        binding.swCover.isChecked = prefs.cover
        binding.swSponsor.isChecked = prefs.sponsor
        binding.swSubtitle.isChecked = prefs.subtitle
        binding.swFolderKanal.isChecked = prefs.folderPerKanal
        binding.swWifi.setOnCheckedChangeListener { _, c -> prefs.wifiOnly = c }
        binding.swDuplikat.setOnCheckedChangeListener { _, c -> prefs.lewatiDuplikat = c }
        binding.swCover.setOnCheckedChangeListener { _, c -> prefs.cover = c }
        binding.swSponsor.setOnCheckedChangeListener { _, c -> prefs.sponsor = c }
        binding.swSubtitle.setOnCheckedChangeListener { _, c -> prefs.subtitle = c }
        binding.swFolderKanal.setOnCheckedChangeListener { _, c -> prefs.folderPerKanal = c }

        binding.actPenamaan.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Prefs.PILIHAN_PENAMAAN))
        binding.actPenamaan.setText(Prefs.PILIHAN_PENAMAAN[prefs.penamaan.coerceIn(0, 1)], false)
        binding.actPenamaan.setOnItemClickListener { _, _, p, _ -> prefs.penamaan = p }
        binding.actBatas.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Prefs.PILIHAN_BATAS))
        binding.actBatas.setText(Prefs.PILIHAN_BATAS[prefs.batas.coerceIn(0, 3)], false)
        binding.actBatas.setOnItemClickListener { _, _, p, _ -> prefs.batas = p }

        binding.btnPerbarui.setOnClickListener {
            lifecycleScope.launch {
                binding.btnPerbarui.isEnabled = false
                snack("Memperbarui mesin…")
                val ok = Mesin.perbarui(this@MainActivity)
                snack(if (ok) "Mesin pengunduh diperbarui" else "Gagal memperbarui. Periksa koneksi internet.")
                binding.btnPerbarui.isEnabled = true
            }
        }
        binding.btnCookies.setOnClickListener { pemilihCookies.launch(arrayOf("*/*")) }
        binding.btnHapusCookies.setOnClickListener { Prefs.cookies(this).delete(); snack("Cookies dihapus"); perbaruiCookiesUi() }
        perbaruiCookiesUi()
        binding.btnResetArsip.setOnClickListener {
            FormatUnduh.values().forEach { Prefs.arsip(this, it).delete() }
            snack("Daftar 'sudah diunduh' direset")
        }
        binding.btnSalinLog.setOnClickListener {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("log", Catatan.baca()))
            snack("Log disalin")
        }
        binding.btnHapusLog.setOnClickListener { Catatan.hapus(); snack("Log dihapus") }
        binding.swUpdate.isChecked = prefs.cekOtomatis
        binding.swUpdate.setOnCheckedChangeListener { _, c -> prefs.cekOtomatis = c }
        binding.btnCekUpdate.setOnClickListener {
            snack("Mengecek pembaruan…")
            cekPembaruan(true)
        }
        binding.btnBersihkan.setOnClickListener {
            val s = statusAntrian
            val aman = s.aktif == null && s.antre.isEmpty() && s.terjeda.isEmpty()
            val konversiAman = !konversiBerjalan
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { bersihkanCache(this@MainActivity, aman, konversiAman) }
                snack(if (aman && konversiAman) "Cache dibersihkan" else "Cache dibersihkan (file yang sedang dipakai dipertahankan)")
                hitungCache()
            }
        }
        binding.btnUpdateDetail.setOnClickListener { rilisBaru?.let { dialogUpdate(it) } }
        binding.btnUpdateTutup.setOnClickListener { binding.cardUpdate.visibility = View.GONE }
        binding.btnLatar.setOnClickListener { pemilihLatar.launch("image/*") }
        binding.btnLatarBawaan.setOnClickListener { Prefs.latar(this).delete(); muatLatar() }

        val versi = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull()
        binding.tvVersi.text = "Down-Chan v${versi ?: "?"}"
    }

    private fun perbaruiCookiesUi() {
        binding.btnHapusCookies.text =
            if (Prefs.cookies(this).exists()) "Hapus cookies (aktif)" else "Hapus cookies"
    }

    private fun impor(uri: Uri) {
        runCatching {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw java.io.IOException("File tidak bisa dibuka")
            if (bytes.size > 5_000_000) throw IllegalArgumentException("Berkas terlalu besar untuk cookies.txt")
            val teks = bytes.toString(Charsets.UTF_8)
            // File cookies yang salah membuat semua unduhan gagal, jadi diperiksa sebelum disimpan.
            if (!cookiesValid(teks)) throw IllegalArgumentException("Bukan format cookies.txt (Netscape)")
            Prefs.cookies(this).writeText(teks)
        }.onSuccess { snack("Cookies diimpor"); perbaruiCookiesUi() }
            .onFailure { snack(it.message ?: "Gagal mengimpor cookies") }
    }

    private fun simpanLatar(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    // Dikecilkan agar hemat memori dan penyimpanan
                    val bmp = converter.decodeKecil(uri, 1280) ?: return@runCatching false
                    Prefs.latar(this@MainActivity).outputStream().use { bmp.compress(formatWebp(), 80, it) }
                    true
                }.getOrDefault(false)
            }
            if (ok) muatLatar() else snack("Gagal memuat gambar")
        }
    }

    private fun muatLatar() {
        val f = Prefs.latar(this)
        if (!f.exists()) { binding.bgImage.setImageResource(R.drawable.bg_anna); return }
        // Dekode latar kustom di thread latar belakang, bukan di thread utama
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(f.absolutePath) }
            if (bmp != null) binding.bgImage.setImageBitmap(bmp) else binding.bgImage.setImageResource(R.drawable.bg_anna)
        }
    }

    // =========================================================================
    // Pembaruan & cache
    // =========================================================================
    private fun cekPembaruan(paksa: Boolean) {
        lifecycleScope.launch {
            when (val h = Pembaruan.cek(applicationContext, prefs, paksa)) {
                is Pembaruan.Hasil.Baru -> {
                    rilisBaru = h.info
                    binding.tvUpdate.text = "Versi ${h.info.versi.removePrefix("v")} tersedia (kamu memakai v${Pembaruan.versiSaatIni(this@MainActivity)})"
                    binding.cardUpdate.visibility = View.VISIBLE
                    if (paksa) dialogUpdate(h.info)
                }
                Pembaruan.Hasil.Terkini ->
                    if (paksa) snack("Kamu sudah memakai versi terbaru (v${Pembaruan.versiSaatIni(this@MainActivity)})")
                is Pembaruan.Hasil.Gagal -> if (paksa) snack("Gagal mengecek pembaruan: ${h.pesan}")
                Pembaruan.Hasil.Dilewati -> {}
            }
        }
    }

    private fun dialogUpdate(i: Pembaruan.Info) {
        val catatan = i.catatan.ifBlank { "Tidak ada catatan perubahan." }
        MaterialAlertDialogBuilder(this)
            .setTitle("Versi ${i.versi.removePrefix("v")} tersedia")
            .setMessage(catatan)
            .setPositiveButton(if (i.apk != null) "Unduh APK" else "Buka halaman rilis") { _, _ ->
                bukaTautan(i.apk ?: i.halaman)
            }
            .setNeutralButton("Lewati versi ini") { _, _ ->
                prefs.lewatiVersi = i.versi
                binding.cardUpdate.visibility = View.GONE
            }
            .setNegativeButton("Nanti", null)
            .show()
    }

    private fun bukaTautan(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, url.toUri())) }
        catch (_: ActivityNotFoundException) { snack("Tidak ada peramban untuk membuka tautan") }
    }

    private fun hitungCache() {
        lifecycleScope.launch {
            val u = withContext(Dispatchers.IO) { ukuranCache(this@MainActivity) }
            binding.btnBersihkan.text = "Bersihkan cache (${formatUkuran(u)})"
        }
    }
}

/** Saran ketikan tanpa penyaringan bawaan ArrayAdapter (saran server tidak selalu diawali teks yang diketik). */
private class AdapterSaran(context: Context, private val data: List<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, data) {
    override fun getFilter(): Filter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults =
            FilterResults().apply { values = data; count = data.size }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            notifyDataSetChanged()
        }
    }
}
