package com.example.unduhku

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

class MainActivity : AppCompatActivity() {

    private var uriLokasiSimpan: Uri? = null

    private val pemilihFolder = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                uriLokasiSimpan = uri
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                
                findViewById<TextView>(R.id.tvLokasi).text = "Lokasi Siap!\nFile akan disimpan di folder pilihan Anda."
                Toast.makeText(this, "Lokasi penyimpanan diatur!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            YoutubeDL.getInstance().init(application)
            FFmpeg.getInstance().init(application)
        } catch (e: Exception) {
            Log.e("DownChan_Init", "Gagal memuat library", e)
        }

        val btnPilihFolder = findViewById<Button>(R.id.btnPilihFolder)
        btnPilihFolder.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            pemilihFolder.launch(intent)
        }
    }
}