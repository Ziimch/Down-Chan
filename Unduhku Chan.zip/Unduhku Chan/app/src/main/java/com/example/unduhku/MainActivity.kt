package com.example.unduhku

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.example.unduhku.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val downloader by lazy { Downloader(applicationContext) }

    private var folderUri: Uri? = null
    private var mesinSiap = false
    private var mesinGagal = false
    private var sedangUnduh = false
    private var processIdAktif: String? = null
    private var kualitasAudio = 128
    private var kualitasTinggi: Int? = 1080

    private val pilihanAudio = listOf(
        "128 kbps (hemat)" to 128,
        "192 kbps" to 192,
        "256 kbps" to 256,
        "320 kbps (terbaik)" to 320
    )
    private val pilihanVideo = listOf(
        "Terbaik tersedia" to null,
        "4K / 2160p" to 2160,
        "1440p" to 1440,
        "1080p Full HD" to 1080,
        "720p HD" to 720,
        "480p" to 480,
        "360p" to 360
    )
    private var indeksAudio = 0
    private var indeksVideo = 3

    private val pemilihFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) simpanFolder(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pulihFolderTersimpan()
        pasangAksi()
        siapkanMesin()
        tanganiIntent(intent)
        perbaruiUi()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tanganiIntent(intent)
    }

    // ---------- Inisialisasi ----------

    /** Init yt-dlp + ffmpeg mengekstrak file besar saat pertama kali, jadi jangan di main thread. */
    private fun siapkanMesin() {
        lifecycleScope.launch {
            val berhasil = withContext(Dispatchers.IO) {
                runCatching {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                }.onFailure { Log.e(TAG, "Gagal memuat library", it) }.isSuccess
            }
            mesinSiap = berhasil
            mesinGagal = !berhasil
            perbaruiUi()
        }
    }

    private fun pulihFolderTersimpan() {
        val tersimpan = prefs.getString(KEY_FOLDER, null)?.toUri() ?: return
        val masihBerizin = contentResolver.persistedUriPermissions.any {
            it.uri == tersimpan && it.isWritePermission
        }
        if (masihBerizin) folderUri = tersimpan else prefs.edit().remove(KEY_FOLDER).apply()
    }

    private fun simpanFolder(uri: Uri) {
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        folderUri = uri
        prefs.edit().putString(KEY_FOLDER, uri.toString()).apply()
        perbaruiUi()
        binding.etUrl.requestFocus()
    }

    // ---------- Aksi ----------

    private fun pasangAksi() {
        binding.btnPilihFolder.setOnClickListener { pemilihFolder.launch(null) }

        binding.tilUrl.setEndIconOnClickListener {
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val teks = clip.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(this)?.toString()
            if (teks.isNullOrBlank()) {
                Snackbar.make(binding.root, R.string.error_clipboard_kosong, Snackbar.LENGTH_SHORT).show()
            } else {
                binding.etUrl.setText(ambilUrl(teks) ?: teks.trim())
            }
        }

        binding.etUrl.doAfterTextChanged { binding.tilUrl.error = null }
        binding.etUrl.setOnEditorActionListener { _, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_DONE) { mulaiUnduh(); true } else false
        }

        binding.toggleFormat.addOnButtonCheckedListener { _, id, dicek ->
            if (dicek) tampilkanPilihanKualitas(id == R.id.btnMp3)
        }
        tampilkanPilihanKualitas(binding.toggleFormat.checkedButtonId == R.id.btnMp3)

        binding.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                val konversi = tab?.position == 1
                binding.panelUnduh.visibility = if (konversi) View.GONE else View.VISIBLE
                binding.panelKonversi.visibility = if (konversi) View.VISIBLE else View.GONE
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        binding.btnPilihFile.setOnClickListener {
            pemilihFile.launch(arrayOf("image/*", "video/*", "audio/*"))
        }
        binding.btnKonversi.setOnClickListener { mulaiKonversi() }
        binding.btnBatalKonversi.setOnClickListener { processIdKonversi?.let(converter::batalkan) }

        binding.btnUnduh.setOnClickListener { mulaiUnduh() }
        binding.btnPerbarui.setOnClickListener { perbaruiMesinManual() }
        binding.btnBatal.setOnClickListener { processIdAktif?.let(downloader::batalkan) }
    }

    private fun tampilkanPilihanKualitas(musik: Boolean) {
        val label = (if (musik) pilihanAudio else pilihanVideo).map { it.first }
        val indeks = if (musik) indeksAudio else indeksVideo
        binding.actKualitas.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, label)
        )
        binding.actKualitas.setText(label[indeks], false)
        binding.actKualitas.setOnItemClickListener { _, _, posisi, _ ->
            if (musik) indeksAudio = posisi else indeksVideo = posisi
        }
    }

    /** Link yang dibagikan dari aplikasi lain langsung masuk ke kolom. */
    private fun tanganiIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val teks = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        ambilUrl(teks)?.let {
            binding.tabs.getTabAt(0)?.select()
            binding.etUrl.setText(it)
        }
    }

    private fun ambilUrl(teks: String?): String? {
        if (teks.isNullOrBlank()) return null
        val matcher = Patterns.WEB_URL.matcher(teks)
        if (!matcher.find()) return null
        val url = matcher.group()
        return if (url.startsWith("http", ignoreCase = true)) url else "https://$url"
    }

    private fun mulaiUnduh() {
        val folder = folderUri ?: return
        if (!mesinSiap || sedangUnduh) return

        val mentah = binding.etUrl.text?.toString().orEmpty()
        if (mentah.isBlank()) {
            binding.tilUrl.error = getString(R.string.error_link_kosong)
            return
        }
        val url = ambilUrl(mentah)
        if (url == null) {
            binding.tilUrl.error = getString(R.string.error_link_tidak_valid)
            return
        }

        val format = if (binding.toggleFormat.checkedButtonId == R.id.btnMp3) FormatUnduh.MP3 else FormatUnduh.MP4
        kualitasAudio = pilihanAudio[indeksAudio].second
        kualitasTinggi = pilihanVideo[indeksVideo].second
        val processId = UUID.randomUUID().toString()
        processIdAktif = processId
        sedangUnduh = true

        binding.progressBar.isIndeterminate = true
        binding.tvProgress.text = ""
        perbaruiUi(statusKhusus = getString(R.string.status_mengunduh))

        lifecycleScope.launch { jalankanUnduhan(url, folder, format, processId, sudahPerbarui = false) }
    }

    private suspend fun jalankanUnduhan(
        url: String,
        folder: Uri,
        format: FormatUnduh,
        processId: String,
        sudahPerbarui: Boolean
    ) {
        val hasil = downloader.unduh(
            url = url,
            folderTujuan = folder,
            format = format,
            audioKbps = kualitasAudio,
            tinggiMaks = kualitasTinggi,
            processId = processId,
            onProgress = { persen -> runOnUiThread { tampilkanProgress(persen) } },
            onMenyimpan = {
                runOnUiThread {
                    binding.progressBar.isIndeterminate = true
                    binding.tvStatus.setText(R.string.status_menyimpan)
                }
            }
        )

        // HTTP 403 / minta login biasanya karena yt-dlp kedaluwarsa: perbarui sekali lalu ulangi.
        if (hasil is HasilUnduh.Gagal && !sudahPerbarui && perluPerbarui(hasil.pesan)) {
            binding.progressBar.isIndeterminate = true
            binding.tvProgress.text = ""
            binding.tvStatus.setText(R.string.status_memperbarui)
            if (downloader.perbaruiMesin()) {
                binding.tvStatus.setText(R.string.status_coba_lagi)
                jalankanUnduhan(url, folder, format, processId, sudahPerbarui = true)
                return
            }
        }

        sedangUnduh = false
        processIdAktif = null

        val pesan = when (hasil) {
            is HasilUnduh.Sukses -> {
                binding.etUrl.text?.clear()
                getString(R.string.status_berhasil, hasil.namaFile)
            }
            is HasilUnduh.Gagal -> {
                val dasar = getString(R.string.status_gagal, hasil.pesan)
                if (sudahPerbarui || !perluPerbarui(hasil.pesan)) dasar
                else dasar + "\n" + getString(R.string.hint_403)
            }
            HasilUnduh.Dibatalkan -> getString(R.string.status_dibatalkan)
        }
        perbaruiUi(statusKhusus = pesan)
    }

    private fun perluPerbarui(pesan: String) =
        pesan.contains("403") || pesan.contains("Sign in", ignoreCase = true)

    private fun perbaruiMesinManual() {
        if (sedangUnduh || !mesinSiap) return
        sedangUnduh = true
        binding.progressBar.isIndeterminate = true
        perbaruiUi(statusKhusus = getString(R.string.status_memperbarui))
        lifecycleScope.launch {
            val ok = downloader.perbaruiMesin()
            sedangUnduh = false
            perbaruiUi(
                statusKhusus = getString(
                    if (ok) R.string.status_perbarui_ok else R.string.status_perbarui_gagal
                )
            )
        }
    }

    // ---------- Konverter ----------

    private enum class Jenis { GAMBAR, MEDIA }

    private val converter by lazy { Converter(applicationContext) }
    private var fileKonversi: Uri? = null
    private var namaFileKonversi = ""
    private var jenisKonversi: Jenis? = null
    private var opsiKonversi: List<String> = emptyList()
    private var indeksKonversi = 0
    private var processIdKonversi: String? = null

    private val pemilihFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) pilihFile(uri)
        }

    private fun pilihFile(uri: Uri) {
        val tipe = contentResolver.getType(uri).orEmpty()
        val jenis = when {
            tipe.startsWith("image/") -> Jenis.GAMBAR
            tipe.startsWith("video/") || tipe.startsWith("audio/") -> Jenis.MEDIA
            else -> null
        }
        if (jenis == null) {
            Snackbar.make(binding.root, R.string.error_file_tidak_didukung, Snackbar.LENGTH_SHORT).show()
            return
        }

        val nama = contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
            ?: uri.lastPathSegment ?: "file"

        fileKonversi = uri
        namaFileKonversi = nama
        jenisKonversi = jenis
        opsiKonversi = if (jenis == Jenis.GAMBAR) FormatGambar.values().map { it.name }
                       else FormatAudio.values().map { it.name }
        indeksKonversi = 0

        binding.tvFileKonversi.text = nama
        binding.actFormatKonversi.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, opsiKonversi)
        )
        binding.actFormatKonversi.setText(opsiKonversi[0], false)
        binding.actFormatKonversi.setOnItemClickListener { _, _, posisi, _ -> indeksKonversi = posisi }
        perbaruiUi()
    }

    private fun mulaiKonversi() {
        val sumber = fileKonversi
        val jenis = jenisKonversi
        val folder = folderUri
        if (sumber == null || jenis == null) {
            Snackbar.make(binding.root, R.string.error_pilih_file, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (folder == null) {
            Snackbar.make(binding.root, R.string.status_pilih_folder, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (sedangUnduh || (jenis == Jenis.MEDIA && !mesinSiap)) return

        val pilihan = opsiKonversi[indeksKonversi]
        val processId = UUID.randomUUID().toString()
        processIdKonversi = processId
        sedangUnduh = true

        binding.progressBar.isIndeterminate = true
        binding.tvProgress.text = ""
        perbaruiUi(statusKhusus = getString(R.string.status_mengonversi))

        lifecycleScope.launch {
            val hasil = when (jenis) {
                Jenis.GAMBAR -> converter.konversiGambar(
                    sumber, namaFileKonversi, folder, FormatGambar.valueOf(pilihan)
                )
                Jenis.MEDIA -> converter.konversiMedia(
                    sumber, namaFileKonversi, folder, FormatAudio.valueOf(pilihan), processId
                )
            }

            sedangUnduh = false
            processIdKonversi = null

            val pesan = when (hasil) {
                is HasilKonversi.Sukses -> getString(R.string.status_konversi_berhasil, hasil.namaFile)
                is HasilKonversi.Gagal -> getString(R.string.status_konversi_gagal, hasil.pesan)
                HasilKonversi.Dibatalkan -> getString(R.string.status_dibatalkan)
            }
            perbaruiUi(statusKhusus = pesan)
        }
    }

    // ---------- Tampilan ----------

    private fun tampilkanProgress(persen: Int) {
        with(binding.progressBar) {
            if (isIndeterminate) isIndeterminate = false
            setProgressCompat(persen, true)
        }
        binding.tvProgress.text = getString(R.string.progress_persen, persen)
    }

    private fun perbaruiUi(statusKhusus: String? = null) {
        val folder = folderUri
        binding.tvFolderName.text = folder
            ?.let { DocumentFile.fromTreeUri(this, it)?.name ?: it.lastPathSegment }
            ?: getString(R.string.folder_belum_dipilih)
        binding.btnPilihFolder.setText(
            if (folder == null) R.string.btn_pilih_folder else R.string.btn_ganti_folder
        )

        binding.btnUnduh.isEnabled = mesinSiap && folder != null && !sedangUnduh
        binding.btnPilihFolder.isEnabled = !sedangUnduh
        binding.btnPerbarui.isEnabled = mesinSiap && !sedangUnduh
        binding.toggleFormat.isEnabled = !sedangUnduh
        binding.btnMp4.isEnabled = !sedangUnduh
        binding.btnMp3.isEnabled = !sedangUnduh
        binding.tilKualitas.isEnabled = !sedangUnduh

        binding.btnBatal.visibility = if (sedangUnduh && processIdAktif != null) View.VISIBLE else View.GONE
        binding.btnBatalKonversi.visibility =
            if (sedangUnduh && processIdKonversi != null && jenisKonversi == Jenis.MEDIA) View.VISIBLE else View.GONE
        binding.btnPilihFile.isEnabled = !sedangUnduh
        binding.tilFormatKonversi.isEnabled = !sedangUnduh && fileKonversi != null
        binding.btnKonversi.isEnabled = !sedangUnduh && fileKonversi != null && folder != null &&
            (jenisKonversi == Jenis.GAMBAR || mesinSiap)
        binding.progressBar.visibility = if (sedangUnduh) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (sedangUnduh) View.VISIBLE else View.GONE

        binding.tvStatus.text = statusKhusus ?: getString(
            when {
                mesinGagal -> R.string.status_mesin_gagal
                !mesinSiap -> R.string.status_menyiapkan_mesin
                folder == null -> R.string.status_pilih_folder
                else -> R.string.status_siap
            }
        )
    }

    private companion object {
        const val TAG = "DownChan"
        const val PREFS = "unduhku"
        const val KEY_FOLDER = "folder_uri"
    }
}
