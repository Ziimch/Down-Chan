package com.example.unduhku

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.inputmethod.EditorInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import com.example.unduhku.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val downloader by lazy { Downloader(applicationContext) }

    private var folderUri: Uri? = null
    private var mesinSiap = false
    private var mesinGagal = false
    private var sedangUnduh = false
    private var processIdAktif: String? = null

    private val pemilihFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) simpanFolder(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pulihFolderTersimpan()
        pasangAksi()
        siapkanMesin()
        tanganiIntent(intent)
        perbaruiUi()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tanganiIntent(intent)
    }

    // ---------- Inisialisasi ----------

    /** Init yt-dlp + ffmpeg mengekstrak file besar saat pertama kali, jadi jangan di main thread. */
    private fun siapkanMesin() {
        lifecycleScope.launch {
            val berhasil = withContext(Dispatchers.IO) {
                runCatching {
                    YoutubeDL.getInstance().init(application)
                    FFmpeg.getInstance().init(application)
                }.onFailure { Log.e(TAG, "Gagal memuat library", it) }.isSuccess
            }
            mesinSiap = berhasil
            mesinGagal = !berhasil
            perbaruiUi()
        }
    }

    private fun pulihFolderTersimpan() {
        val tersimpan = prefs.getString(KEY_FOLDER, null)?.toUri() ?: return
        val masihBerizin = contentResolver.persistedUriPermissions.any {
            it.uri == tersimpan && it.isWritePermission
        }
        if (masihBerizin) folderUri = tersimpan else prefs.edit().remove(KEY_FOLDER).apply()
    }

    private fun simpanFolder(uri: Uri) {
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        folderUri = uri
        prefs.edit().putString(KEY_FOLDER, uri.toString()).apply()
        perbaruiUi()
        binding.etUrl.requestFocus()
    }

    // ---------- Aksi ----------

    private fun pasangAksi() {
        binding.btnPilihFolder.setOnClickListener { pemilihFolder.launch(null) }

        binding.tilUrl.setEndIconOnClickListener {
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val teks = clip.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(this)?.toString()
            if (teks.isNullOrBlank()) {
                Snackbar.make(binding.root, R.string.error_clipboard_kosong, Snackbar.LENGTH_SHORT).show()
            } else {
                binding.etUrl.setText(ambilUrl(teks) ?: teks.trim())
            }
        }

        binding.etUrl.doAfterTextChanged { binding.tilUrl.error = null }
        binding.etUrl.setOnEditorActionListener { _, aksi, _ ->
            if (aksi == EditorInfo.IME_ACTION_DONE) { mulaiUnduh(); true } else false
        }

        binding.btnUnduh.setOnClickListener { mulaiUnduh() }
        binding.btnBatal.setOnClickListener { processIdAktif?.let(downloader::batalkan) }
    }

    /** Link yang dibagikan dari aplikasi lain langsung masuk ke kolom. */
    private fun tanganiIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val teks = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        ambilUrl(teks)?.let { binding.etUrl.setText(it) }
    }

    private fun ambilUrl(teks: String?): String? {
        if (teks.isNullOrBlank()) return null
        val matcher = Patterns.WEB_URL.matcher(teks)
        if (!matcher.find()) return null
        val url = matcher.group()
        return if (url.startsWith("http", ignoreCase = true)) url else "https://$url"
    }

    private fun mulaiUnduh() {
        val folder = folderUri ?: return
        if (!mesinSiap || sedangUnduh) return

        val mentah = binding.etUrl.text?.toString().orEmpty()
        if (mentah.isBlank()) {
            binding.tilUrl.error = getString(R.string.error_link_kosong)
            return
        }
        val url = ambilUrl(mentah)
        if (url == null) {
            binding.tilUrl.error = getString(R.string.error_link_tidak_valid)
            return
        }

        val format = if (binding.toggleFormat.checkedButtonId == R.id.btnMp3) FormatUnduh.MP3 else FormatUnduh.MP4
        val processId = UUID.randomUUID().toString()
        processIdAktif = processId
        sedangUnduh = true

        binding.progressBar.isIndeterminate = true
        binding.tvProgress.text = ""
        perbaruiUi(statusKhusus = getString(R.string.status_mengunduh))

        lifecycleScope.launch {
            val hasil = downloader.unduh(
                url = url,
                folderTujuan = folder,
                format = format,
                processId = processId,
                onProgress = { persen -> runOnUiThread { tampilkanProgress(persen) } },
                onMenyimpan = {
                    runOnUiThread {
                        binding.progressBar.isIndeterminate = true
                        binding.tvStatus.setText(R.string.status_menyimpan)
                    }
                }
            )

            sedangUnduh = false
            processIdAktif = null

            val pesan = when (hasil) {
                is HasilUnduh.Sukses -> {
                    binding.etUrl.text?.clear()
                    getString(R.string.status_berhasil, hasil.namaFile)
                }
                is HasilUnduh.Gagal -> getString(R.string.status_gagal, hasil.pesan)
                HasilUnduh.Dibatalkan -> getString(R.string.status_dibatalkan)
            }
            perbaruiUi(statusKhusus = pesan)
        }
    }

    // ---------- Tampilan ----------

    private fun tampilkanProgress(persen: Int) {
        with(binding.progressBar) {
            if (isIndeterminate) isIndeterminate = false
            setProgressCompat(persen, true)
        }
        binding.tvProgress.text = getString(R.string.progress_persen, persen)
    }

    private fun perbaruiUi(statusKhusus: String? = null) {
        val folder = folderUri
        binding.tvFolderName.text = folder
            ?.let { DocumentFile.fromTreeUri(this, it)?.name ?: it.lastPathSegment }
            ?: getString(R.string.folder_belum_dipilih)
        binding.btnPilihFolder.setText(
            if (folder == null) R.string.btn_pilih_folder else R.string.btn_ganti_folder
        )

        binding.btnUnduh.isEnabled = mesinSiap && folder != null && !sedangUnduh
        binding.btnPilihFolder.isEnabled = !sedangUnduh
        binding.toggleFormat.isEnabled = !sedangUnduh
        binding.btnMp4.isEnabled = !sedangUnduh
        binding.btnMp3.isEnabled = !sedangUnduh

        binding.btnBatal.visibility = if (sedangUnduh) android.view.View.VISIBLE else android.view.View.GONE
        binding.progressBar.visibility = if (sedangUnduh) android.view.View.VISIBLE else android.view.View.GONE
        binding.tvProgress.visibility = if (sedangUnduh) android.view.View.VISIBLE else android.view.View.GONE

        binding.tvStatus.text = statusKhusus ?: getString(
            when {
                mesinGagal -> R.string.status_mesin_gagal
                !mesinSiap -> R.string.status_menyiapkan_mesin
                folder == null -> R.string.status_pilih_folder
                else -> R.string.status_siap
            }
        )
    }

    private companion object {
        const val TAG = "DownChan"
        const val PREFS = "unduhku"
        const val KEY_FOLDER = "folder_uri"
    }
}
