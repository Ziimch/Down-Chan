package com.example.unduhku

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private var uriLokasiSimpan: Uri? = null
    private lateinit var tvStatus: TextView
    private lateinit var tvLokasi: TextView
    private lateinit var btnUnduh: Button
    private lateinit var etUrl: EditText
    private lateinit var rgFormat: RadioGroup

    private val pemilihFolder = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                uriLokasiSimpan = uri
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                tvLokasi.text = "Lokasi Tersimpan! (Siap Mengunduh)"
                tvStatus.text = "Silakan masukkan link lalu tekan Mulai Unduh."
                btnUnduh.isEnabled = true
                etUrl.requestFocus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvLokasi = findViewById(R.id.tvLokasi)
        btnUnduh = findViewById(R.id.btnUnduh)
        etUrl = findViewById(R.id.etUrl)
        rgFormat = findViewById(R.id.rgFormat)
        val btnPilihFolder = findViewById<Button>(R.id.btnPilihFolder)

        btnUnduh.isEnabled = false

        try {
            YoutubeDL.getInstance().init(application)
            FFmpeg.getInstance().init(application)
        } catch (e: Exception) {
            Log.e("DownChan_Init", "Gagal memuat library", e)
            tvStatus.text = "Error: Gagal memuat mesin pengunduh."
        }

        btnPilihFolder.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            pemilihFolder.launch(intent)
        }

        btnUnduh.setOnClickListener {
            val urlMedia = etUrl.text.toString().trim()
            val formatTerpilih = if (rgFormat.checkedRadioButtonId == R.id.rbMp3) "MP3" else "MP4"

            if (urlMedia.isEmpty()) {
                Toast.makeText(this, "Tautan tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            btnUnduh.isEnabled = false
            tvStatus.text = "Sedang mengunduh media... Mohon tunggu."

            CoroutineScope(Dispatchers.Main).launch {
                val downloader = Downloader(this@MainActivity)
                val hasilSukses = downloader.prosesUnduhan(urlMedia, uriLokasiSimpan, formatTerpilih)

                if (hasilSukses) {
                    tvStatus.text = "Unduhan Berhasil Disimpan!"
                    etUrl.text.clear()
                } else {
                    tvStatus.text = "Unduhan Gagal. Periksa link atau koneksi."
                }
                btnUnduh.isEnabled = true
            }
        }
    }
}
