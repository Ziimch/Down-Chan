package com.example.unduhku

import android.app.Application
import android.content.Context
import android.net.Uri
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/** Init & pembaruan yt-dlp/ffmpeg. Init aman dipanggil berulang (di-cache oleh library). */
object Mesin {
    suspend fun siapkan(app: Application): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
        }.onFailure { Catatan.tulis("Init mesin gagal: ${it.message}") }.isSuccess
    }

    suspend fun perbarui(context: Context): Boolean = withContext(Dispatchers.IO) {
        runCatching { YoutubeDL.getInstance().updateYoutubeDL(context) }
            .onFailure { Catatan.tulis("Update mesin gagal: ${it.message}") }.isSuccess
    }
}

class Downloader(private val context: Context) {

    private val storage = Storage(context)

    suspend fun unduh(
        tugas: Tugas,
        prefs: Prefs,
        folder: Uri,
        onProgress: (Int) -> Unit,
        onMenyimpan: () -> Unit
    ): HasilUnduh = withContext(Dispatchers.IO) {
        // Folder kerja tetap per tugas: kalau dijeda, sisa .part dipakai lagi saat dilanjutkan.
        val kerja = File(File(context.cacheDir, "dl"), tugas.id).apply { mkdirs() }
        var tanpaCover = false
        val arsip = Prefs.arsip(context, tugas.opsi.format)

        for (percobaan in 0..1) {
            var dilewati = false
            var persenTerakhir = -1
            // Cadangan arsip "sudah diunduh": yt-dlp mencatat video SEBELUM file disalin ke folder
            // pilihan. Kalau penyimpanan gagal atau dibatalkan, catatan itu harus dikembalikan.
            val cadanganArsip = if (arsip.exists()) runCatching { arsip.readText() }.getOrNull() else null
            val request = bangunRequest(tugas, prefs, kerja, tanpaCover)

            try {
                YoutubeDL.getInstance().execute(request, tugas.id) { progress, _, line ->
                    Catatan.tulis(line)
                    if (line.contains("already been recorded", ignoreCase = true)) dilewati = true
                    val p = progress.toInt().coerceIn(0, 100)
                    if (p != persenTerakhir) { persenTerakhir = p; onProgress(p) }
                }
            } catch (e: Exception) {
                when (AntrianUnduh.permintaan) {
                    AntrianUnduh.JEDA -> return@withContext HasilUnduh.Dijeda
                    AntrianUnduh.BATAL -> {
                        kerja.deleteRecursively(); pulihkanArsip(arsip, cadanganArsip)
                        return@withContext HasilUnduh.Dibatalkan
                    }
                }
                val pesan = ringkasError(e)
                Catatan.tulis("GAGAL: ${e.message?.take(600)}")
                // Penyematan cover kadang gagal: ulangi sekali tanpa cover
                if (percobaan == 0 && !tanpaCover && tugas.opsi.format == FormatUnduh.MP3 &&
                    prefs.cover && pesan.contains("thumbnail", ignoreCase = true)
                ) { tanpaCover = true; continue }
                kerja.deleteRecursively()
                pulihkanArsip(arsip, cadanganArsip)
                return@withContext HasilUnduh.Gagal(pesan)
            }

            if (AntrianUnduh.permintaan == AntrianUnduh.JEDA) return@withContext HasilUnduh.Dijeda
            if (AntrianUnduh.permintaan == AntrianUnduh.BATAL) {
                kerja.deleteRecursively(); pulihkanArsip(arsip, cadanganArsip)
                return@withContext HasilUnduh.Dibatalkan
            }
            if (dilewati) { kerja.deleteRecursively(); return@withContext HasilUnduh.Dilewati }

            val hasil = simpanHasil(kerja, folder, onMenyimpan)
            if (hasil is HasilUnduh.Gagal) pulihkanArsip(arsip, cadanganArsip)
            return@withContext hasil
        }
        HasilUnduh.Gagal("Tidak diketahui")
    }

    private fun pulihkanArsip(arsip: File, isi: String?) {
        runCatching { if (isi == null) arsip.delete() else arsip.writeText(isi) }
    }

    private fun simpanHasil(kerja: File, folder: Uri, onMenyimpan: () -> Unit): HasilUnduh {
        try {
            val semua = kerja.walkTopDown()
                .filter { it.isFile && it.extension.lowercase() !in SEMENTARA }.toList()
            val media = semua.filter { it.extension.lowercase() in MEDIA }.ifEmpty { semua }
            if (media.isEmpty()) return HasilUnduh.Gagal(context.getString(R.string.error_tidak_ada_file))

            onMenyimpan()
            val hasil = mutableListOf<Berkas>()
            var gagal = false
            for (f in media) {
                val ukuran = f.length()
                val sub = f.parentFile?.relativeTo(kerja)?.path.orEmpty()
                    .split(File.separatorChar).filter { it.isNotEmpty() }
                val uri = storage.simpan(f, folder, sub)
                if (uri != null) hasil += Berkas(f.name, uri, ukuran) else gagal = true
            }
            return if (gagal && hasil.isEmpty()) HasilUnduh.Gagal(context.getString(R.string.error_gagal_simpan))
            else HasilUnduh.Sukses(hasil)
        } finally {
            kerja.deleteRecursively()
        }
    }

    private fun bangunRequest(t: Tugas, p: Prefs, kerja: File, tanpaCover: Boolean): YoutubeDLRequest {
        val o = t.opsi
        return YoutubeDLRequest(t.url).apply {
            val nama = if (p.penamaan == 1) "%(uploader)s - %(title).110s" else "%(title).150s"
            val sub = if (p.folderPerKanal) "%(uploader)s/" else ""
            addOption("-o", "${kerja.absolutePath}/$sub$nama.%(ext)s")
            addOption("--no-playlist")
            addOption("--no-mtime")
            addOption("--concurrent-fragments", "4")
            addOption("--retries", "5")
            addOption("--fragment-retries", "5")
            addOption("--socket-timeout", "20")

            p.batasArg()?.let { addOption("--limit-rate", it) }
            Prefs.cookies(context).takeIf { it.exists() }?.let { addOption("--cookies", it.absolutePath) }
            if (p.lewatiDuplikat) addOption("--download-archive", Prefs.arsip(context, o.format).absolutePath)
            if (o.mulai != null || o.akhir != null) {
                addOption("--download-sections", "*${o.mulai ?: "0"}-${o.akhir ?: "inf"}")
            }
            if (p.sponsor) {
                addOption("--sponsorblock-remove", "sponsor,intro,outro,selfpromo,music_offtopic")
            }

            if (o.format == FormatUnduh.MP3) {
                addOption("-x")
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", "${o.audioKbps}K")
                o.efek.filter?.let { addOption("--postprocessor-args", "ExtractAudio:-af $it") }
                if (p.cover && !tanpaCover) {
                    addOption("--embed-metadata")
                    addOption("--embed-thumbnail")
                    addOption("--convert-thumbnails", "jpg")
                }
            } else {
                addOption("-f", formatVideo(o.tinggi))
                addOption("--merge-output-format", "mp4")
                addOption("--embed-metadata")
                if (p.subtitle) {
                    addOption("--write-subs")
                    addOption("--sub-langs", "id.*,en.*")
                    addOption("--embed-subs")
                }
            }
        }
    }

    /**
     * Sampai 1080p YouTube punya stream mp4/m4a (paling kompatibel).
     * Di atas 1080p hanya VP9/AV1: filter ekstensi dilepas lalu digabung ke mp4.
     */
    private fun formatVideo(tinggi: Int?): String = when {
        tinggi == null -> "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
        tinggi <= 1080 ->
            "bestvideo[height<=$tinggi][ext=mp4]+bestaudio[ext=m4a]/" +
                "best[height<=$tinggi][ext=mp4]/best[height<=$tinggi]/best"
        else -> "bestvideo[height<=$tinggi]+bestaudio/best[height<=$tinggi]/best"
    }

    // ---------- Pratinjau ----------

    suspend fun info(url: String): InfoMedia = withContext(Dispatchers.IO) {
        val req = YoutubeDLRequest(url).apply {
            addOption("-J")
            addOption("--flat-playlist")
            addOption("--no-warnings")
            Prefs.cookies(context).takeIf { it.exists() }?.let { addOption("--cookies", it.absolutePath) }
        }
        val out = YoutubeDL.getInstance().execute(req).out
        parseInfo(url, out)
    }

    private fun parseInfo(url: String, out: String): InfoMedia {
        val awal = out.indexOf('{')
        if (awal < 0) throw IllegalStateException("Balasan info kosong")
        val j = JSONObject(out.substring(awal))
        val entri = mutableListOf<EntriPlaylist>()
        j.optJSONArray("entries")?.let { arr ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                var u = e.teks("url").ifBlank { e.teks("webpage_url") }
                val id = e.teks("id")
                if (!u.startsWith("http") && id.isNotBlank()) u = "https://www.youtube.com/watch?v=$id"
                if (u.isBlank()) continue
                entri += EntriPlaylist(e.teks("title").ifBlank { u }, u, e.optLong("duration", 0))
            }
        }
        val video = sortedMapOf<Int, Long>()
        var audio = 0L
        j.optJSONArray("formats")?.let { f ->
            for (i in 0 until f.length()) {
                val x = f.optJSONObject(i) ?: continue
                val ukuran = x.optLong("filesize", 0).takeIf { it > 0 } ?: x.optLong("filesize_approx", 0)
                val h = x.optInt("height", 0)
                val vc = x.teks("vcodec").ifBlank { "none" }
                val ac = x.teks("acodec").ifBlank { "none" }
                if (vc != "none" && h > 0) { if (ukuran > (video[h] ?: 0L)) video[h] = ukuran }
                else if (vc == "none" && ac != "none") audio = maxOf(audio, ukuran)
            }
        }
        return InfoMedia(
            url = url,
            judul = j.teks("title"),
            kanal = j.teks("uploader").ifBlank { j.teks("channel") },
            durasi = j.optLong("duration", 0),
            thumb = j.teks("thumbnail").ifBlank { null },
            ukuranVideo = video,
            ukuranAudio = audio,
            entri = entri
        )
    }

    private companion object {
        val SEMENTARA = setOf("part", "ytdl", "temp", "tmp", "json", "vtt", "srt", "webp", "jpg", "jpeg", "png")
        val MEDIA = setOf("mp3", "m4a", "mp4", "mkv", "webm", "opus", "aac", "ogg", "wav", "flac", "mov")
    }
}
