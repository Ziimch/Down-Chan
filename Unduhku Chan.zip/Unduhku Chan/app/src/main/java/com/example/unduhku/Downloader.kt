package com.example.unduhku

import android.content.Context
import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class FormatUnduh { MP4, MP3 }

sealed interface HasilUnduh {
    data class Sukses(val namaFile: String) : HasilUnduh
    data class Gagal(val pesan: String) : HasilUnduh
    data object Dibatalkan : HasilUnduh
}

class Downloader(private val context: Context) {

    private val storage = Storage(context)

    @Volatile
    private var dibatalkan = false

    /**
     * @param onProgress persen 0..100, hanya dipanggil saat angkanya berubah (thread IO).
     * @param onMenyimpan dipanggil saat unduhan selesai dan file mulai disalin ke folder tujuan.
     */
    suspend fun unduh(
        url: String,
        folderTujuan: Uri,
        format: FormatUnduh,
        audioKbps: Int,
        tinggiMaks: Int?,
        processId: String,
        onProgress: (Int) -> Unit,
        onMenyimpan: () -> Unit
    ): HasilUnduh = withContext(Dispatchers.IO) {
        dibatalkan = false

        // Bersihkan sisa unduhan yang gagal sebelumnya, lalu buat folder kerja unik.
        val akar = File(context.cacheDir, "dl").also { it.deleteRecursively() }
        val kerja = File(akar, processId).also { it.mkdirs() }

        try {
            val request = YoutubeDLRequest(url).apply {
                addOption("-o", "${kerja.absolutePath}/%(title).150s.%(ext)s")
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--concurrent-fragments", "4")

                if (format == FormatUnduh.MP3) {
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "${audioKbps}K")
                } else {
                    addOption("-f", formatVideo(tinggiMaks))
                    addOption("--merge-output-format", "mp4")
                }
            }

            var persenTerakhir = -1
            YoutubeDL.getInstance().execute(request, processId) { progress, _, _ ->
                val persen = progress.toInt().coerceIn(0, 100)
                if (persen != persenTerakhir) {
                    persenTerakhir = persen
                    onProgress(persen)
                }
            }

            if (dibatalkan) return@withContext HasilUnduh.Dibatalkan

            val hasil = kerja.listFiles()
                ?.filter { it.isFile && it.extension.lowercase() !in SEMENTARA }
                .orEmpty()

            if (hasil.isEmpty()) {
                return@withContext HasilUnduh.Gagal(context.getString(R.string.error_tidak_ada_file))
            }

            onMenyimpan()
            var gagalSimpan = false
            for (file in hasil) {
                if (!storage.simpanKeLokasiPilihan(file, folderTujuan)) gagalSimpan = true
            }

            if (gagalSimpan) {
                HasilUnduh.Gagal(context.getString(R.string.error_gagal_simpan))
            } else {
                HasilUnduh.Sukses(hasil.first().name)
            }
        } catch (e: Exception) {
            if (dibatalkan) HasilUnduh.Dibatalkan else HasilUnduh.Gagal(ringkasError(e))
        } finally {
            akar.deleteRecursively()
        }
    }

    /**
     * Sampai 1080p, YouTube punya stream mp4/m4a (paling kompatibel).
     * Di atas 1080p hanya ada VP9/AV1, jadi filter ekstensi dilepas lalu digabung ke mp4.
     */
    private fun formatVideo(tinggi: Int?): String = when {
        tinggi == null -> "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
        tinggi <= 1080 ->
            "bestvideo[height<=$tinggi][ext=mp4]+bestaudio[ext=m4a]/" +
                "best[height<=$tinggi][ext=mp4]/best[height<=$tinggi]/best"
        else -> "bestvideo[height<=$tinggi]+bestaudio/best[height<=$tinggi]/best"
    }

    /** Perbarui yt-dlp dari GitHub. YouTube sering berubah, versi lama sering kena HTTP 403. */
    suspend fun perbaruiMesin(): Boolean = withContext(Dispatchers.IO) {
        runCatching { YoutubeDL.getInstance().updateYoutubeDL(context) }.isSuccess
    }

    fun batalkan(processId: String) {
        dibatalkan = true
        YoutubeDL.getInstance().destroyProcessById(processId)
    }

    private companion object {
        val SEMENTARA = setOf("part", "ytdl", "temp", "tmp")
    }
}

/** Ambil baris error yt-dlp yang paling informatif, bukan stack trace panjang. */
internal fun ringkasError(e: Throwable): String {
    val baris = e.message.orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }
    val error = baris.lastOrNull { it.startsWith("ERROR", ignoreCase = true) }
    val teks = (error ?: baris.lastOrNull() ?: e.javaClass.simpleName)
        .removePrefix("ERROR:").trim()
    return teks.take(160)
}
