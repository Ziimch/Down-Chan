package com.example.unduhku

import android.content.Context
import android.net.Uri
import android.util.Log
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class Downloader(private val context: Context) {

    suspend fun prosesUnduhan(urlMedia: String, uriTujuan: Uri?, format: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val tempDir = File(context.cacheDir, "DownChanTemp")
                if (!tempDir.exists()) tempDir.mkdir()
                
                tempDir.listFiles()?.forEach { it.delete() }

                val request = YoutubeDLRequest(urlMedia)
                request.addOption("-o", "${tempDir.absolutePath}/%(title)s.%(ext)s")
                
                if (format.equals("MP3", ignoreCase = true)) {
                    request.addOption("-x")
                    request.addOption("--audio-format", "mp3")
                    request.addOption("--audio-quality", "0")
                } else {
                    request.addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]")
                }

                YoutubeDL.getInstance().execute(request, "DownChan_Task") { progress, eta, _ ->
                    Log.d("DownChan_Progress", "Selesai: $progress%, ETA: $eta detik")
                }

                if (uriTujuan != null) {
                    val downloadedFile = tempDir.listFiles()?.firstOrNull()
                    if (downloadedFile != null) {
                        val storage = Storage(context)
                        val sukses = storage.simpanKeLokasiPilihan(downloadedFile, uriTujuan)
                        return@withContext sukses
                    }
                }
                true
            } catch (e: Exception) {
                Log.e("DownChan_Error", "Gagal mengunduh", e)
                false
            }
        }
    }
}