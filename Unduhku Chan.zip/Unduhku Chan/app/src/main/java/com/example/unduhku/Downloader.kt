package com.example.unduhku

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class Downloader(private val context: Context) {

    suspend fun prosesUnduhan(url: String, destinationUri: Uri?, format: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val cacheDir = File(context.cacheDir, "downloads")
                if (!cacheDir.exists()) cacheDir.mkdirs()

                val request = YoutubeDLRequest(url)
                request.addOption("-o", "${cacheDir.absolutePath}/%(title)s.%(ext)s")

                if (format == "MP3") {
                    request.addOption("-x")
                    request.addOption("--audio-format", "mp3")
                } else {
                    request.addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best")
                }

                YoutubeDL.getInstance().execute(request)

                val downloadedFiles = cacheDir.listFiles()
                if (downloadedFiles != null && downloadedFiles.isNotEmpty() && destinationUri != null) {
                    val pickedFolder = DocumentFile.fromTreeUri(context, destinationUri)
                    for (file in downloadedFiles) {
                        val mimeType = if (format == "MP3") "audio/mpeg" else "video/mp4"
                        val newFile = pickedFolder?.createFile(mimeType, file.name)
                        if (newFile != null) {
                            context.contentResolver.openOutputStream(newFile.uri)?.use { output ->
                                file.inputStream().use { input ->
                                    input.copyTo(output)
                                }
                            }
                        }
                        file.delete()
                    }
                }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
