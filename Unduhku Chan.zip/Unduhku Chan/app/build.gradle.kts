plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.unduhku"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.unduhku"
        minSdk = 24
        targetSdk = 34
        // Diisi workflow dari nama tag (mis. tag v2.4 -> versionName 2.4), supaya versi aplikasi
        // selalu sama dengan rilis GitHub. Tanpa itu pengingat pembaruan bisa terus muncul.
        versionCode = (project.findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 12
        versionName = (project.findProperty("appVersionName") as String?) ?: "2.9"

        // Python + yt-dlp + ffmpeg (~puluhan MB) disalin untuk SETIAP ABI, jadi ABI
        // adalah penentu terbesar ukuran APK. Hampir semua HP modern memakai arm64-v8a.
        // HP 32-bit lama: tambahkan "armeabi-v7a". Emulator PC: tambahkan "x86_64".
        ndk {
            abiFilters.add("arm64-v8a")
        }

        // Buang terjemahan bawaan library yang tidak dipakai
        resourceConfigurations += listOf("en", "id")
    }

    // Kunci tanda tangan TETAP. Tanpa ini tiap build memakai kunci debug acak, dan Android menolak
    // memasang versi baru di atas yang lama ("paket ini bentrok dengan paket yang sudah ada").
    // Urutan: keystore dari GitHub Secrets (paling aman) -> keystore bawaan proyek (app/keystore).
    // Berlaku untuk build debug maupun release, jadi APK dari mesin mana pun tetap bisa saling menimpa.
    val kunciEnv = System.getenv("KEYSTORE_PATH")
    signingConfigs {
        create("tetap") {
            if (!kunciEnv.isNullOrBlank() && file(kunciEnv).exists()) {
                storeFile = file(kunciEnv)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else {
                storeFile = file("keystore/down-chan.jks")
                storePassword = "downchan"
                keyAlias = "downchan"
                keyPassword = "downchan"
                storeType = "pkcs12"
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("tetap")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("tetap")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        viewBinding = true
    }

    // youtubedl-android perlu mengekstrak binary python/ffmpeg dari jniLibs
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/*.version",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "DebugProbesKt.bin"
            )
        }
    }

    // Build lebih cepat di CI; lint tidak menghentikan build
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
