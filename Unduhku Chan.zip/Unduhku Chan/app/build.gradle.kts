plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.unduhku"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.unduhku"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "2.1"

        // Python + yt-dlp + ffmpeg (~puluhan MB) disalin untuk SETIAP ABI, jadi ABI
        // adalah penentu terbesar ukuran APK. Hampir semua HP modern memakai arm64-v8a.
        // HP 32-bit lama: tambahkan "armeabi-v7a". Emulator PC: tambahkan "x86_64".
        ndk {
            abiFilters.add("arm64-v8a")
        }

        // Buang terjemahan bawaan library yang tidak dipakai
        resourceConfigurations += listOf("en", "id")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            // Pakai kunci debug supaya assembleRelease langsung bisa dipasang di HP.
            // Untuk dipublikasikan, ganti dengan keystore sendiri.
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        viewBinding = true
    }

    // youtubedl-android perlu mengekstrak binary python/ffmpeg dari jniLibs
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/*.version",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "DebugProbesKt.bin"
            )
        }
    }

    // Build lebih cepat di CI; lint tidak menghentikan build
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
