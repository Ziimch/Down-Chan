plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.unduhku"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.unduhku"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    
    // Library pengunduh & konverter
    implementation("com.github.yausername.youtubedl-android:library:0.16.+")
    implementation("com.github.yausername.youtubedl-android:ffmpeg:0.16.+")
    
    // DocumentFile untuk SD Card / Storage Access Framework
    implementation("androidx.documentfile:documentfile:1.0.1")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}